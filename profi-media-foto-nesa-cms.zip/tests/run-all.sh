#!/usr/bin/env bash
# One command: fresh local stack → users → web server → all tests → report.
# Usage: STACK_DIR=/path/to/stack bash tests/run-all.sh
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; PROJECT="$(cd "$HERE/.." && pwd)"
STACK_DIR="${STACK_DIR:-/home/claude/stack}"; export STACK_DIR
mkdir -p "$PROJECT/tests/report"
bash "$HERE/stack/stop.sh" --wipe >/dev/null 2>&1
bash "$HERE/stack/start.sh" </dev/null >"$PROJECT/tests/report/stack.log" 2>&1 || { echo "stack failed"; exit 1; }
source "$STACK_DIR/run/env.sh"
node "$HERE/stack/seed-users.mjs"
node "$HERE/serve.mjs" </dev/null >"$STACK_DIR/run/serve.log" 2>&1 & SERVE=$!
sleep 1
cd "$PROJECT"
set -o pipefail
{ node tools/csp.mjs --check && node --test --test-reporter=spec tests/unit/*.test.mjs && node --test --test-concurrency=1 --test-reporter=spec tests/e2e/*.test.mjs; } 2>&1 | tee tests/report/results.txt
STATUS=$?
kill $SERVE
exit $STATUS
