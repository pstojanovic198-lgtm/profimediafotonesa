// Tiny stand-in for Supabase's API gateway (Kong): one origin that routes
// /rest/v1 → PostgREST, /auth/v1 → GoTrue, /storage/v1 → Storage API.
// Like Kong, it requires an `apikey` header (or query param) for API routes
// and uses it as the bearer token when no Authorization header is sent.
// TEST USE ONLY.
import http from "node:http";

const PORT = +process.env.GATEWAY_PORT || 54321;
const KEYS = new Set([process.env.ANON_KEY, process.env.SERVICE_KEY].filter(Boolean));
const ROUTES = [
  ["/rest/v1", 3000],
  ["/auth/v1", 9999],
  ["/storage/v1", 5000],
];
const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,PUT,PATCH,DELETE,HEAD,OPTIONS",
  "access-control-allow-headers":
    "authorization,apikey,content-type,x-client-info,x-upsert,prefer,range,accept-profile,content-profile,cache-control,tus-resumable,upload-length,upload-metadata,upload-offset,x-http-method-override,upload-concat,upload-defer-length",
  "access-control-expose-headers":
    "content-range,location,upload-offset,upload-length,tus-resumable,tus-version,tus-max-size,tus-extension,x-total-count",
  "access-control-max-age": "600",
};

http
  .createServer((req, res) => {
    if (req.method === "OPTIONS") {
      // like Supabase: allow whatever headers the client asks for
      const asked = req.headers["access-control-request-headers"];
      res.writeHead(204, asked ? { ...CORS, "access-control-allow-headers": asked } : CORS);
      return res.end();
    }
    const route = ROUTES.find(([p]) => req.url.startsWith(p + "/") || req.url === p || req.url.startsWith(p + "?"));
    if (!route) {
      res.writeHead(404, CORS);
      return res.end("no route");
    }
    const url = new URL(req.url, "http://x");
    const apikey = req.headers.apikey || url.searchParams.get("apikey");
    // Public storage objects are served without a key, like on Supabase.
    const isPublicObject = req.url.startsWith("/storage/v1/object/public/");
    if (!isPublicObject && !KEYS.has(apikey)) {
      res.writeHead(401, { ...CORS, "content-type": "application/json" });
      return res.end(JSON.stringify({ message: "Invalid API key" }));
    }
    const headers = { ...req.headers, host: `127.0.0.1:${route[1]}` };
    if (!headers.authorization && apikey && !isPublicObject) headers.authorization = "Bearer " + apikey;
    headers["x-forwarded-host"] = req.headers.host;
    headers["x-forwarded-proto"] = "http";
    headers["x-forwarded-prefix"] = route[0];
    const upstream = http.request(
      { host: "127.0.0.1", port: route[1], method: req.method, path: req.url.slice(route[0].length) || "/", headers },
      (up) => {
        const h = { ...up.headers, ...CORS };
        // TUS "Location" from storage is relative to its own root; expose it under /storage/v1
        if (route[0] === "/storage/v1" && h.location && h.location.startsWith("http://127.0.0.1:5000")) {
          h.location = h.location.replace("http://127.0.0.1:5000", `http://${req.headers.host}/storage/v1`);
        }
        res.writeHead(up.statusCode, h);
        up.pipe(res);
      },
    );
    upstream.on("error", (e) => {
      res.writeHead(502, CORS);
      res.end("upstream error: " + e.message);
    });
    req.pipe(upstream);
  })
  .listen(PORT, "127.0.0.1", () => console.log("gateway on", PORT));
