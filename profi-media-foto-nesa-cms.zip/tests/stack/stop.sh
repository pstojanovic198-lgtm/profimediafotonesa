#!/usr/bin/env bash
# Stops the local test stack. Pass --wipe to delete its data as well.
STACK_DIR="${STACK_DIR:-/home/claude/stack}"
RUN="$STACK_DIR/run"
for s in gateway postgrest storage gotrue; do
  [ -f "$RUN/$s.pid" ] && kill "$(cat "$RUN/$s.pid")" 2>/dev/null; rm -f "$RUN/$s.pid"
done
# Child processes (e.g. Storage runs under a tsx wrapper) are not in the pid files
pkill -f "gotrue serve" 2>/dev/null
pkill -f "src/start/server.ts" 2>/dev/null
pkill -f "$STACK_DIR/bin/postgrest" 2>/dev/null
pkill -f "tests/stack/gateway.mjs" 2>/dev/null
sleep 1
pkill -9 -f "src/start/server.ts" 2>/dev/null   # tsx may ignore SIGTERM while shutting down
pkill -9 -f "gotrue serve" 2>/dev/null
[ -d "$RUN/pgdata" ] && su postgres -c "/usr/lib/postgresql/16/bin/pg_ctl -D $RUN/pgdata -m fast stop" >/dev/null 2>&1
for port in 54321 3000 5000 9999 54322; do
  for i in $(seq 1 40); do
    (echo > /dev/tcp/127.0.0.1/$port) 2>/dev/null || break
    sleep 0.25
  done
done
if [ "${1:-}" = "--wipe" ]; then rm -rf "$RUN"; fi
echo stopped
