// Creates the test users through the real Auth admin API and provisions the
// administrator exactly like supabase/admin-provisioning.sql. TEST USE ONLY.
import { execFileSync } from "node:child_process";

const URL_ = process.env.SUPABASE_URL;
const SERVICE = process.env.SERVICE_KEY;
export const ADMIN = { email: "vlasnik@test.local", password: "Test-lozinka-2026!" };
export const OTHER = { email: "neovlascen@test.local", password: "Druga-lozinka-2026!" };

async function createUser(u) {
  const res = await fetch(`${URL_}/auth/v1/admin/users`, {
    method: "POST",
    headers: { apikey: SERVICE, authorization: `Bearer ${SERVICE}`, "content-type": "application/json" },
    body: JSON.stringify({ email: u.email, password: u.password, email_confirm: true }),
  });
  if (!res.ok && res.status !== 422) throw new Error(`create user ${u.email}: ${res.status} ${await res.text()}`);
}

export async function seedUsers() {
  await createUser(ADMIN);
  await createUser(OTHER);
  const sql = `insert into public.admin_users (user_id, note) select id, 'test' from auth.users where email = '${ADMIN.email}' on conflict do nothing;`;
  execFileSync("psql", ["postgres://postgres:postgres@127.0.0.1:54322/postgres", "-qc", sql], { env: { ...process.env, PGPASSWORD: "postgres" } });
}

if (import.meta.url === `file://${process.argv[1]}`) seedUsers().then(() => console.log("users ready"));
