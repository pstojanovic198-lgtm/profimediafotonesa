-- Minimal replica of the roles/schemas that the supabase/postgres image
-- creates, so GoTrue, Storage API, PostgREST and our migration run
-- unmodified. TEST USE ONLY.
create role anon nologin noinherit;
create role authenticated nologin noinherit;
create role service_role nologin noinherit bypassrls;
create role authenticator login noinherit password 'postgres';
grant anon, authenticated, service_role to authenticator;

create role supabase_admin login superuser password 'postgres';
create role supabase_auth_admin login createrole noinherit password 'postgres';
create role supabase_storage_admin login createrole noinherit password 'postgres';
grant anon, authenticated, service_role to supabase_storage_admin;

create schema auth authorization supabase_auth_admin;
create schema storage authorization supabase_storage_admin;
create schema extensions;
alter role supabase_auth_admin set search_path = auth;
alter role supabase_storage_admin set search_path = storage;
grant usage on schema auth, storage to anon, authenticated, service_role;
grant create on database postgres to supabase_auth_admin, supabase_storage_admin;

-- Supabase platform defaults: API roles get table privileges in public and
-- rely on RLS. Our migration explicitly revokes/grants on its own tables.
grant usage on schema public to anon, authenticated, service_role;
alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
alter default privileges in schema public grant all on sequences to anon, authenticated, service_role;
