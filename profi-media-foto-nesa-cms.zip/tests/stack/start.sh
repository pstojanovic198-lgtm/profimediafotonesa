#!/usr/bin/env bash
# Starts a local Supabase-compatible stack for automated tests:
#   PostgreSQL 16 (:54322) · PostgREST (:3000) · GoTrue (:9999)
#   Storage API (:5000, file backend, TUS enabled) · gateway (:54321)
# Requires (paths overridable): STACK_DIR with bin/postgrest, bin/gotrue,
# bin/migrations (GoTrue release) and storage/ (supabase/storage v1.40 built).
# TEST USE ONLY — never use these keys anywhere else.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
PROJECT="$(cd "$HERE/../.." && pwd)"
STACK_DIR="${STACK_DIR:-/home/claude/stack}"
RUN="$STACK_DIR/run"
PGDATA="$RUN/pgdata"
PGBIN="${PGBIN:-/usr/lib/postgresql/16/bin}"
mkdir -p "$RUN"

export JWT_SECRET="test-only-jwt-secret-with-at-least-32-characters"
sign() { node -e '
  const c=require("crypto"),b=o=>Buffer.from(JSON.stringify(o)).toString("base64url");
  const h=b({alg:"HS256",typ:"JWT"}),p=b({iss:"supabase-test",role:process.argv[1],iat:1700000000,exp:2000000000});
  console.log(h+"."+p+"."+c.createHmac("sha256",process.env.JWT_SECRET).update(h+"."+p).digest("base64url"))' "$1"; }
export ANON_KEY="$(sign anon)"
export SERVICE_KEY="$(sign service_role)"
printf 'export ANON_KEY=%q\nexport SERVICE_KEY=%q\nexport JWT_SECRET=%q\nexport SUPABASE_URL=http://127.0.0.1:54321\n' \
  "$ANON_KEY" "$SERVICE_KEY" "$JWT_SECRET" > "$RUN/env.sh"

DB="postgres://postgres:postgres@127.0.0.1:54322/postgres"

# ---- PostgreSQL --------------------------------------------------------
fresh=0
if [ ! -d "$PGDATA" ]; then
  fresh=1
  mkdir -p "$PGDATA" && chown postgres "$PGDATA" "$RUN"
  echo postgres > "$RUN/pw"; chown postgres "$RUN/pw"
  su postgres -c "$PGBIN/initdb -D $PGDATA -U postgres --pwfile=$RUN/pw -A scram-sha-256 >/dev/null"
fi
su postgres -c "$PGBIN/pg_ctl -D $PGDATA -o '-p 54322 -k /tmp -c listen_addresses=127.0.0.1' -l $RUN/postgres.log -w start" >/dev/null
export PGPASSWORD=postgres
if [ $fresh = 1 ]; then
  psql "$DB" -q -v ON_ERROR_STOP=1 -f "$HERE/bootstrap.sql"
fi

# ---- GoTrue (Supabase Auth) ---------------------------------------------
export GOTRUE_DB_DRIVER=postgres
export DATABASE_URL="postgres://supabase_auth_admin:postgres@127.0.0.1:54322/postgres"
export GOTRUE_DB_DATABASE_URL="$DATABASE_URL"
export GOTRUE_API_HOST=127.0.0.1 PORT=9999 GOTRUE_API_PORT=9999
export API_EXTERNAL_URL="http://127.0.0.1:54321/auth/v1"
export GOTRUE_SITE_URL="http://127.0.0.1:8080/admin/"
export GOTRUE_URI_ALLOW_LIST="http://127.0.0.1:8080/**"
export GOTRUE_JWT_SECRET="$JWT_SECRET" GOTRUE_JWT_EXP=3600 GOTRUE_JWT_AUD=authenticated
export GOTRUE_JWT_DEFAULT_GROUP_NAME=authenticated GOTRUE_JWT_ADMIN_ROLES=service_role
export GOTRUE_DISABLE_SIGNUP=true GOTRUE_EXTERNAL_EMAIL_ENABLED=true GOTRUE_MAILER_AUTOCONFIRM=true
export GOTRUE_SMTP_HOST=127.0.0.1 GOTRUE_SMTP_PORT=2500 GOTRUE_SMTP_ADMIN_EMAIL=test@example.com
export GOTRUE_RATE_LIMIT_EMAIL_SENT=1000 GOTRUE_LOG_LEVEL=warn
export GOTRUE_DB_MIGRATIONS_PATH="$STACK_DIR/bin"
(cd "$STACK_DIR/bin" && ./gotrue migrate >"$RUN/gotrue-migrate.log" 2>&1)
(cd "$STACK_DIR/bin" && nohup ./gotrue serve >"$RUN/gotrue.log" 2>&1 & echo $! > "$RUN/gotrue.pid")

# ---- Storage API ----------------------------------------------------------
(
  cd "$STACK_DIR/storage"
  export SERVER_HOST=127.0.0.1 SERVER_PORT=5000 SERVER_ADMIN_PORT=5001 SERVER_REGION=local
  export AUTH_JWT_SECRET="$JWT_SECRET" AUTH_JWT_ALGORITHM=HS256 PGRST_JWT_SECRET="$JWT_SECRET"
  export ANON_KEY SERVICE_KEY
  export DATABASE_URL="postgres://supabase_storage_admin:postgres@127.0.0.1:54322/postgres"
  export DB_INSTALL_ROLES=false DB_ANON_ROLE=anon DB_SERVICE_ROLE=service_role DB_AUTHENTICATED_ROLE=authenticated DB_SUPER_USER=postgres
  export STORAGE_BACKEND=file STORAGE_FILE_BACKEND_PATH="$RUN/storage-data" STORAGE_FILE_ETAG_ALGORITHM=md5
  export GLOBAL_S3_BUCKET=local TENANT_ID=stub IS_MULTITENANT=false
  export UPLOAD_FILE_SIZE_LIMIT=524288000 UPLOAD_FILE_SIZE_LIMIT_STANDARD=52428800
  export TUS_URL_PATH=/upload/resumable TUS_URL_EXPIRY_MS=3600000
  export IMAGE_TRANSFORMATION_ENABLED=false PG_QUEUE_ENABLE=false RATE_LIMITER_ENABLED=false
  export LOG_LEVEL=warn REQUEST_ALLOW_X_FORWARDED_PATH=true
  # tsx resolves the @internal/* path aliases of the source tree
  nohup ./node_modules/.bin/tsx src/start/server.ts >"$RUN/storage.log" 2>&1 & echo $! > "$RUN/storage.pid"
)
for i in $(seq 1 60); do curl -fs http://127.0.0.1:5000/status >/dev/null 2>&1 && break; sleep 0.5; done
for i in $(seq 1 60); do curl -fs http://127.0.0.1:9999/health >/dev/null 2>&1 && break; sleep 0.5; done

# ---- Our schema -------------------------------------------------------------
if [ $fresh = 1 ]; then
  for f in "$PROJECT"/supabase/migrations/*.sql; do
    psql "$DB" -q -v ON_ERROR_STOP=1 -f "$f"
  done
fi

# ---- PostgREST ------------------------------------------------------------
cat > "$RUN/postgrest.conf" <<EOF
db-uri = "postgres://authenticator:postgres@127.0.0.1:54322/postgres"
db-schemas = "public"
db-anon-role = "anon"
jwt-secret = "$JWT_SECRET"
server-host = "127.0.0.1"
server-port = 3000
db-max-rows = 1000
EOF
nohup "$STACK_DIR/bin/postgrest" "$RUN/postgrest.conf" >"$RUN/postgrest.log" 2>&1 & echo $! > "$RUN/postgrest.pid"

# ---- Gateway ----------------------------------------------------------------
nohup node "$HERE/gateway.mjs" >"$RUN/gateway.log" 2>&1 & echo $! > "$RUN/gateway.pid"
for i in $(seq 1 60); do curl -fs -H "apikey: $ANON_KEY" "http://127.0.0.1:54321/rest/v1/categories?select=slug" >/dev/null 2>&1 && break; sleep 0.5; done
echo "stack up — source $RUN/env.sh"
