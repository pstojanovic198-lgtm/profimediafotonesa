import { test } from "node:test";
import assert from "node:assert/strict";
import { analyzeMediaUrl, slugify, titleFromFilename } from "../../admin/js/media-url.js";
import { isSafeUrl, isAllowedEmbed, safeVariants, toSrcset } from "../../assets/js/media-safety.js";

const img = (u) => analyzeMediaUrl(u, { expect: "image" });
const vid = (u) => analyzeMediaUrl(u, { expect: "video" });

test("generic https image on any host is accepted (no domain allow-list)", () => {
  for (const u of ["https://example.org/a/b/photo.jpg", "https://cdn.some-unknown-host.rs/x.webp?v=2", "https://i.imgur.com/abc123.png", "https://foo.b-cdn.net/wedding.avif"]) {
    const r = img(u);
    assert.equal(r.ok, true, u);
    assert.equal(r.kind, "image");
    assert.equal(r.sourceType, "external");
  }
});

test("extensionless URL is accepted for the expected kind and flagged for a real check", () => {
  const r = img("https://images.example.com/render?id=42");
  assert.equal(r.ok, true);
  assert.ok(r.notes.some((n) => /proveravamo/.test(n)));
});

test("rejects http, credentials, private hosts, garbage", () => {
  assert.equal(img("http://example.com/a.jpg").code, "http");
  assert.equal(img("https://user:pass@example.com/a.jpg").code, "credentials");
  assert.equal(img("https://192.168.1.10/a.jpg").code, "privateHost");
  assert.equal(img("https://localhost/a.jpg").code, "privateHost");
  assert.equal(img("javascript:alert(1)").ok, false);
  assert.equal(img("").code, "empty");
  assert.equal(img("not a url at all").ok, false);
});

test("wrong kind is explained", () => {
  assert.equal(img("https://example.com/clip.mp4").code, "expectImage");
  assert.equal(vid("https://example.com/photo.jpg").code, "expectVideo");
  assert.equal(img("https://youtu.be/dQw4w9WgXcQ").code, "expectImage");
});

test("unsupported formats", () => {
  assert.equal(vid("https://example.com/a.mov").code, "movFormat");
  assert.equal(img("https://example.com/a.heic").code, "unsupportedFormat");
  assert.equal(img("https://example.com/a.svg").code, "unsupportedFormat");
  assert.equal(img("https://example.com/gallery.html").code, "htmlPage");
});

test("YouTube variants normalise to privacy-enhanced embed", () => {
  const cases = {
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    "https://youtu.be/dQw4w9WgXcQ?si=abc": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    "https://m.youtube.com/watch?v=dQw4w9WgXcQ&feature=share": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    "https://www.youtube.com/shorts/dQw4w9WgXcQ": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    "https://www.youtube.com/embed/dQw4w9WgXcQ": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    "https://www.youtube.com/live/dQw4w9WgXcQ": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0",
    "https://youtu.be/dQw4w9WgXcQ?t=1m30s": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0&start=90",
    "youtube.com/watch?v=dQw4w9WgXcQ&t=45": "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0&start=45",
  };
  for (const [input, embed] of Object.entries(cases)) {
    const r = vid(input);
    assert.equal(r.ok, true, input);
    assert.equal(r.sourceType, "youtube");
    assert.equal(r.embedUrl, embed, input);
    assert.ok(isAllowedEmbed(r.embedUrl));
    assert.equal(r.thumbnailUrl, "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg");
  }
  assert.deepEqual(vid("https://www.youtube.com/shorts/dQw4w9WgXcQ").aspect, { w: 9, h: 16 });
  assert.equal(vid("https://www.youtube.com/playlist?list=PL123").code, "ytPlaylist");
  assert.equal(vid("https://www.youtube.com/@profimedia").code, "ytPlaylist");
  assert.equal(vid("https://www.youtube.com/watch?v=short").code, "ytBad");
});

test("Vimeo public, unlisted and player links", () => {
  assert.equal(vid("https://vimeo.com/76979871").embedUrl, "https://player.vimeo.com/video/76979871?dnt=1");
  assert.equal(vid("https://vimeo.com/76979871/8272103f6e").embedUrl, "https://player.vimeo.com/video/76979871?dnt=1&h=8272103f6e");
  assert.equal(vid("https://player.vimeo.com/video/76979871?h=8272103f6e&badge=0").embedUrl, "https://player.vimeo.com/video/76979871?dnt=1&h=8272103f6e");
  assert.equal(vid("https://vimeo.com/channels/staffpicks/76979871").embedUrl, "https://player.vimeo.com/video/76979871?dnt=1");
  assert.equal(vid("https://vimeo.com/showcase/123").code, "vimeoShowcase");
  assert.equal(vid("https://vimeo.com/user123").code, "vimeoBad");
});

test("Google Drive: file links normalised, folders rejected", () => {
  const id = "1AbCdEfGhIjKlMnOpQrStUvWxYz012345";
  const v = vid(`https://drive.google.com/file/d/${id}/view?usp=sharing`);
  assert.equal(v.ok, true);
  assert.equal(v.embedUrl, `https://drive.google.com/file/d/${id}/preview`);
  assert.ok(isAllowedEmbed(v.embedUrl));
  const i = img(`https://drive.google.com/open?id=${id}`);
  assert.equal(i.ok, true);
  assert.equal(i.provider, "gdrive");
  assert.match(i.url, /thumbnail\?id=.*&sz=w2000$/);
  assert.equal(img("https://drive.google.com/drive/folders/1xyzxyzxyzxyz").code, "driveFolder");
});

test("Dropbox share link becomes raw link; folders rejected", () => {
  const r = img("https://www.dropbox.com/scl/fi/abc123/vencanje.jpg?rlkey=xyz&dl=0");
  assert.equal(r.ok, true);
  assert.equal(r.url, "https://www.dropbox.com/scl/fi/abc123/vencanje.jpg?rlkey=xyz&raw=1");
  assert.equal(r.provider, "dropbox");
  const v = vid("https://www.dropbox.com/s/abc/film.mp4?dl=0");
  assert.equal(v.ok, true);
  assert.equal(v.kind, "video");
  assert.equal(img("https://www.dropbox.com/scl/fo/abc/xyz?rlkey=1").code, "dropboxFolder");
});

test("sharing pages that are not files are explained", () => {
  assert.equal(img("https://photos.app.goo.gl/AbCdEf").code, "gphotos");
  assert.equal(img("https://photos.google.com/share/AF1Qip").code, "gphotos");
  assert.equal(img("https://1drv.ms/i/s!Abc").code, "onedrive");
  assert.equal(vid("https://www.instagram.com/reel/Cxyz/").code, "social");
  assert.equal(vid("https://www.facebook.com/watch/?v=1").code, "social");
  assert.equal(img("https://unsplash.com/photos/abc-123").code, "unsplashPage");
  assert.equal(img("https://imgur.com/gallery/abc").code, "imgurPage");
});

test("CDN thumbnails: Cloudinary, ImageKit, Unsplash", () => {
  const c = img("https://res.cloudinary.com/demo/image/upload/v1712/folder/bride.jpg");
  assert.equal(c.provider, "cloudinary");
  assert.equal(c.thumbnailUrl, "https://res.cloudinary.com/demo/image/upload/w_480,c_limit,f_auto,q_auto/v1712/folder/bride.jpg");
  assert.equal(c.variants.length, 3);
  const ct = img("https://res.cloudinary.com/demo/image/upload/w_300,c_fill/v1712/bride.jpg");
  assert.equal(ct.variants.length, 0, "existing transformation is left untouched");
  const cv = vid("https://res.cloudinary.com/demo/video/upload/v1/dance.mp4");
  assert.equal(cv.posterUrl, "https://res.cloudinary.com/demo/video/upload/so_1,w_960,c_limit,f_jpg/v1/dance.jpg");
  const ik = img("https://ik.imagekit.io/profimedia/vencanje.jpg");
  assert.match(ik.thumbnailUrl, /\?tr=w-480%2Cc-at_max$/);
  const un = img("https://images.unsplash.com/photo-123?ixid=abc");
  assert.equal(un.provider, "unsplash");
  assert.match(un.thumbnailUrl, /w=480/);
});

test("safety helpers mirror the database rules", () => {
  assert.equal(isSafeUrl("https://a.b/c.jpg"), true);
  assert.equal(isSafeUrl("http://127.0.0.1:54321/x"), true);
  assert.equal(isSafeUrl("http://evil.com/x"), false);
  assert.equal(isSafeUrl("javascript:alert(1)"), false);
  assert.equal(isSafeUrl('https://a.b/"onerror=alert(1)'), false);
  assert.equal(isSafeUrl("https://a.b/x y.jpg"), false);
  assert.equal(isAllowedEmbed("https://www.youtube.com/embed/dQw4w9WgXcQ"), false, "only the nocookie domain");
  assert.equal(isAllowedEmbed("https://player.vimeo.com/video/1?x=<script>"), false);
  assert.equal(isAllowedEmbed("https://evil.com/https://player.vimeo.com/video/1"), false);
  const v = safeVariants([{ w: 960, url: "https://a/9.webp" }, { w: 480, url: "https://a/4.webp" }, { w: 10, url: "javascript:x" }, null]);
  assert.deepEqual(v.map((x) => x.w), [480, 960]);
  assert.equal(toSrcset(v), "https://a/4.webp 480w, https://a/9.webp 960w");
});

test("slugify and titles", () => {
  assert.equal(slugify("Rođendani i proslave"), "rodjendani-i-proslave");
  assert.equal(slugify("  Krštenja & Slave!! "), "krstenja-slave");
  assert.equal(slugify("Венчања"), "");
  assert.equal(titleFromFilename("IMG_2041-mladenci_crkva.JPG"), "IMG 2041 mladenci crkva");
  assert.equal(titleFromFilename(".jpg"), "Bez naziva");
});
