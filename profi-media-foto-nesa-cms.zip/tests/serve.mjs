// Static file server for local testing (http://127.0.0.1:8080).
// TEST-ONLY adjustments, applied in memory (files on disk are not changed):
//  * cms-config.js is generated from SUPABASE_URL / ANON_KEY env vars;
//  * the local API origin (http://127.0.0.1:54321) is added to the CSP and
//    `upgrade-insecure-requests` is removed, because the local stack is http.
import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const PORT = +process.env.PORT || 8080;
const API = process.env.SUPABASE_URL || "http://127.0.0.1:54321";
const TYPES = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json", ".webp": "image/webp", ".png": "image/png",
  ".jpg": "image/jpeg", ".ico": "image/x-icon", ".svg": "image/svg+xml", ".woff2": "font/woff2", ".mp4": "video/mp4", ".webm": "video/webm",
};

function patchCsp(html) {
  return html.replace(/(<meta http-equiv="Content-Security-Policy" content=")([^"]*)(")/, (_, a, policy, c) => {
    const p = policy
      .replace(/; upgrade-insecure-requests/, "")
      .replace(/connect-src ([^;]*)/, `connect-src $1 ${API}`)
      .replace(/img-src ([^;]*)/, `img-src $1 ${API}`)
      .replace(/media-src ([^;]*)/, `media-src $1 ${API}`);
    return a + p + c;
  });
}

http
  .createServer(async (req, res) => {
    try {
      let path = decodeURIComponent(new URL(req.url, "http://x").pathname);
      if (path === "/assets/js/cms-config.js") {
        res.writeHead(200, { "content-type": TYPES[".js"], "cache-control": "no-store" });
        return res.end(
          `window.PMFN_CMS = Object.freeze({ supabaseUrl: ${JSON.stringify(API)}, supabaseAnonKey: ${JSON.stringify(process.env.ANON_KEY || "")}, storage: Object.freeze({ provider: "supabase", bucket: "media" }) });`,
        );
      }
      if (path.endsWith("/")) path += "index.html";
      const file = normalize(join(ROOT, path));
      if (!file.startsWith(ROOT) || /\/(\.|node_modules|tests\/stack)/.test(file.slice(ROOT.length))) {
        res.writeHead(404);
        return res.end();
      }
      const st = await stat(file).catch(() => null);
      if (!st || !st.isFile()) {
        res.writeHead(404);
        return res.end("not found");
      }
      let body = await readFile(file);
      if (extname(file) === ".html") body = Buffer.from(patchCsp(body.toString("utf8")));
      res.writeHead(200, { "content-type": TYPES[extname(file)] || "application/octet-stream", "cache-control": "no-store" });
      res.end(body);
    } catch (e) {
      res.writeHead(500);
      res.end(String(e));
    }
  })
  .listen(PORT, "127.0.0.1", () => console.log(`serving ${ROOT} on http://127.0.0.1:${PORT}`));
