// Required tests 1–13 and 18 through the real admin UI in Chromium, against
// the local Supabase-compatible stack (real Auth, PostgREST/RLS, Storage+TUS).
import { test, before, after } from "node:test";
import { writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomBytes } from "node:crypto";
import assert from "node:assert/strict";
import { chromium, SITE, FIX, ADMIN, OTHER, sql, resetData, newPage, login, assertNoErrors, publicGallery } from "./helpers.mjs";

let browser, page;
const row = (title) => {
  const r = sql(`select row_to_json(m) from media_assets m where title = '${title.replace(/'/g, "''")}'`);
  return r ? JSON.parse(r) : null;
};
const card = (title) => page.locator(".mcard", { has: page.locator(".mcard__title", { hasText: title }) });

async function go(hash) {
  await page.goto(SITE + "/admin/#/" + hash);
  await page.reload(); // fresh view even when the hash did not change
  await page.locator("main h1").first().waitFor();
}

async function waitDone(n, timeout = 60000) {
  await page.waitForFunction((n) => document.querySelectorAll(".qitem.is-done").length >= n, n, { timeout });
}

// > 6 MB so the resumable (TUS) path is used; generated, not committed
const BIG = join(tmpdir(), "veliki-video.webm");
const BIG_SIZE = 10 * 1024 * 1024 + 12345;

before(async () => {
  writeFileSync(BIG, randomBytes(BIG_SIZE));
  resetData();
  browser = await chromium.launch();
  page = await newPage(browser);
  // The sandbox has no route to YouTube: answer its thumbnail and player with stubs.
  await page.context().route("https://i.ytimg.com/**", (r) => r.fulfill({ path: FIX + "mladenci-pejzaz.jpg", contentType: "image/jpeg" }));
  await page.context().route("https://www.youtube-nocookie.com/**", (r) => r.fulfill({ body: "<!doctype html><title>YouTube stub</title><p>player</p>", contentType: "text/html" }));
});

after(async () => {
  await browser?.close();
});

test("1. administrator can log in", async () => {
  await login(page, ADMIN);
  await page.getByRole("heading", { name: "Pregled", level: 1 }).waitFor();
  await page.locator(".stats .stat__value").first().waitFor();
  assert.equal(await page.locator(".sidebar__foot strong").textContent(), ADMIN.email);
});

test("2. unauthorized visitors cannot use the administration", async () => {
  const anon = await newPage(browser);
  await anon.goto(SITE + "/admin/#/galerija");
  await anon.getByRole("heading", { name: "Prijava" }).waitFor();
  assert.equal(await anon.locator(".shell").count(), 0, "no admin shell without a session");

  // wrong password
  await anon.getByLabel("E-mail").fill(ADMIN.email);
  await anon.getByRole("textbox", { name: "Lozinka", exact: true }).fill("pogresna-lozinka");
  await anon.getByRole("button", { name: "Prijavi se" }).click();
  await anon.getByText("Pogrešan e-mail ili lozinka.").waitFor();

  // valid account without admin rights
  await login(anon, OTHER);
  await anon.getByText("Ovaj nalog nema administratorska prava", { exact: false }).waitFor();
  assert.equal(await anon.locator(".shell").count(), 0);
  await anon.context().close();
});

test("3. administrator can upload images (multi-file, progress, publish)", async () => {
  await go("dodaj-fotografije");
  await page.setInputFiles(".dropzone input[type=file]", [FIX + "mladenci-pejzaz.jpg", FIX + "detalj-portret.png"]);
  await page.waitForFunction(() => document.querySelectorAll(".qitem").length === 2 && !document.querySelector(".qitem .spinner"));
  const items = page.locator(".qitem");
  await items.nth(0).getByLabel("Naziv").fill("Mladenci na livadi");
  await items.nth(0).getByLabel("Alternativni tekst").fill("Mladenci stoje na livadi u zalazak sunca");
  await items.nth(0).getByLabel("Opis").fill("Venčanje u Petrovcu");
  await items.nth(1).getByLabel("Naziv").fill("Detalj buketa");
  await items.nth(1).getByLabel("Alternativni tekst").fill("Buket belih ruža");
  await items.nth(1).getByLabel("Kategorija").selectOption({ label: "Detalji" });

  // Publishing without alt text is blocked in the UI
  await items.nth(1).getByLabel("Alternativni tekst").fill("");
  await page.getByRole("button", { name: /Objavi sve/ }).click();
  await page.getByText("Za objavu je potreban alternativni tekst", { exact: false }).waitFor();
  await items.nth(1).getByLabel("Alternativni tekst").fill("Buket belih ruža");

  await page.getByRole("button", { name: /Objavi sve/ }).click();
  await waitDone(2);
  const a = row("Mladenci na livadi"), b = row("Detalj buketa");
  assert.equal(a.is_published, true);
  assert.equal(a.source_type, "upload");
  assert.equal(a.width, 2400);
  assert.equal(a.height, 1600);
  assert.deepEqual(a.variants.map((v) => v.w), [480, 960, 1920]);
  assert.match(a.source_url, /original\.jpg$/);
  assert.equal(sql(`select slug from categories where id='${b.category_id}'`), "detalji");
  for (const u of [a.thumbnail_url, a.source_url, b.thumbnail_url]) {
    const r = await fetch(u);
    assert.equal(r.status, 200, u);
  }
  const thumb = await fetch(a.thumbnail_url);
  assert.equal(thumb.headers.get("content-type"), "image/webp");
});

test("4. administrator can upload a video (poster generated automatically)", async () => {
  await go("dodaj-video");
  await page.setInputFiles(".dropzone input[type=file]", FIX + "prvi-ples.mp4");
  await page.waitForFunction(() => document.querySelector(".qitem") && !document.querySelector(".qitem .spinner"));
  await page.locator(".qitem").getByLabel("Naziv").fill("Prvi ples");
  await page.getByRole("button", { name: "Objavi", exact: true }).click();
  await waitDone(1);
  const v = row("Prvi ples");
  assert.equal(v.media_type, "video");
  assert.equal(v.is_published, true);
  assert.equal(v.width, 640);
  assert.ok(+v.duration_seconds > 3);
  assert.ok(v.poster_url && v.thumbnail_url, "auto poster");
  assert.equal(sql(`select slug from categories where id='${v.category_id}'`), "video", "video page defaults to the Video category");
  assert.equal((await fetch(v.source_url)).status, 200);
});

test("4b. large videos use resumable (TUS) upload in 6 MB chunks", async () => {
  const tusCalls = [];
  page.on("request", (r) => r.url().includes("/upload/resumable") && tusCalls.push(r.method()));
  await go("dodaj-video");
  await page.setInputFiles(".dropzone input[type=file]", BIG);
  await page.waitForFunction(() => document.querySelector(".qitem") && !document.querySelector(".qitem .spinner"));
  await page.locator(".qitem").getByLabel("Naziv").fill("Veliki video");
  await page.getByRole("button", { name: "Sačuvaj kao nacrt", exact: true }).click();
  await page.locator(".progress").waitFor({ timeout: 10000 }).catch(() => {});
  await waitDone(1, 120000);
  const v = row("Veliki video");
  assert.equal(v.is_published, false, "saved as draft");
  assert.ok(tusCalls.includes("POST") && tusCalls.filter((m) => m === "PATCH").length >= 2, "TUS create + ≥2 chunks: " + tusCalls.join(","));
  const r = await fetch(v.source_url, { method: "HEAD" });
  assert.equal(+r.headers.get("content-length"), BIG_SIZE);
});

test("4c. upload can be cancelled", async () => {
  await go("dodaj-video");
  await page.setInputFiles(".dropzone input[type=file]", BIG);
  await page.waitForFunction(() => document.querySelector(".qitem") && !document.querySelector(".qitem .spinner"));
  await page.locator(".qitem").getByLabel("Naziv").fill("Otkazani video");
  await page.route("**/upload/resumable/**", async (r) => {
    await new Promise((res) => setTimeout(res, 1500)); // slow the chunk so there is time to cancel
    r.continue().catch(() => {});
  });
  await page.getByRole("button", { name: "Objavi", exact: true }).click();
  await page.getByRole("button", { name: "Otkaži" }).click();
  await page.getByText("Otpremanje je otkazano.").first().waitFor();
  await page.unroute("**/upload/resumable/**");
  assert.equal(row("Otkazani video"), null, "nothing saved");
  assert.equal(await page.locator(".qitem.is-done").count(), 0);
});

test("5. administrator can add an external image URL", async () => {
  await go("dodaj-fotografije");
  await page.locator(".segmented label", { hasText: "Link do fotografije" }).click();
  await page.getByRole("textbox", { name: "Link do fotografije" }).fill(SITE + "/tests/fixtures/detalj-portret.png");
  await page.getByRole("button", { name: "Dodaj link" }).click();
  await page.waitForFunction(() => document.querySelector(".qitem") && !document.querySelector(".qitem .spinner"));
  await page.getByText("1200 × 1800 px", { exact: false }).waitFor();
  await page.locator(".qitem").getByLabel("Naziv").fill("Spoljna fotografija");
  await page.locator(".qitem").getByLabel("Alternativni tekst").fill("Test slika sa spoljnog linka");
  await page.getByRole("button", { name: "Objavi", exact: true }).click();
  await waitDone(1);
  const r = row("Spoljna fotografija");
  assert.equal(r.source_type, "external");
  assert.equal(r.source_url, SITE + "/tests/fixtures/detalj-portret.png", "original link kept, not re-hosted");
  assert.ok(r.variants.length >= 1, "thumbnails built because the host allows CORS");
  assert.equal(r.height, 1800);
});

test("6. administrator can add a direct video URL", async () => {
  await go("dodaj-video");
  await page.locator(".segmented label", { hasText: "Link do video fajla" }).click();
  await page.getByRole("textbox", { name: "Link do video fajla" }).fill(SITE + "/tests/fixtures/zdravica.webm");
  await page.getByRole("button", { name: "Dodaj link" }).click();
  await page.waitForFunction(() => document.querySelector(".qitem") && !document.querySelector(".qitem .spinner"));
  await page.locator(".qitem").getByLabel("Naziv").fill("Zdravica (link)");
  await page.getByRole("button", { name: "Objavi", exact: true }).click();
  await waitDone(1);
  const r = row("Zdravica (link)");
  assert.equal(r.source_type, "external");
  assert.equal(r.media_type, "video");
  assert.equal(r.width, 640);
  assert.ok(r.poster_url, "poster frame captured (host allows CORS)");
});

test("7. administrator can embed a YouTube video", async () => {
  await go("dodaj-video");
  await page.locator(".segmented label", { hasText: "YouTube" }).click();
  await page.getByRole("textbox", { name: "YouTube link" }).fill("https://youtu.be/dQw4w9WgXcQ?si=share");
  await page.getByRole("button", { name: "Dodaj link" }).click();
  await page.waitForFunction(() => document.querySelector(".qitem") && !document.querySelector(".qitem .spinner"));
  await page.locator(".qitem").getByLabel("Naziv").fill("YouTube spot");
  // preview opens the sandboxed privacy-enhanced player, no autoplay
  await page.locator(".qitem").getByRole("button", { name: "Pregled" }).click();
  const frame = page.locator("dialog.pv iframe");
  assert.equal(await frame.getAttribute("src"), "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0");
  assert.match(await frame.getAttribute("sandbox"), /allow-scripts/);
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: "Objavi", exact: true }).click();
  await waitDone(1);
  const r = row("YouTube spot");
  assert.equal(r.source_type, "youtube");
  assert.equal(r.embed_url, "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0");
  assert.equal(r.thumbnail_url, "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg");
});

test("18. invalid URLs produce useful error messages", async () => {
  await go("dodaj-fotografije");
  await page.locator(".segmented label", { hasText: "Link do fotografije" }).click();
  const cases = [
    ["https://www.instagram.com/p/Cabc123/", /Instagrama/],
    ["https://www.dropbox.com/scl/fo/abc/xyz?rlkey=1", /Dropbox folder/],
    ["https://photos.app.goo.gl/AbCd", /Google Photos/],
    ["http://example.com/slika.jpg", /https:\/\//],
    [SITE + "/tests/fixtures/ne-postoji.jpg", /ne može da se učita/],
    [SITE + "/tests/fixtures/prvi-ples.mp4", /Dodaj video/],
  ];
  for (const [url, re] of cases) {
    await page.getByRole("textbox", { name: "Link do fotografije" }).fill(url);
    await page.getByRole("button", { name: "Dodaj link" }).click();
    await page.locator(".qitem.is-error").last().getByText(re).waitFor({ timeout: 20000 });
  }
  assert.equal(await page.locator(".qitem.is-error").count(), cases.length);
  assert.ok(await page.getByRole("button", { name: "Objavi", exact: true }).isDisabled(), "nothing to publish");
});

test("8 & 9. administrator can edit media and change its category", async () => {
  await go("galerija");
  await card("Mladenci na livadi").getByRole("button", { name: "Uredi" }).click();
  const dlg = page.locator("dialog.dialog");
  await dlg.getByLabel("Naziv").fill("Mladenci na livadi — izmenjeno");
  await dlg.getByLabel("Opis").fill("Novi opis fotografije");
  await dlg.getByLabel("Kategorija").selectOption({ label: "Rođendani i proslave" });
  await dlg.getByRole("button", { name: "Sačuvaj" }).click();
  await page.getByText("Izmene su sačuvane.", { exact: false }).waitFor();
  const r = row("Mladenci na livadi — izmenjeno");
  assert.equal(r.description, "Novi opis fotografije");
  assert.equal(sql(`select slug from categories where id='${r.category_id}'`), "proslave");

  // bulk move back
  await card("Mladenci na livadi — izmenjeno").locator(".mcard__select input").check();
  await page.locator(".bulkbar select").selectOption({ label: "Venčanja" });
  await page.getByText("Premešteno u „Venčanja“", { exact: false }).waitFor();
  assert.equal(sql(`select c.slug from media_assets m join categories c on c.id=m.category_id where m.id='${r.id}'`), "vencanja");
});

test("10. administrator can reorder media (keyboard and drag-and-drop)", async () => {
  await go("galerija");
  await page.locator(".mcard").first().waitFor();
  const domOrder = () => page.locator(".mcard .mcard__title").allTextContents();
  const dbOrder = () => sql("select string_agg(title, '|' order by sort_order, id) from media_assets where deleted_at is null").split("|");

  const before = await domOrder();
  await page.locator(".mcard").first().locator(".mcard__grip").focus();
  await page.keyboard.press("ArrowRight");
  await page.getByText("Redosled je sačuvan", { exact: false }).waitFor();
  const afterKey = await domOrder();
  assert.deepEqual(afterKey.slice(0, 2), [before[1], before[0]]);
  assert.deepEqual(dbOrder(), afterKey);

  // drag the last card to the first position
  const last = page.locator(".mcard").last();
  const lastTitle = await last.locator(".mcard__title").textContent();
  const grip = await last.locator(".mcard__grip").boundingBox();
  const first = await page.locator(".mcard").first().boundingBox();
  await page.mouse.move(grip.x + grip.width / 2, grip.y + grip.height / 2);
  await page.mouse.down();
  await page.mouse.move(first.x + 30, first.y + 40, { steps: 12 });
  await page.mouse.up();
  await page.waitForFunction((t) => document.querySelector(".mcard .mcard__title").textContent === t, lastTitle);
  await page.waitForTimeout(1200); // debounce + request
  assert.equal(dbOrder()[0], lastTitle);
  const g = await publicGallery();
  assert.equal(g.items[0].title, dbOrder().filter((t) => row(t).is_published)[0], "website uses the same order");
});

test("11. administrator can unpublish and publish", async () => {
  await go("galerija");
  await card("Prvi ples").getByRole("button", { name: "Povuci sa sajta: Prvi ples" }).click();
  await page.getByText("Povučeno sa sajta", { exact: false }).waitFor();
  assert.equal(row("Prvi ples").is_published, false);
  assert.ok(!(await publicGallery()).items.some((i) => i.title === "Prvi ples"));
  await card("Prvi ples").getByRole("button", { name: "Objavi: Prvi ples" }).click();
  await page.getByText("Objavljeno: 1", { exact: false }).waitFor();
  assert.ok((await publicGallery()).items.some((i) => i.title === "Prvi ples"));

  // bulk publish of a draft (Veliki video)
  await card("Veliki video").locator(".mcard__select input").check();
  await page.locator(".bulkbar").getByRole("button", { name: "Objavi" }).click();
  await page.getByText("Objavljeno: 1", { exact: false }).waitFor();
  assert.equal(row("Veliki video").is_published, true);
});

test("12. administrator can delete media (trash, restore, permanent delete)", async () => {
  await go("galerija");
  const r0 = row("Veliki video");
  await card("Veliki video").locator(".mcard__select input").check();
  await page.locator(".bulkbar").getByRole("button", { name: "Obriši" }).click();
  // confirmation dialog, focus on the safe choice
  const dlg = page.getByRole("alertdialog");
  assert.equal(await dlg.locator("button:focus").textContent(), "Odustani");
  await dlg.getByRole("button", { name: "Premesti u korpu" }).click();
  await page.getByText("Premešteno u korpu.").waitFor();
  const r1 = row("Veliki video");
  assert.ok(r1.deleted_at);
  assert.equal(r1.is_published, false);
  assert.ok(!(await publicGallery()).items.some((i) => i.title === "Veliki video"));

  await page.getByLabel("Status").selectOption("trash");
  await card("Veliki video").getByRole("button", { name: "Vrati" }).click();
  await page.getByText("Vraćeno iz korpe", { exact: false }).waitFor();
  assert.equal(row("Veliki video").deleted_at, null);

  // trash again, then delete permanently (files are removed from storage)
  await page.getByLabel("Status").selectOption("all");
  await card("Veliki video").locator(".mcard__select input").check();
  await page.locator(".bulkbar").getByRole("button", { name: "Obriši" }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: "Premesti u korpu" }).click();
  await page.getByLabel("Status").selectOption("trash");
  await card("Veliki video").getByRole("button", { name: "Trajno obriši: Veliki video" }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: "Obriši trajno" }).click();
  await page.getByText("Trajno obrisano.").waitFor();
  assert.equal(row("Veliki video"), null);
  assert.ok((await fetch(r0.source_url, { method: "HEAD" })).status >= 400, "video file removed from storage");
  for (const u of [r0.poster_url, r0.thumbnail_url].filter(Boolean)) assert.ok((await fetch(u, { method: "HEAD" })).status >= 400, "poster removed from storage");
});

test("categories: add, rename/describe, hide, reorder; identifiers are protected", async () => {
  await go("kategorije");
  await page.getByRole("button", { name: "Nova kategorija" }).click();
  const dlg = page.locator("dialog.dialog");
  await dlg.getByLabel("Naziv").fill("Krštenja");
  assert.equal(await dlg.getByLabel("Identifikator (ID filtera)").inputValue(), "krstenja");
  await dlg.getByLabel("Opis").fill("Krštenja i porodična slavlja");
  await dlg.getByRole("button", { name: "Dodaj kategoriju" }).click();
  await page.getByText("Kategorija je dodata.").waitFor();
  assert.equal(sql("select name from categories where slug='krstenja'"), "Krštenja");

  await page.locator(".cat", { hasText: "Detalji" }).getByRole("button", { name: "Uredi" }).click();
  assert.equal(await dlg.getByLabel("Identifikator (ID filtera)").getAttribute("readonly"), "");
  await dlg.getByLabel("Naziv").fill("Detalji i dekoracija");
  await dlg.getByLabel("Opis").fill("Burme, buketi, dekoracija");
  await dlg.getByRole("button", { name: "Sačuvaj" }).click();
  await page.getByText("Kategorija je sačuvana.").waitFor();
  assert.equal(sql("select name||'|'||slug from categories where slug='detalji'"), "Detalji i dekoracija|detalji");

  await page.getByRole("switch", { name: "Prikaži „Krštenja“ na sajtu" }).uncheck();
  await page.getByText("je skrivena na sajtu", { exact: false }).waitFor();
  assert.equal(sql("select is_visible from categories where slug='krstenja'"), "f");

  await page.getByRole("button", { name: "Pomeri „Krštenja“ gore" }).click();
  await page.waitForTimeout(800);
  assert.equal(sql("select string_agg(slug, ',' order by sort_order) from categories"), "vencanja,detalji,proslave,krstenja,video");

  // non-empty categories cannot be deleted
  await page.getByRole("button", { name: "Obriši „Venčanja“" }).click();
  await page.getByText("Premestite ih u drugu kategoriju", { exact: false }).waitFor();
  assert.equal(sql("select count(*) from categories where slug='vencanja'"), "1");
  // empty one can
  await page.getByRole("button", { name: "Obriši „Krštenja“" }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: "Obriši" }).click();
  await page.getByText("Kategorija je obrisana.").waitFor();
});

test("13. newly published media appears on the public website", async () => {
  const site = await newPage(browser);
  await site.goto(SITE + "/#radovi");
  await site.waitForFunction(() => !document.documentElement.classList.contains("cms-pending"));
  const titles = await site.locator(".gallery .g-link").evaluateAll((as) => as.map((a) => a.dataset.title));
  for (const t of ["Mladenci na livadi — izmenjeno", "Detalj buketa", "Prvi ples", "Spoljna fotografija", "Zdravica (link)", "YouTube spot"]) assert.ok(titles.includes(t), t);
  assert.equal(titles.length, (await publicGallery()).items.length);
  const chips = await site.locator("[data-filters] .chip").allTextContents();
  assert.deepEqual(chips, ["Sve", "Venčanja", "Detalji i dekoracija", "Video snimanje"], "only visible categories with published items");
  assertNoErrors(site);
  await site.context().close();
});

test("settings: illustrative-photo notice is managed from the CMS", async () => {
  await go("podesavanja");
  await page.getByRole("switch", { name: /Napomena o ilustrativnim/ }).uncheck();
  await page.locator("form", { hasText: "Galerija na sajtu" }).getByRole("button", { name: "Sačuvaj" }).click();
  await page.getByText("Sačuvano.", { exact: false }).waitFor();
  const site = await newPage(browser);
  await site.goto(SITE + "/#radovi");
  await site.waitForFunction(() => !document.documentElement.classList.contains("cms-pending"));
  assert.equal(await site.locator(".stock-note").isHidden(), true);
  await site.context().close();
  sql("update site_settings set stock_notice_enabled = true");
});

test("logout ends the session", async () => {
  await page.getByRole("button", { name: "Odjava" }).click();
  await page.getByRole("heading", { name: "Prijava" }).waitFor();
  await page.goto(SITE + "/admin/#/galerija");
  await page.getByRole("heading", { name: "Prijava" }).waitFor();
  const stored = await page.evaluate(() => localStorage.getItem("pmfn-admin-auth"));
  assert.equal(stored, null);
  assertNoErrors(page, [/Failed to load resource.*(404|400)/, /ne-postoji\.jpg/, /ERR_FAILED/]);
});
