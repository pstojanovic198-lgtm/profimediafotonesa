// Required tests 2 & 20: visitors and non-admin accounts cannot perform
// administrative operations. Exercised against the real API (PostgREST +
// GoTrue + Storage) with RLS — no UI involved, so hiding buttons cannot help.
import { test, before } from "node:test";
import assert from "node:assert/strict";
import { rest, sql, resetData, tokenFor, ADMIN, OTHER, ANON, publicGallery } from "./helpers.mjs";

let adminToken, otherToken, catId, draftId, pubId;

before(async () => {
  resetData();
  adminToken = await tokenFor(ADMIN);
  otherToken = await tokenFor(OTHER);
  catId = sql("select id from categories where slug='vencanja'");
  draftId = sql(`insert into media_assets (title, alt_text, media_type, category_id, source_type, source_url, is_published)
                 values ('Tajni nacrt','alt','image','${catId}','external','https://example.com/a.jpg', false) returning id`);
  pubId = sql(`insert into media_assets (title, alt_text, media_type, category_id, source_type, source_url, is_published)
               values ('Javna','alt','image','${catId}','external','https://example.com/b.jpg', true) returning id`);
});

test("public signup is disabled", async () => {
  const r = await rest("/auth/v1/signup", { method: "POST", body: { email: "napadac@test.local", password: "Neka-lozinka-123" } });
  assert.ok(r.status >= 400, "signup must fail, got " + r.status);
  assert.equal(sql("select count(*) from auth.users where email='napadac@test.local'"), "0");
});

test("anonymous visitor sees only published media", async () => {
  const g = await publicGallery();
  const titles = g.items.map((i) => i.title);
  assert.ok(titles.includes("Javna"));
  assert.ok(!titles.includes("Tajni nacrt"));
  const v = await rest("/rest/v1/gallery_items?select=title");
  assert.deepEqual(v.json.map((x) => x.title), ["Javna"]);
  const direct = await rest(`/rest/v1/media_assets?select=id,title&id=eq.${draftId}`);
  assert.deepEqual(direct.json, [], "draft must be invisible to anon");
});

test("anonymous visitor cannot insert, update, delete, reorder or change settings", async () => {
  const ins = await rest("/rest/v1/media_assets", { method: "POST", body: { title: "x", media_type: "image", category_id: catId, source_type: "external", source_url: "https://e.com/x.jpg" } });
  assert.ok([401, 403].includes(ins.status), "insert " + ins.status);
  const upd = await rest(`/rest/v1/media_assets?id=eq.${pubId}`, { method: "PATCH", body: { title: "hacked" }, headers: { prefer: "return=representation" } });
  assert.ok(upd.status >= 400 || (Array.isArray(upd.json) && upd.json.length === 0), "update " + upd.status);
  const del = await rest(`/rest/v1/media_assets?id=eq.${pubId}`, { method: "DELETE" });
  assert.ok(del.status >= 400 || del.status === 204);
  assert.equal(sql(`select title from media_assets where id='${pubId}'`), "Javna", "row unchanged");
  const ro = await rest("/rest/v1/rpc/reorder_media", { method: "POST", body: { p_ids: [pubId, draftId] } });
  assert.ok(ro.status >= 400, "reorder " + ro.status);
  const st = await rest("/rest/v1/site_settings?id=eq.1", { method: "PATCH", body: { stock_notice_enabled: false } });
  assert.ok(st.status >= 400 || st.status === 204);
  assert.equal(sql("select stock_notice_enabled from site_settings"), "t");
  const cat = await rest("/rest/v1/categories", { method: "POST", body: { slug: "hack", name: "Hack" } });
  assert.ok(cat.status >= 400, "category insert " + cat.status);
  const adm = await rest("/rest/v1/admin_users", { method: "POST", body: { user_id: "00000000-0000-0000-0000-000000000000" } });
  assert.ok(adm.status >= 400);
});

test("anonymous visitor cannot upload or delete storage files", async () => {
  const up = await rest("/storage/v1/object/media/2026/01/hack/x.webp", { method: "POST", body: new Uint8Array([1, 2, 3]), headers: { "content-type": "image/webp" } });
  assert.ok(up.status >= 400, "anon upload " + up.status);
  const tus = await rest("/storage/v1/upload/resumable", {
    method: "POST",
    headers: { "tus-resumable": "1.0.0", "upload-length": "3", "upload-metadata": "bucketName " + btoa("media") + ",objectName " + btoa("x/y.mp4") },
  });
  assert.ok(tus.status >= 400, "anon resumable " + tus.status);
});

test("logged-in user who is NOT an administrator has no admin rights", async () => {
  const isAdmin = await rest("/rest/v1/rpc/is_admin", { method: "POST", token: otherToken, body: {} });
  assert.equal(isAdmin.json, false);
  const ins = await rest("/rest/v1/media_assets", { method: "POST", token: otherToken, body: { title: "x", media_type: "image", category_id: catId, source_type: "external", source_url: "https://e.com/x.jpg" } });
  assert.ok(ins.status >= 400, "insert " + ins.status);
  const drafts = await rest(`/rest/v1/media_assets?select=id&id=eq.${draftId}`, { token: otherToken });
  assert.deepEqual(drafts.json, []);
  const stats = await rest("/rest/v1/rpc/dashboard_stats", { method: "POST", token: otherToken, body: {} });
  assert.ok(stats.status >= 400);
  const up = await rest("/storage/v1/object/media/2026/01/hack/x.webp", { method: "POST", token: otherToken, body: new Uint8Array([1]), headers: { "content-type": "image/webp" } });
  assert.ok(up.status >= 400, "non-admin upload " + up.status);
  const self = await rest("/rest/v1/admin_users", { method: "POST", token: otherToken, body: { user_id: JSON.parse(atob(otherToken.split(".")[1])).sub } });
  assert.ok(self.status >= 400, "self-promotion must fail");
});

test("administrator can read drafts and write", async () => {
  const isAdmin = await rest("/rest/v1/rpc/is_admin", { method: "POST", token: adminToken, body: {} });
  assert.equal(isAdmin.json, true);
  const drafts = await rest(`/rest/v1/media_assets?select=id&id=eq.${draftId}`, { token: adminToken });
  assert.equal(drafts.json.length, 1);
});

test("database rejects unsafe content even from an administrator", async () => {
  const base = { title: "x", alt_text: "a", media_type: "video", category_id: catId };
  const js = await rest("/rest/v1/media_assets", { method: "POST", token: adminToken, body: { ...base, source_type: "external", source_url: "javascript:alert(1)" } });
  assert.equal(js.status, 400, "javascript: URL");
  const embed = await rest("/rest/v1/media_assets", { method: "POST", token: adminToken, body: { ...base, source_type: "youtube", embed_url: "https://evil.example/embed/x" } });
  assert.equal(embed.status, 400, "non-allow-listed embed");
  const http = await rest("/rest/v1/media_assets", { method: "POST", token: adminToken, body: { ...base, media_type: "image", source_type: "external", source_url: "http://evil.example/a.jpg" } });
  assert.equal(http.status, 400, "plain http URL");
  const noAlt = await rest("/rest/v1/media_assets", { method: "POST", token: adminToken, body: { title: "x", media_type: "image", category_id: catId, source_type: "external", source_url: "https://e.com/a.jpg", is_published: true } });
  assert.equal(noAlt.status, 400, "published photo without alt text");
  const slug = await rest(`/rest/v1/categories?slug=eq.vencanja`, { method: "PATCH", token: adminToken, body: { slug: "nesto-drugo" } });
  assert.equal(slug.status, 400, "category identifiers are immutable");
});

test("a sign-out revokes the session's refresh token", async () => {
  const r = await rest("/auth/v1/token?grant_type=password", { method: "POST", body: OTHER });
  const out = await rest("/auth/v1/logout", { method: "POST", token: r.json.access_token });
  assert.equal(out.status, 204);
  const refresh = await rest("/auth/v1/token?grant_type=refresh_token", { method: "POST", body: { refresh_token: r.json.refresh_token } });
  assert.ok(refresh.status >= 400, "refresh after logout must fail");
});

test("anon key is the only key the website ships", async () => {
  const fs = await import("node:fs");
  const files = ["assets/js/cms-config.js", "assets/js/gallery-cms.js", "admin/js/app.js", "index.html", "admin/index.html"];
  for (const f of files) {
    const s = fs.readFileSync(new URL("../../" + f, import.meta.url), "utf8");
    assert.ok(!/sb_secret_[A-Za-z0-9_-]{10,}/.test(s), f + " must not contain a secret API key");
    for (const jwt of s.match(/eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g) || []) {
      const role = JSON.parse(Buffer.from(jwt.split(".")[1], "base64url")).role;
      assert.notEqual(role, "service_role", f + " contains a service_role key");
    }
  }
  assert.ok(ANON.length > 20);
});
