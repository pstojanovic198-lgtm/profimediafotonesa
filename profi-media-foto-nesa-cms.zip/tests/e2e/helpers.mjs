// Shared helpers for the end-to-end suite (local Supabase-compatible stack).
import { execFileSync } from "node:child_process";
import { createRequire } from "node:module";
import assert from "node:assert/strict";

const require = createRequire(import.meta.url);
export const { chromium } = require("playwright");

export const SITE = process.env.SITE_URL || "http://127.0.0.1:8080";
export const API = process.env.SUPABASE_URL || "http://127.0.0.1:54321";
export const ANON = process.env.ANON_KEY;
export const SERVICE = process.env.SERVICE_KEY;
export const FIX = new URL("../fixtures/", import.meta.url).pathname;
export const ADMIN = { email: "vlasnik@test.local", password: "Test-lozinka-2026!" };
export const OTHER = { email: "neovlascen@test.local", password: "Druga-lozinka-2026!" };

if (!ANON || !SERVICE) throw new Error("Source the stack env first: source $STACK_DIR/run/env.sh");

export function sql(q) {
  return execFileSync("psql", ["postgres://postgres:postgres@127.0.0.1:54322/postgres", "-AtXqc", q], {
    env: { ...process.env, PGPASSWORD: "postgres" },
    encoding: "utf8",
  }).trim();
}

export function resetData() {
  sql(`delete from public.media_assets;
       delete from public.categories where slug not in ('vencanja','detalji','proslave','video');
       update public.categories set is_visible = true, description = null,
         name = case slug when 'vencanja' then 'Venčanja' when 'detalji' then 'Detalji' when 'proslave' then 'Rođendani i proslave' else 'Video snimanje' end,
         sort_order = case slug when 'vencanja' then 10 when 'detalji' then 20 when 'proslave' then 30 else 40 end;
       update public.site_settings set stock_notice_enabled = true, stock_notice_text = null, fallback_enabled = true,
         max_image_mb = 25, max_video_mb = 50, keep_original_images = true where id = 1;`);
}

/** Raw REST call through the gateway. */
export async function rest(path, { method = "GET", key = ANON, token, body, headers = {} } = {}) {
  const res = await fetch(API + path, {
    method,
    headers: { apikey: key, authorization: "Bearer " + (token || key), "content-type": "application/json", ...headers },
    body: body === undefined ? undefined : typeof body === "string" || body instanceof Uint8Array ? body : JSON.stringify(body),
  });
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: res.status, json, text };
}

export async function tokenFor(user) {
  const r = await rest("/auth/v1/token?grant_type=password", { method: "POST", body: user });
  assert.equal(r.status, 200, "login " + user.email + ": " + r.text);
  return r.json.access_token;
}

export async function publicGallery() {
  const r = await rest("/rest/v1/rpc/public_gallery");
  assert.equal(r.status, 200, r.text);
  return r.json;
}

/** Page with console/CSP error collection. */
export async function newPage(browser, opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, ...opts });
  const page = await ctx.newPage();
  page.errors = [];
  page.on("console", (m) => {
    const t = m.text();
    if (m.type() === "error" || /Content Security Policy/i.test(t)) page.errors.push(t);
  });
  page.on("pageerror", (e) => page.errors.push("pageerror: " + e.message));
  return page;
}

export async function login(page, user = ADMIN) {
  await page.goto(SITE + "/admin/");
  await page.getByLabel("E-mail").fill(user.email);
  await page.getByRole("textbox", { name: "Lozinka", exact: true }).fill(user.password);
  await page.getByRole("button", { name: "Prijavi se" }).click();
}

export async function noHorizontalScroll(page) {
  return page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
}

/** Fails if a page logged errors other than the expected ones. */
export function assertNoErrors(page, allow = []) {
  const bad = page.errors.filter((e) => !allow.some((re) => re.test(e)));
  assert.deepEqual(bad, [], "console errors:\n" + bad.join("\n"));
}
