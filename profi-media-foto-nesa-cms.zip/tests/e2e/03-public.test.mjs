// Required tests 14–17 and 19 on the public website, plus fallback, XSS and CSP checks.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { chromium, SITE, API, FIX, sql, resetData, newPage, login, assertNoErrors, noHorizontalScroll } from "./helpers.mjs";

let browser;
const F = SITE + "/tests/fixtures/";
const cat = (slug) => sql(`select id from categories where slug='${slug}'`);

function seed() {
  resetData();
  const v = (u) => JSON.stringify([{ w: 480, url: u }, { w: 960, url: u }]);
  const rows = [];
  for (let i = 1; i <= 14; i++) {
    const slug = i % 3 === 0 ? "detalji" : i % 3 === 1 ? "vencanja" : "proslave";
    const file = i % 2 ? "mladenci-pejzaz.jpg" : "detalj-portret.png";
    const [w, h] = i % 2 ? [2400, 1600] : [1200, 1800];
    rows.push(`('Foto ${i}', 'Opis ${i}', 'Alt ${i}', 'image', '${cat(slug)}', 'external', '${F + file}', '${F + file}', '${v(F + file)}', ${w}, ${h}, true, ${i * 10})`);
  }
  sql(`insert into media_assets (title, description, alt_text, media_type, category_id, source_type, source_url, thumbnail_url, variants, width, height, is_published, sort_order) values ${rows.join(",")}`);
  sql(`insert into media_assets (title, media_type, category_id, source_type, source_url, mime_type, poster_url, thumbnail_url, width, height, is_published, sort_order)
       values ('Zdravica video', 'video', '${cat("video")}', 'external', '${F}zdravica.webm', 'video/webm', '${F}mladenci-pejzaz.jpg', '${F}mladenci-pejzaz.jpg', 640, 360, true, 1)`);
  sql(`insert into media_assets (title, media_type, category_id, source_type, source_url, embed_url, thumbnail_url, width, height, is_published, sort_order)
       values ('YouTube spot', 'video', '${cat("video")}', 'youtube', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0', 'https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg', 1920, 1080, true, 2)`);
  sql(`insert into media_assets (title, media_type, category_id, source_type, source_url, width, height, is_published, sort_order)
       values ('Pokvaren video', 'video', '${cat("video")}', 'external', '${F}ne-postoji.mp4', 640, 360, true, 3)`);
  sql(`insert into media_assets (title, alt_text, media_type, category_id, source_type, source_url, is_published) values ('Nacrt', 'x', 'image', '${cat("vencanja")}', 'external', '${F}detalj-portret.png', false)`);
}

async function site(opts = {}) {
  const page = await newPage(browser, opts);
  await page.context().route("https://i.ytimg.com/**", (r) => r.fulfill({ path: FIX + "mladenci-pejzaz.jpg", contentType: "image/jpeg" }));
  await page.context().route("https://www.youtube-nocookie.com/**", (r) => r.fulfill({ body: "<!doctype html><p>player</p>", contentType: "text/html" }));
  return page;
}
async function open(page, hash = "#radovi") {
  await page.goto("about:blank"); // force a real page load even when only the hash would change
  await page.goto(SITE + "/" + hash);
  await page.waitForFunction(() => !document.documentElement.classList.contains("cms-pending"));
}
const visibleItems = (page) => page.locator(".gallery .g-item:not([hidden])");

before(async () => {
  seed();
  browser = await chromium.launch();
});
after(async () => browser?.close());

test("CMS content replaces the built-in photos, in CMS order, drafts excluded", async () => {
  const page = await site();
  await open(page);
  const titles = await page.locator(".gallery .g-link").evaluateAll((as) => as.map((a) => a.dataset.title));
  assert.equal(titles.length, 17);
  assert.deepEqual(titles.slice(0, 3), ["Zdravica video", "YouTube spot", "Pokvaren video"]);
  assert.ok(!titles.includes("Nacrt"));
  // images: lazy, dimensions for aspect ratio, alt text, responsive srcset
  const img = page.locator('.g-link[data-title="Foto 1"] img');
  assert.equal(await img.getAttribute("loading"), "lazy");
  assert.equal(await img.getAttribute("alt"), "Alt 1");
  assert.equal(await img.getAttribute("width"), "540");
  assert.equal(await img.getAttribute("height"), "360");
  // videos are not loaded on the page at all (only poster images)
  assert.equal(await page.locator(".gallery video, .gallery iframe").count(), 0);
  assertNoErrors(page);
  await page.context().close();
});

test("14. gallery filters and „Prikaži još” work", async () => {
  const page = await site();
  await open(page);
  assert.deepEqual(await page.locator("[data-filters] .chip").allTextContents(), ["Sve", "Venčanja", "Detalji", "Rođendani i proslave", "Video snimanje"]);
  assert.equal(await visibleItems(page).count(), 12, "first page = 12");
  const more = page.locator("[data-more]");
  assert.equal(await more.textContent(), "Prikaži još 5 fotografija");
  await more.click();
  assert.equal(await visibleItems(page).count(), 17);
  assert.equal(await page.evaluate(() => document.activeElement.closest(".g-item") !== null), true, "focus moves to first new item");

  await page.getByRole("button", { name: "Video snimanje" }).click();
  assert.equal(await page.getByRole("button", { name: "Video snimanje" }).getAttribute("aria-pressed"), "true");
  const cats = await visibleItems(page).evaluateAll((lis) => lis.map((l) => l.dataset.cat));
  assert.deepEqual([...new Set(cats)], ["video"]);
  assert.equal(cats.length, 3);
  await page.getByRole("button", { name: "Venčanja" }).click();
  assert.equal(await visibleItems(page).count(), 5);
  // a service-card link opens the gallery pre-filtered (existing behaviour)
  await page.locator('[data-filter-link="proslave"]').first().click();
  assert.equal(await page.getByRole("button", { name: "Rođendani i proslave" }).getAttribute("aria-pressed"), "true");
  await page.context().close();
});

test("15. lightbox works with images (keyboard, caption, focus return)", async () => {
  const page = await site();
  await open(page);
  const first = page.locator('.g-link[data-title="Foto 1"]');
  await first.focus();
  await page.keyboard.press("Enter");
  const dlg = page.locator("#lightbox");
  await dlg.waitFor();
  assert.equal(await dlg.locator(".lb-counter").textContent(), "4 / 17");
  assert.equal(await dlg.locator(".lb-caption strong").textContent(), "Foto 1");
  assert.equal(await dlg.locator(".lb-desc").textContent(), "Opis 1");
  assert.match(await dlg.locator(".lb-img").getAttribute("src"), /mladenci-pejzaz\.jpg/);
  await page.keyboard.press("ArrowRight");
  assert.equal(await dlg.locator(".lb-counter").textContent(), "5 / 17");
  await page.keyboard.press("ArrowLeft");
  await page.keyboard.press("Escape");
  await dlg.waitFor({ state: "hidden" });
  assert.equal(await page.evaluate(() => document.activeElement.dataset.title), "Foto 1", "focus returns to the opener");
  await page.context().close();
});

test("16. video playback: native player for files, sandboxed embed for YouTube, no autoplay", async () => {
  const page = await site();
  await open(page);
  await page.locator('.g-link[data-title="Zdravica video"]').click();
  const video = page.locator("#lightbox video");
  await video.waitFor();
  assert.equal(await video.getAttribute("controls"), "");
  assert.equal(await video.evaluate((v) => v.paused && !v.autoplay), true, "not autoplaying");
  await video.evaluate((v) => { v.muted = true; return v.play(); });
  await page.waitForFunction(() => document.querySelector("#lightbox video").currentTime > 0.5, null, { timeout: 15000 });

  await page.keyboard.press("Escape"); // focus is on the dialog close button, so Escape closes
  await page.locator("#lightbox").waitFor({ state: "hidden" });
  // the dialog "close" event is dispatched asynchronously
  await page.waitForFunction(() => !document.querySelector("#lightbox video"), null, { timeout: 5000 });

  await page.locator('.g-link[data-title="YouTube spot"]').click();
  const frame = page.locator("#lightbox iframe");
  await frame.waitFor();
  assert.equal(await frame.getAttribute("src"), "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ?rel=0");
  assert.equal(await frame.getAttribute("sandbox"), "allow-scripts allow-same-origin allow-presentation allow-popups");
  assert.ok(!(await frame.getAttribute("src")).includes("autoplay"));

  // navigating replaces the player
  await page.locator("#lightbox .lb-next").click();
  assert.equal(await page.locator("#lightbox iframe").count(), 0);
  // a broken video shows a message and does not break the gallery
  await page.waitForFunction(() => /ne može da se pusti/.test(document.querySelector("#lightbox .lb-stage").textContent), null, { timeout: 15000 });
  await page.locator("#lightbox .lb-next").click();
  assert.equal(await page.locator("#lightbox .lb-counter").textContent(), "4 / 17");
  await page.context().close();
});

test("17. mobile layout (390×844): public site and admin", async () => {
  const page = await site({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  await open(page);
  assert.ok(await noHorizontalScroll(page), "no horizontal scroll on the website");
  const cols = await page.locator(".gallery").evaluate((g) => getComputedStyle(g).columnCount);
  assert.equal(cols, "2");
  await page.locator('.g-link[data-title="Foto 1"]').tap();
  await page.locator("#lightbox .lb-img").waitFor();
  await page.locator("#lightbox .lb-close").tap();
  await page.locator("#radovi").screenshot({ path: "tests/report/mobile-gallery.png" });

  const admin = await newPage(browser, { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  await login(admin);
  await admin.locator(".stats").waitFor();
  assert.ok(await noHorizontalScroll(admin), "no horizontal scroll in admin");
  assert.equal(await admin.locator(".sidebar").isVisible(), false, "navigation collapsed");
  await admin.getByRole("button", { name: "Meni" }).tap();
  await admin.getByRole("link", { name: "Galerija" }).tap();
  await admin.locator(".mcard").first().waitFor();
  assert.ok(await noHorizontalScroll(admin));
  await admin.waitForTimeout(400); // let the menu finish closing
  await admin.screenshot({ path: "tests/report/mobile-admin-gallery.png" });
  await admin.goto(SITE + "/admin/#/dodaj-fotografije");
  await admin.reload();
  await admin.locator(".dropzone").waitFor();
  assert.ok(await noHorizontalScroll(admin));
  const btn = await admin.getByRole("button", { name: "Objavi" }).boundingBox();
  assert.ok(btn.height >= 44, "touch target ≥ 44px");
  await admin.screenshot({ path: "tests/report/mobile-admin-add.png", fullPage: true });
  await page.context().close();
  await admin.context().close();
});

test("19. website stays functional when the CMS API is unavailable", async () => {
  // a) first visit, API down: built-in photos, filters and lightbox keep working, no error banner
  const page = await site();
  await page.context().route(API + "/**", (r) => r.abort("connectionfailed"));
  await page.goto(SITE + "/#radovi");
  await page.waitForFunction(() => !document.documentElement.classList.contains("cms-pending"), null, { timeout: 15000 });
  assert.equal(await page.locator(".gallery .g-item").count(), 42, "built-in gallery");
  assert.equal(await page.locator("[data-gallery-error]").isHidden(), true);
  assert.equal(await page.locator(".stock-note").isVisible(), true, "illustrative notice stays with built-in photos");
  await page.getByRole("button", { name: "Detalji" }).click();
  assert.ok((await visibleItems(page).count()) > 0);
  await visibleItems(page).first().locator(".g-link").click();
  await page.locator("#lightbox .lb-img").waitFor();
  await page.context().close();

  // b) returning visitor, API down: last good CMS content from the browser cache
  const ctx = await browser.newContext();
  const p2 = await ctx.newPage();
  await p2.goto(SITE + "/#radovi");
  await p2.waitForFunction(() => !document.documentElement.classList.contains("cms-pending"));
  await ctx.route(API + "/**", (r) => r.abort("connectionfailed"));
  await p2.reload();
  await p2.waitForFunction(() => !document.documentElement.classList.contains("cms-pending"), null, { timeout: 15000 });
  assert.equal(await p2.locator(".gallery .g-item").count(), 17, "cached CMS gallery");
  await ctx.close();

  // c) the built-in photos are hidden for at most ~4 s while waiting (CSS fail-safe)
  const p3 = await site();
  await p3.context().route(API + "/**", () => {}); // never answers
  await p3.goto(SITE + "/#radovi");
  await p3.waitForTimeout(4600);
  const op = await p3.locator(".gallery .g-item img").first().evaluate((i) => getComputedStyle(i).opacity);
  assert.equal(op, "1");
  await p3.context().close();
});

test("fallback: no published media → built-in photos; fallback disabled → empty-state message", async () => {
  sql("update media_assets set is_published = false");
  const page = await site();
  await open(page);
  assert.equal(await page.locator(".gallery .g-item").count(), 42);
  sql("update site_settings set fallback_enabled = false");
  await page.evaluate(() => localStorage.clear());
  await open(page);
  assert.equal(await page.locator(".gallery .g-item").count(), 0);
  assert.match(await page.locator("[data-gallery-empty]").textContent(), /Uskoro ovde objavljujemo/);
  await page.context().close();
  sql("update site_settings set fallback_enabled = true; update media_assets set is_published = true where title <> 'Nacrt'");
});

test("hidden category disappears from the website with its items", async () => {
  sql("update categories set is_visible = false where slug = 'detalji'");
  const page = await site();
  await open(page);
  assert.ok(!(await page.locator("[data-filters] .chip").allTextContents()).includes("Detalji"));
  assert.equal(await page.locator('.g-item[data-cat="detalji"]').count(), 0);
  await page.context().close();
  sql("update categories set is_visible = true");
});

test("CMS text is rendered as text (XSS) and unsafe URLs are dropped", async () => {
  const payload = `<img src=x onerror="window.__xss=1">"><script>window.__xss=2</script>`;
  sql(`insert into media_assets (title, description, alt_text, media_type, category_id, source_type, source_url, is_published, sort_order)
       values ($$${payload}$$, $$${payload}$$, $$${payload}$$, 'image', '${cat("vencanja")}', 'external', '${F}detalj-portret.png', true, -100)`);
  sql(`update categories set description = $$${payload}$$ where slug = 'vencanja'`);
  const page = await site();
  await open(page);
  const link = page.locator(".gallery .g-link").first();
  assert.equal(await link.getAttribute("data-title"), payload);
  await page.getByRole("button", { name: "Venčanja" }).click();
  await link.click();
  await page.locator("#lightbox .lb-caption strong").waitFor();
  assert.equal(await page.locator("#lightbox .lb-caption strong").textContent(), payload);
  assert.equal(await page.evaluate(() => window.__xss), undefined);
  assert.equal(await page.locator(".lb-caption img, .lb-caption script, [data-cat-desc] img").count(), 0);

  // admin renders the same payload safely too
  const admin = await newPage(browser);
  await login(admin);
  await admin.locator(".stats").waitFor();
  await admin.goto(SITE + "/admin/#/galerija");
  await admin.locator(".mcard").first().waitFor();
  assert.equal(await admin.evaluate(() => window.__xss), undefined);
  await admin.context().close();
  await page.context().close();
  sql(`delete from media_assets where sort_order = -100; update categories set description = null`);
});

test("Content Security Policy: no violations on the website or the admin", async () => {
  const page = await site();
  const violations = [];
  await page.exposeFunction("__cspv", (v) => violations.push(v));
  await page.addInitScript(() => document.addEventListener("securitypolicyviolation", (e) => window.__cspv(e.violatedDirective + " " + e.blockedURI)));
  await open(page);
  await page.locator('.g-link[data-title="YouTube spot"]').click();
  await page.locator("#lightbox iframe").waitFor();
  await page.keyboard.press("Escape");
  const admin = await newPage(browser);
  await admin.exposeFunction("__cspv", (v) => violations.push("admin: " + v));
  await admin.addInitScript(() => document.addEventListener("securitypolicyviolation", (e) => window.__cspv(e.violatedDirective + " " + e.blockedURI)));
  await login(admin);
  await admin.locator(".stats").waitFor();
  for (const r of ["galerija", "dodaj-fotografije", "dodaj-video", "kategorije", "podesavanja"]) {
    await admin.goto(SITE + "/admin/#/" + r);
    await admin.waitForTimeout(600);
  }
  assert.deepEqual(violations, []);
  await page.context().close();
  await admin.context().close();
});
