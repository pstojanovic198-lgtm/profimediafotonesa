/* Profi Media – Foto Neša: gallery content from the CMS.

   Loads published media from Supabase (one request: rpc/public_gallery) and
   rebuilds the gallery list + category filters. Rendering uses DOM APIs only
   (never innerHTML) and re-validates every URL and embed before use.

   Reliability
   - No config / script errors          → the built-in photos stay (static HTML).
   - Last good response is kept in localStorage and shown instantly on the
     next visit, then refreshed in the background.
   - Network failure: 2 retries (1 s, 3 s). If nothing can be shown, an error
     message with a "Pokušaj ponovo" button appears; otherwise the built-in or
     cached gallery stays and the problem is only logged.
   - CSS hides the built-in photos for at most 4 s while loading (see
     .cms-pending in index.html), so a failure can never leave a blank gallery. */

import { isSafeUrl, isAllowedEmbed, safeVariants, toSrcset } from "./media-safety.js";

const root = document.documentElement;
const cfg = window.PMFN_CMS || {};
const list = document.querySelector("[data-gallery]");
const CACHE_KEY = "pmfn-gallery-v1";
const CACHE_MAX_AGE = 7 * 24 * 3600 * 1000;
const SIZES = "(min-width: 1200px) 288px, (min-width: 600px) 30vw, 46vw";

function finish() {
  root.classList.remove("cms-pending");
  if (list) list.removeAttribute("aria-busy");
}

function api() {
  return window.pmfnGallery || null; // exposed by the inline page script
}

/* ---------------- cache ---------------- */
function readCache() {
  try {
    const c = JSON.parse(localStorage.getItem(CACHE_KEY) || "null");
    return c && Date.now() - c.t < CACHE_MAX_AGE && c.data ? c : null;
  } catch {
    return null;
  }
}
function writeCache(data) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({ t: Date.now(), data }));
  } catch {
    /* private mode / quota: fine */
  }
}

/* ---------------- fetch ---------------- */
async function fetchGallery() {
  const url = cfg.supabaseUrl.replace(/\/+$/, "") + "/rest/v1/rpc/public_gallery";
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(url, {
      headers: { apikey: cfg.supabaseAnonKey, accept: "application/json" },
      credentials: "omit",
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    if (!data || !Array.isArray(data.items) || !Array.isArray(data.categories)) throw new Error("Neočekivan odgovor");
    return data;
  } finally {
    clearTimeout(t);
  }
}

async function fetchWithRetry() {
  const waits = [0, 1000, 3000];
  let last;
  for (const w of waits) {
    if (w) await new Promise((r) => setTimeout(r, w));
    try {
      return await fetchGallery();
    } catch (e) {
      last = e;
    }
  }
  throw last;
}

/* ---------------- rendering ---------------- */
const SVG_NS = "http://www.w3.org/2000/svg";
function useIcon(id, cls) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("class", cls);
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("focusable", "false");
  const u = document.createElementNS(SVG_NS, "use");
  u.setAttribute("href", "#" + id);
  svg.append(u);
  return svg;
}

function el(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) if (v !== null && v !== undefined && v !== false) e.setAttribute(k, String(v));
  for (const k of kids) if (k) e.append(k);
  return e;
}

function placeholder(w, h) {
  const ph = el("span", { class: "g-ph", "aria-hidden": "true" }, useIcon("i-video", "icon"));
  ph.style.aspectRatio = `${w} / ${h}`; // CSSOM: allowed by the CSP
  return ph;
}

/** One gallery tile. Returns null for items that cannot be shown safely. */
export function buildItem(m) {
  if (!m || typeof m.category !== "string" || !/^[a-z0-9-]{2,40}$/.test(m.category)) return null;
  const variants = safeVariants(m.variants);
  const w = Math.max(1, Math.min(30000, +m.width || 0)) || null;
  const h = Math.max(1, Math.min(30000, +m.height || 0)) || null;
  const title = String(m.title || "").slice(0, 140);
  const alt = String(m.alt_text || m.title || "").slice(0, 250);
  const desc = String(m.description || "").slice(0, 1000);
  const li = el("li", { class: "g-item", "data-cat": m.category });

  if (m.media_type === "image") {
    const full = variants.length ? variants[variants.length - 1].url : m.source_url;
    if (!isSafeUrl(full)) return null;
    const thumbs = variants.filter((v) => v.w <= 960);
    const thumb = (thumbs[0] || variants[0] || {}).url || (isSafeUrl(m.thumbnail_url) ? m.thumbnail_url : full);
    const ratioW = w || 4, ratioH = h || 3;
    const a = el("a", {
      class: "g-link",
      href: full,
      "data-kind": "image",
      "data-large": full,
      "data-large-srcset": variants.length ? toSrcset(variants) : null,
      "data-w": ratioW,
      "data-h": ratioH,
      "data-alt": alt,
      "data-title": title,
      "data-desc": desc || null,
    });
    const img = el("img", {
      src: thumb,
      srcset: thumbs.length > 1 ? toSrcset(thumbs) : null,
      sizes: thumbs.length > 1 ? SIZES : null,
      width: 540,
      height: Math.round((540 * ratioH) / ratioW),
      alt,
      loading: "lazy",
      decoding: "async",
    });
    img.addEventListener("error", () => img.replaceWith(placeholder(ratioW, ratioH)), { once: true });
    a.append(img, el("span", { class: "g-zoom", "aria-hidden": "true" }, useIcon("i-zoom", "icon")));
    li.append(a);
    return li;
  }

  if (m.media_type !== "video") return null;
  const embed = m.embed_url && isAllowedEmbed(m.embed_url) ? m.embed_url : null;
  const direct = !embed && isSafeUrl(m.source_url) ? m.source_url : null;
  if (!embed && !direct) return null;
  const href = isSafeUrl(m.source_url) ? m.source_url : embed;
  const ratioW = w || 16, ratioH = h || 9;
  const poster = isSafeUrl(m.poster_url) ? m.poster_url : null;
  const posterThumbs = variants.filter((v) => v.w <= 960);
  const thumb = (posterThumbs[0] || {}).url || (isSafeUrl(m.thumbnail_url) ? m.thumbnail_url : poster);
  const a = el("a", {
    class: "g-link g-link--video",
    href,
    "data-kind": embed ? "embed" : "video",
    "data-embed": embed,
    "data-video": direct,
    "data-mime": /^video\/(mp4|webm)$/.test(m.mime_type || "") ? m.mime_type : null,
    "data-poster": poster,
    "data-w": ratioW,
    "data-h": ratioH,
    "data-alt": alt,
    "data-title": title,
    "data-desc": desc || null,
  });
  if (thumb) {
    const img = el("img", {
      src: thumb,
      srcset: posterThumbs.length > 1 ? toSrcset(posterThumbs) : null,
      sizes: posterThumbs.length > 1 ? SIZES : null,
      width: 540,
      height: Math.round((540 * ratioH) / ratioW),
      alt: "",
      loading: "lazy",
      decoding: "async",
    });
    img.addEventListener("error", () => img.replaceWith(placeholder(ratioW, ratioH)), { once: true });
    a.append(img);
  } else a.append(placeholder(ratioW, ratioH));
  a.append(el("span", { class: "sr-only" }, document.createTextNode("Video: " + (alt || "bez naziva"))));
  a.append(el("span", { class: "g-play", "aria-hidden": "true" }, useIcon("i-play", "icon")));
  li.append(a);
  return li;
}

function buildFilters(categories, items) {
  const used = new Set(items.map((i) => i.getAttribute("data-cat")));
  const chips = [el("button", { class: "chip", type: "button", "data-filter": "sve", "aria-pressed": "true" }, document.createTextNode("Sve"))];
  for (const c of categories) {
    if (!used.has(c.slug) || !/^[a-z0-9-]{2,40}$/.test(c.slug)) continue;
    chips.push(
      el(
        "button",
        { class: "chip", type: "button", "data-filter": c.slug, "aria-pressed": "false", "data-desc": c.description ? String(c.description).slice(0, 500) : null },
        document.createTextNode(String(c.name).slice(0, 60)),
      ),
    );
  }
  return chips;
}

function applyNotice(settings, showingCms) {
  const note = document.querySelector(".stock-note");
  if (!note) return;
  if (!showingCms) return; // built-in illustrative photos: the notice always stays
  note.hidden = !settings?.stock_notice_enabled;
  if (settings?.stock_notice_text) {
    const span = note.querySelector("span");
    if (span) span.textContent = String(settings.stock_notice_text).slice(0, 400);
  }
}

let lastSignature = "";
function render(data) {
  const g = api();
  if (!g || !list) return false;
  const settings = data.settings || {};
  const items = data.items.map(buildItem).filter(Boolean);
  const sig = JSON.stringify(data);
  if (sig === lastSignature) return true;
  lastSignature = sig;

  if (!items.length) {
    if (settings.fallback_enabled !== false && g.hasFallback()) {
      g.restoreFallback();
      return true;
    }
    g.setItems([], [], { empty: true });
    return true;
  }
  g.setItems(items, buildFilters(data.categories, items));
  applyNotice(settings, true);
  return true;
}

function showError(retry) {
  const g = api();
  if (g && g.showError) g.showError(retry);
}

async function load({ fromRetry = false } = {}) {
  try {
    const data = await fetchWithRetry();
    writeCache(data);
    render(data);
  } catch (e) {
    console.warn("[galerija] CMS nije dostupan:", e && e.message);
    const g = api();
    if (fromRetry || !g || !g.itemCount()) showError(() => load({ fromRetry: true }));
  } finally {
    finish();
  }
}

(function start() {
  if (!list || !cfg.supabaseUrl || !cfg.supabaseAnonKey || !isSafeUrl(cfg.supabaseUrl) || !api()) return finish();
  list.setAttribute("aria-busy", "true");
  const cached = readCache();
  if (cached) {
    try {
      render(cached.data);
      finish();
    } catch {
      /* ignore a bad cache entry */
    }
  }
  load();
})();
