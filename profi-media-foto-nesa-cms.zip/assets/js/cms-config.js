/* CMS connection settings — PUBLIC values only.
   Used by the website (gallery) and by the admin panel (/admin/).

   Safe to publish:
     supabaseUrl      – the project's API URL (Supabase → Project Settings → API)
     supabaseAnonKey  – the "anon" / "publishable" key. It only grants what Row
                        Level Security allows: reading published media.
   NEVER put here: the service_role / secret key, the database password,
   the JWT secret or any storage provider secret.

   Leave supabaseUrl empty to run the site without the CMS (built-in photos). */
window.PMFN_CMS = Object.freeze({
  supabaseUrl: "",
  supabaseAnonKey: "",
  storage: Object.freeze({ provider: "supabase", bucket: "media" }),
});
