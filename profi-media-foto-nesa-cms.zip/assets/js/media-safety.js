/* Shared safety checks for CMS media URLs (public site + admin).
   Mirrors public.is_safe_url() and public.is_allowed_embed() in the database,
   so content is validated on write (DB) and again before rendering (here). */

const UNSAFE_CHARS = /[\s<>"'`\\]/;

/** https URL (or http on localhost for development), no credentials, ≤ 2048 chars. */
export function isSafeUrl(value) {
  if (typeof value !== "string" || !value || value.length > 2048 || UNSAFE_CHARS.test(value)) return false;
  let u;
  try {
    u = new URL(value);
  } catch {
    return false;
  }
  if (u.username || u.password) return false;
  if (u.protocol === "https:") return true;
  return u.protocol === "http:" && (u.hostname === "127.0.0.1" || u.hostname === "localhost");
}

const EMBED_PATTERNS = [
  /^https:\/\/www\.youtube-nocookie\.com\/embed\/[A-Za-z0-9_-]{11}(\?[A-Za-z0-9=&_-]{0,200})?$/,
  /^https:\/\/player\.vimeo\.com\/video\/[0-9]{1,12}(\?[A-Za-z0-9=&_.-]{0,200})?$/,
  /^https:\/\/drive\.google\.com\/file\/d\/[A-Za-z0-9_-]{10,100}\/preview$/,
];

/** Only these iframe sources may ever be rendered. */
export function isAllowedEmbed(value) {
  return typeof value === "string" && EMBED_PATTERNS.some((re) => re.test(value));
}

/** Variants sorted by width, unsafe entries dropped. */
export function safeVariants(list) {
  if (!Array.isArray(list)) return [];
  return list
    .filter((v) => v && Number.isFinite(+v.w) && +v.w > 0 && isSafeUrl(v.url))
    .map((v) => ({ w: Math.round(+v.w), url: v.url }))
    .sort((a, b) => a.w - b.w);
}

/** "url 480w, url 960w". Inner commas (Cloudinary "w_480,c_limit") are valid in
    srcset; only a trailing comma would be misparsed, so such URLs are skipped. */
export function toSrcset(variants) {
  return variants
    .filter((v) => !v.url.endsWith(","))
    .map((v) => `${v.url} ${v.w}w`)
    .join(", ");
}
