#!/usr/bin/env node
/* Writes the Content-Security-Policy <meta> of index.html.
   Inline <script>/<style> blocks are allowed by their SHA-256 hash, so the
   policy needs no 'unsafe-inline'. Run after editing any inline block:

     node tools/csp.mjs           # update index.html
     node tools/csp.mjs --check   # exit 1 if the policy is out of date (CI/tests)

   The Supabase origin is read from assets/js/cms-config.js; *.supabase.co is
   always allowed, a custom API domain is added automatically. */
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const FILE = join(ROOT, "index.html");
const html = readFileSync(FILE, "utf8");

const hash = (s) => "'sha256-" + createHash("sha256").update(s, "utf8").digest("base64") + "'";
const scripts = [...html.matchAll(/<script(?![^>]*\bsrc=)(?![^>]*type="application\/(?:ld\+)?json")[^>]*>([\s\S]*?)<\/script>/g)].map((m) => hash(m[1]));
const styles = [...html.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/g)].map((m) => hash(m[1]));
if (/\sstyle="/.test(html)) {
  console.error("index.html contains style=\"…\" attributes; move them to the stylesheet (CSP has no 'unsafe-inline').");
  process.exit(1);
}

let connect = ["'self'", "https://*.supabase.co"];
try {
  const cfg = readFileSync(join(ROOT, "assets/js/cms-config.js"), "utf8");
  const m = /supabaseUrl:\s*"([^"]*)"/.exec(cfg);
  if (m && m[1]) {
    const origin = new URL(m[1]).origin;
    if (!/\.supabase\.co$/.test(new URL(origin).hostname)) connect.push(origin);
  }
} catch {
  /* no config yet */
}

const policy = [
  "default-src 'self'",
  `script-src 'self' ${scripts.join(" ")}`,
  `style-src 'self' ${styles.join(" ")}`,
  "img-src 'self' https: data:",
  "media-src 'self' https:",
  "font-src 'self'",
  `connect-src ${connect.join(" ")}`,
  "frame-src https://www.youtube-nocookie.com https://player.vimeo.com https://drive.google.com",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "upgrade-insecure-requests",
].join("; ");

const re = /<meta http-equiv="Content-Security-Policy" content="[^"]*">/;
if (!re.test(html)) {
  console.error("CSP <meta> not found in index.html");
  process.exit(1);
}
const next = html.replace(re, `<meta http-equiv="Content-Security-Policy" content="${policy}">`);
if (process.argv.includes("--check")) {
  if (next !== html) {
    console.error("CSP is out of date. Run: node tools/csp.mjs");
    process.exit(1);
  }
  console.log("CSP up to date");
} else {
  writeFileSync(FILE, next);
  console.log(`CSP updated (${scripts.length} script hashes, ${styles.length} style hashes)`);
}
