# Test report

Date: 4 Nov 2026 · Result: **50 / 50 automated tests passing** (13 unit + 37 end-to-end) + CSP consistency check + accessibility scan with 0 violations.
Full log: `tests/report/results.txt`. Screenshots: `tests/report/*.png`.

## How it was tested

No mock backend. The suite runs against a **local Supabase-compatible stack built from the official open-source components**, started from an empty database using only `supabase/migrations/…cms_init.sql`:

| Component | Version | Role |
|---|---|---|
| PostgreSQL | 16 | database, RLS, constraints, RPCs |
| PostgREST | 12.2.3 | REST API used by supabase-js |
| Supabase Auth (GoTrue) | 2.180.0 | login, sessions, logout, signup disabled |
| Supabase Storage API | 1.40.0 (file backend) | uploads, TUS resumable uploads, public URLs, RLS |
| `tests/stack/gateway.mjs` | — | stands in for Supabase's Kong gateway (routing, apikey, CORS) |
| Chromium (Playwright) | bundled | real browser for admin + website |

The website and admin are served by `tests/serve.mjs`, which only (a) injects local connection values into `cms-config.js` and (b) adds the local `http://127.0.0.1:54321` origin to the CSP. The real CSP is otherwise enforced during all browser tests.

Re-run everything: `STACK_DIR=… bash tests/run-all.sh` (see `docs/DEPLOYMENT.md`).

## Required scenarios

| # | Requirement | Test | Result |
|---|---|---|---|
| 1 | Administrator can log in | `02-admin` "1." | ✅ |
| 2 | Unauthorized visitors cannot access admin functions | `02-admin` "2." (no session → login only; wrong password; valid non-admin account rejected) + `01-security` | ✅ |
| 3 | Upload an image | `02-admin` "3." — 2 files, 480/960/1920 WebP variants + original stored, files reachable, alt-text rule enforced in UI | ✅ |
| 4 | Upload a video | `02-admin` "4." (poster frame auto-generated, dimensions/duration stored), "4b." **TUS resumable upload** of a 10 MB file in 6 MB chunks, "4c." cancel during upload | ✅ |
| 5 | Add external image URL | `02-admin` "5." — original link kept, thumbnails generated (CORS host) | ✅ |
| 6 | Add direct video URL | `02-admin` "6." — metadata read, poster captured | ✅ |
| 7 | Embed YouTube | `02-admin` "7." — `youtu.be` share link → `youtube-nocookie.com/embed/…`, sandboxed preview | ✅ * |
| 8 | Edit media | `02-admin` "8 & 9." | ✅ |
| 9 | Change categories | `02-admin` "8 & 9." (editor + bulk move) and "categories" test | ✅ |
| 10 | Reorder media | `02-admin` "10." — keyboard (arrow keys on handle) **and** mouse drag-and-drop; DB order = UI order = website order | ✅ |
| 11 | Publish / unpublish | `02-admin` "11." (card toggle + bulk), verified in the public API | ✅ |
| 12 | Delete media | `02-admin` "12." — confirm dialog (safe default focus), trash, restore, permanent delete removes storage files | ✅ |
| 13 | New published media appears on the website | `02-admin` "13." | ✅ |
| 14 | Existing gallery filters work | `03-public` "14." — chips, `aria-pressed`, "Prikaži još", `data-filter-link` from service cards | ✅ |
| 15 | Lightbox with images | `03-public` "15." — keyboard open, arrows, caption, Esc, focus return | ✅ |
| 16 | Video playback | `03-public` "16." — native `<video controls>`, not autoplaying, plays; YouTube iframe sandboxed; player removed on close/navigation; broken video shows a message | ✅ * |
| 17 | Mobile layout | `03-public` "17." — 390×844 touch emulation: no horizontal scroll (site + admin), 2-column gallery, tap lightbox, collapsible admin menu, ≥ 44 px touch targets | ✅ |
| 18 | Invalid URLs → useful errors | `02-admin` "18." (Instagram, Dropbox folder, Google Photos, http, 404 image, wrong media type) + 13 unit tests in `tests/unit/media-url.test.mjs` | ✅ |
| 19 | Site works when CMS API is unavailable | `03-public` "19." — first visit (built-in gallery, filters, lightbox work, no error banner), returning visit (cached CMS gallery), API that never answers (CSS fail-safe reveals photos after 4 s) | ✅ |
| 20 | Public visitors cannot perform admin operations | `01-security` — anon and non-admin users cannot insert/update/delete/reorder, change settings or categories, self-promote to admin, upload via simple or resumable upload; drafts invisible; signup disabled; logout revokes refresh token | ✅ |

\* YouTube is unreachable from the test sandbox, so its thumbnail and player page were answered with local stubs. The app logic (URL normalisation, stored embed URL, sandboxed iframe, no autoplay) is tested; actual YouTube playback was not.

## Additional checks

| Check | Result |
|---|---|
| Database rejects `javascript:` URLs, plain http URLs, non-allow-listed embeds, published photos without alt text, slug changes — even from an admin | ✅ `01-security` |
| No service-role/secret key in shipped files | ✅ `01-security` |
| XSS: HTML/script payload in title, description, alt text and category description rendered as text on the website and in the admin | ✅ `03-public` |
| Content-Security-Policy: no violations on the website (incl. opening a YouTube embed) or any admin page | ✅ `03-public` |
| CSP hashes match inline code | ✅ `node tools/csp.mjs --check` |
| Fallback: no published media → built-in illustrative photos + notice; fallback disabled → empty-state message | ✅ |
| Hidden category removes its chip and items from the website | ✅ |
| Accessibility scan (axe-core 4.10, WCAG 2.0/2.1/2.2 A+AA rules): website, admin login, Pregled, Galerija, Dodaj fotografije, Dodaj video, Kategorije, Podešavanja | ✅ 0 violations (manual check) |
| Migration is idempotent (run twice) | ✅ |

## Bugs found and fixed by testing

1. PostgreSQL limits regex repetition counts to 255 — the `storage_path` constraint (`{0,299}`) rejected every insert. Fixed in the migration.
2. Cancelling an upload before its first byte left it hanging (an aborted-before-send XHR fires no event). Fixed.
3. Changing a gallery filter while a list was loading was ignored. Requests now supersede each other.
4. Drag-and-drop reordering stopped after the first move (moving the card in the DOM released pointer capture). Fixed with document-level pointer listeners.
5. Gateway/test-harness issues (CORS headers, stale processes) — test infrastructure only.

## Not covered (honest limits)

* **Real Supabase cloud** was not used (no credentials available). The same open-source components were used locally; dashboard settings (signup off, SMTP, plan limits) must be checked in production with the 10-minute checklist in `docs/DEPLOYMENT.md` §8.
* **Browsers**: only Chromium. Firefox and Safari (desktop + iOS) were not tested. Playwright's Chromium cannot decode H.264, so the MP4 test file uses VP9 in an MP4 container; regular Chrome/Safari/Edge play H.264 MP4.
* **External providers live**: YouTube (stubbed), Vimeo oEmbed, Google Drive, Dropbox, Cloudinary, ImageKit — URL normalisation is unit-tested; real fetching/playback from those hosts was not.
* **Password-reset e-mail**: UI and API calls implemented; the e-mail round trip was not tested (no SMTP in the sandbox).
* **Resume after page reload / after a dropped connection** (TUS): implemented (HEAD-offset resync, 4 retries with back-off, 24 h resume key); chunked upload and cancel are tested, network interruption and cross-reload resume are not.
* **Real touch devices / screen readers**: emulated mobile viewport and automated a11y rules only.
* **Performance**: no Lighthouse run. Public CMS script is ~4.7 KB gzipped, loads after first paint (module), one API request; images are lazy-loaded WebP renditions.
* Tests within a file are order-dependent (they build on each other's data); run whole files.
