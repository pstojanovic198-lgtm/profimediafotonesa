# Uputstvo za administraciju sajta — Profi Media – Foto Neša

Administracija radi u pregledaču, na računaru, tabletu i telefonu. Ne treba vam GitHub, programer niti bilo kakav program.

**Adresa:** `https://VAŠ-SAJT/admin/`
Sačuvajte je u obeleživače (bookmark).

---

## Prijava

1. Otvorite adresu administracije.
2. Upišite e-mail i lozinku → **Prijavi se**.
3. Zaboravljena lozinka: **Zaboravili ste lozinku?** → upišite e-mail → otvorite link iz e-maila (proverite i „Spam”) → postavite novu lozinku.
4. Kada završite, kliknite **Odjava** (posebno na tuđem ili zajedničkom računaru).

## Pregled (početna strana)

Prikazuje koliko imate fotografija i video snimaka, šta je objavljeno, šta je nacrt, poslednje dodato i broj stavki po kategorijama. Odatle jednim klikom idete na **Dodaj fotografije** ili **Dodaj video**.

## Dodavanje fotografija

1. Meni → **Dodaj fotografije**.
2. Izaberite izvor:
   * **Otpremi fajlove** — prevucite fotografije u označeno polje ili kliknite na njega i izaberite ih (može više odjednom). Na telefonu možete izabrati iz galerije.
   * **Link do fotografije** — nalepite link do fotografije koja je već na internetu (Dropbox, Google Drive, Cloudinary…). Najlakše: desni klik na fotografiju → „Kopiraj adresu slike”. Može više linkova, svaki u novom redu. Zatim **Dodaj link**.
3. Desno izaberite **Kategoriju** (npr. Venčanja). Za pojedinačnu fotografiju možete izabrati drugu.
4. Za svaku fotografiju:
   * **Naziv** — popunjen je iz imena fajla; prepravite ga (npr. „Venčanje Ana i Marko, Despotovac”).
   * **Opis** — neobavezno; prikazuje se ispod fotografije kad je posetilac uveća.
   * **Alternativni tekst** — obavezno za objavu. Jednom rečenicom opišite šta se vidi, npr. „Mladenci ispred crkve u Despotovcu”. Koriste ga slabovidi posetioci i Google.
5. **Pregled** — vidite kako će fotografija izgledati na sajtu.
6. Kliknite **Objavi** (odmah vidljivo na sajtu) ili **Sačuvaj kao nacrt** (vidljivo samo vama).

Tokom otpremanja vidite traku napretka. **Otkaži** prekida otpremanje. Ako se nešto ne uspe, piše zašto, a **Pokušaj ponovo** ponavlja samo tu stavku.

Podržano: JPG, PNG, WebP, AVIF. iPhone HEIC fotografije pošaljite kao JPG (iPhone: Podešavanja → Kamera → Formati → *Najkompatibilniji*).

## Dodavanje videa

1. Meni → **Dodaj video**.
2. Izvor:
   * **Otpremi video** — MP4 ili WebM fajl. Veliki fajl se šalje u delovima: ako se internet prekine, nastavlja se odakle je stao (i posle osvežavanja stranice, u roku od 24 sata — samo ponovo izaberite isti fajl).
   * **Link do video fajla** — direktan link do MP4/WebM fajla ili Google Drive video podeljen sa „Svako ko ima link”.
   * **YouTube** — na YouTube-u kliknite **Podeli → Kopiraj** i nalepite. Radi i za *Shorts* i za neizlistane (unlisted) video snimke.
   * **Vimeo** — kliknite **Share** i kopirajte link.
3. Upišite **Naziv** (i po želji **Opis**).
4. **Naslovna slika** — neobavezno. Ako je ne izaberete, koristi se kadar iz videa ili sličica sa YouTube-a/Vimeo-a.
5. **Pregled**, pa **Objavi** ili **Sačuvaj kao nacrt**.

Video se na sajtu nikada ne pušta sam — posetilac klikne na njega.

**Savet:** dugačke video snimke (preko ~50 MB) postavite na YouTube ili Vimeo i dodajte link — brže se učitavaju i ne troše prostor sajta.

### Linkovi koji ne rade (i šta umesto njih)

| Link | Zašto | Rešenje |
|---|---|---|
| Instagram, Facebook, TikTok | ne mogu se ugraditi bez njihovog praćenja posetilaca | YouTube/Vimeo ili otpremite fajl |
| Google Photos album | vodi na stranicu, ne na fajl | preuzmite i otpremite, ili Google Drive/Dropbox |
| OneDrive, iCloud | vodi na stranicu za preuzimanje | preuzmite i otpremite |
| Folder (Drive/Dropbox) | folder nije jedna fotografija | podelite pojedinačan fajl |
| Privatan fajl | posetioci ga ne mogu otvoriti | podelite sa „Svako ko ima link” |

Administracija vam to piše odmah, pre objave.

## Galerija — uređivanje postojećih radova

Meni → **Galerija**. Redosled ovde je **isti kao na sajtu**.

* **Pretraga i filteri**: po nazivu/opisu, kategoriji, statusu (Objavljeno, Nacrti, Korpa) i vrsti.
* **Uredi**: menjate naziv, opis, alternativni tekst, kategoriju, naslovnu sliku videa i da li je objavljeno.
* **Oko (Objavi / Povuci sa sajta)**: brzo sakrijte ili prikažite stavku, bez brisanja.
* **Pregled**: kako izgleda na sajtu.
* **Promena redosleda**: uhvatite ručicu (tačkice u gornjem desnom uglu kartice) i prevucite. Na tastaturi: kliknite ručicu i koristite strelice. Redosled se čuva odmah.
* **Više stavki odjednom**: označite kvadratiće (ili *Izaberi sve prikazano*). Pojavljuje se traka: **Objavi**, **Povuci sa sajta**, **Premesti u…** (kategoriju), **Obriši**.

### Brisanje i vraćanje

* **Obriši** → stavka ide u **Korpu** i nestaje sa sajta.
* Galerija → Status: **Korpa** → **Vrati** (vraća se kao nacrt; objavite je ponovo) ili **Obriši trajno** (briše i fajlove — ne može se poništiti).

## Kategorije

Meni → **Kategorije**. Kategorije su dugmad (filteri) iznad galerije na sajtu.

* **Nova kategorija** — upišite naziv (npr. „Krštenja”); identifikator se popunjava sam.
* **Uredi** — promenite naziv i opis (opis se prikazuje ispod filtera kad ga posetilac izabere).
* **Strelice gore/dole** — redosled filtera na sajtu.
* **Na sajtu** (prekidač) — sakrijte kategoriju zajedno sa njenim radovima, bez brisanja.
* **Obriši** — moguće samo za praznu kategoriju (prvo premestite radove).

Na sajtu se prikazuju samo vidljive kategorije koje imaju bar jedan objavljen rad.

## Podešavanja

* **Napomena o ilustrativnim fotografijama** — dok se na sajtu nalaze fotografije sa Unsplash-a, napomena mora ostati. Isključite je kada objavite samo svoje prave radove.
* **Ilustrativne fotografije dok nema objava** — dok niste objavili nijedan rad, sajt prikazuje ugrađene ilustrativne fotografije.
* **Ograničenja otpremanja** — najveća fotografija i video (MB).
* **Čuvaj originalne fotografije** — rezervna kopija originala.
* **Lozinka** — promena lozinke.

## Česta pitanja

**Objavio/la sam, a ne vidim na sajtu?** Osvežite stranicu sajta. Proverite da je stavka *Objavljeno* i da kategorija nije sakrivena.

**Piše „Sesija je istekla”.** Prijavite se ponovo.

**Piše „Fajl je veći od dozvoljenog”.** Smanjite fajl ili video postavite na YouTube/Vimeo. Ograničenje servera na besplatnom planu je 50 MB po fajlu.

**Sajt radi i kad administracija ne radi?** Da. Ako server privremeno nije dostupan, sajt prikazuje poslednju sačuvanu galeriju.

**Koliko je bezbedno?** Samo nalozi koje je odobrio održavalac sajta mogu da menjaju sadržaj — proverava to server, ne samo stranica. Ne delite lozinku; za drugu osobu tražite poseban nalog.
