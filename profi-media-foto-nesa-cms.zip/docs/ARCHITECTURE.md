# Architecture

## 1. Starting point (Phase 1 inspection)

| Area | What was found | What changed |
|---|---|---|
| Page | One static `index.html` (≈170 KB) with all CSS in one inline `<style>` and two inline scripts (pre-paint script in `<head>`, behaviour script at the end of `<body>`). Serbian Latin, `lang="sr-Latn"`. | Kept. Only additions: CSP meta, two deferred scripts, three gallery hooks (`data-cat-desc`, `data-gallery-empty`, `data-gallery-error`), one icon, ~20 CSS rules. |
| Gallery | 42 hard-coded `<li class="g-item" data-cat="…">` with `<a class="g-link" data-large data-w data-h data-alt data-author…>`; CSS multi-column masonry (2/3/4 columns); 12 items per page; "Prikaži još"; chips with `data-filter` = `vencanja`, `detalji`, `proslave`, `video`; service cards link to filters via `data-filter-link`. | Same markup and classes for CMS items, so all existing CSS and behaviour apply. The 42 items stay in the HTML as the no-JS / no-CMS fallback. |
| Lightbox | Native `<dialog>`: Esc, arrow keys, swipe, focus return, exact `sizes` computation, next-image preload, Unsplash credits. | Extended in place: also plays MP4/WebM (`<video controls>`, never autoplay) and allow-listed embeds (sandboxed `<iframe>`); caption built with DOM APIs instead of `innerHTML`. |
| Assets | Local fonts (Young Serif, Hanken Grotesk), WebP images in 480 px + ~1400 px renditions. | CMS uploads follow the same idea: 480/960/1920 px WebP renditions are generated on upload. |
| Hosting | GitHub Pages demo; no backend. | Still a plain static site; deployable anywhere. |

## 2. Decision: Supabase (recommended solution)

The site is static and must stay host-independent, so the CMS needs a managed backend that the browser can talk to directly and securely.

**Supabase** gives, in one free-tier-friendly service: Postgres with Row Level Security (authorization enforced by the database), Auth (e-mail + password, password reset, signup can be disabled), Storage with resumable (TUS) uploads and public CDN URLs, and an auto-generated REST API. No server code had to be written or hosted.

Alternatives considered:

| Option | Why not chosen |
|---|---|
| Decap/Netlify CMS, Tina | Commit media into the git repo and trigger rebuilds — explicitly forbidden by the brief (no GitHub, no redeploys, no media in the repo). |
| Sanity / Contentful | Capable, but a second proprietary editing UI the owner must learn, per-seat/asset limits, and still needs custom gallery integration. |
| Custom Node/PHP API | More code to host, patch and secure for a one-person business. |
| Cloudinary as the only store | Excellent media CDN, but no database/auth for drafts, ordering and categories; unsigned uploads would be insecure without a server. |

## 3. Components

```
Browser (visitor)                      Browser (administrator, /admin/)
  index.html (static)                    admin SPA (vanilla JS modules, no build)
   └ assets/js/gallery-cms.js             ├ supabase-js 2.118.0 (vendored, no CDN)
        │ GET rpc/public_gallery          ├ storage/ provider abstraction (Supabase + TUS)
        ▼  (anon key, RLS)                └ media-url.js link analysis, media-process.js resizing
  ┌──────────────── Supabase ─────────────────┐
  │ Postgres + RLS: categories, media_assets, │
  │   site_settings, admin_users              │
  │ Auth (signup disabled)                    │
  │ Storage bucket "media" (public read,      │
  │   admin-only write, TUS)                  │
  └───────────────────────────────────────────┘
External media (YouTube, Vimeo, Drive, Dropbox, Cloudinary, any https URL)
  → loaded by browsers directly; never fetched by a server (no SSRF surface).
```

## 4. Data model (`supabase/migrations/20261104120000_cms_init.sql`)

* `categories` — `slug` (immutable, = public filter id), `name`, `description`, `sort_order`, `is_visible`. Seeded with the 4 existing categories.
* `media_assets` — the suggested structure plus `provider`, `mime_type`, `width`, `height`, `duration_seconds`, `file_size_bytes`, `variants` (responsive renditions), `published_at`, `created_by`. Soft delete via `deleted_at` (trash).
* `site_settings` — single row: illustrative-photo notice on/off + text, fallback on/off, upload limits, keep originals.
* `admin_users` — who is an administrator. Writable only from the SQL editor.
* View `gallery_items` and RPC `public_gallery()` — the only read model for visitors (one request).
* RPCs `reorder_media`, `reorder_categories`, `dashboard_stats` — `SECURITY INVOKER` plus explicit `is_admin()` check.

Database constraints validate URLs (`https` only, no quotes/whitespace), allow-list embed URLs (YouTube-nocookie, Vimeo player, Drive preview), require alt text for published photos, and keep slugs immutable — so even a compromised admin session cannot store a `javascript:` URL or an arbitrary iframe.

## 5. Media pipeline

| Source | Stored as | Thumbnails |
|---|---|---|
| Uploaded photo (JPG/PNG/WebP/AVIF) | original (optional) + WebP 480/960/1920 in `media/{yyyy}/{mm}/{uuid}/` | generated in the admin's browser (EXIF orientation applied) — works on the free plan, no image service needed |
| Uploaded video (MP4/WebM) | file via TUS (6 MB chunks, auto-retry, resumable after reload for 24 h) | poster frame captured automatically or chosen by the admin |
| Image link | the normalised link itself | Cloudinary/ImageKit/Unsplash transformation URLs; otherwise built and uploaded if the host allows CORS; otherwise the original |
| Video file link | the link | poster captured if CORS allows, or uploaded by admin |
| YouTube / Vimeo / Drive | allow-listed embed URL | YouTube `i.ytimg.com`, Vimeo oEmbed, Drive thumbnail, or uploaded poster |

Link handling rules: any public https host is accepted (no domain list); sharing pages (Google Photos, OneDrive, Instagram, folders…) are rejected with an explanation and an alternative. See `admin/js/media-url.js` and its unit tests.

## 6. Public gallery integration

`gallery-cms.js` (ES module, ~10 KB uncompressed, ~4.7 KB gzipped together with media-safety.js) loads `rpc/public_gallery`, builds the same `<li class="g-item">` markup, rebuilds the filter chips (visible categories that have published items, in CMS order) and hands both to `window.pmfnGallery` exposed by the existing inline script. Filters, "Prikaži još", lightbox, keyboard and swipe therefore keep their original code paths.

Reliability: last good response cached in `localStorage` (shown instantly on the next visit, refreshed in background); 2 retries; while loading the built-in photos are shown as placeholders for at most 4 s (pure-CSS fail-safe); on failure the built-in or cached gallery stays. An error message with "Pokušaj ponovo" only appears if there is nothing to show.

Fallback rule: while **no** media is published the built-in illustrative photos and their notice remain (configurable). Once real work is published, the CMS content replaces them; the notice is then controlled in Podešavanja.

## 7. Security summary

* Authorization: RLS on every table + storage policies; `is_admin()` is `SECURITY DEFINER` with empty `search_path`; anon has column-level SELECT only on the columns the site needs.
* No secrets in the frontend: only the URL and anon/publishable key (tested automatically).
* XSS: all CMS text is inserted with `textContent`/attributes; URLs re-validated client-side before use (`media-safety.js`).
* Embeds: allow-list in DB and in both renderers; `sandbox="allow-scripts allow-same-origin allow-presentation allow-popups"`, `referrerpolicy`, no autoplay.
* CSP: website uses hashes for its inline blocks (`tools/csp.mjs`), no `unsafe-inline`; admin has `script-src 'self'` and `style-src 'self'`. Admin refuses to run framed; `_headers` adds `frame-ancestors 'none'` on hosts that support it.
* Sessions: Supabase Auth (JWT 1 h + rotating refresh token); logout revokes the refresh token server-side.
