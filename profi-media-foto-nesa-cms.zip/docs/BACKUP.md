# Backup and recovery

What needs protecting: (1) the database (media records, categories, settings, admin list) and (2) uploaded files in the Storage bucket `media`. External media (YouTube, Dropbox, Cloudinary links) live with those providers.

## Built-in safety nets

* **Trash (Korpa)**: "Obriši" only moves items to the trash; they can be restored from Galerija → Status → Korpa. Files are deleted only with "Obriši trajno" (with a confirmation).
* **Originals**: with *Čuvaj originalne fotografije* on (default), the original photo is stored next to the web versions.
* **Supabase backups**: Pro plan includes daily backups (restorable from the dashboard; point-in-time recovery is an add-on). The Free plan does not offer downloadable backups — use the monthly routine below.

## Monthly backup routine (any plan, ~10 minutes)

Run on a trusted computer with PostgreSQL client tools 15+ and the Supabase CLI, never on a shared machine.

```bash
# 1. Database (schema + data). Connection string: Project Settings → Database → Connection string (session pooler).
export SUPABASE_DB_URL='postgresql://postgres.REF:PASSWORD@aws-0-eu-central-1.pooler.supabase.com:5432/postgres'
pg_dump "$SUPABASE_DB_URL" --schema=public --no-owner --no-privileges -F c -f cms-$(date +%F).dump
# Admin list references auth.users; also note the admin e-mails:
psql "$SUPABASE_DB_URL" -c "select u.email from public.admin_users a join auth.users u on u.id=a.user_id" > admins-$(date +%F).txt

# 2. Files in the media bucket (Supabase CLI ≥ 1.180, after `supabase login` + `supabase link`)
supabase storage cp -r ss:///media ./media-backup-$(date +%F) --experimental
```

Keep at least the last three backups in two places (e.g. external disk + cloud drive). The service-role key and database password are not needed by anyone else — store them only in a password manager.

## Restore

1. **Single item deleted by mistake** — Galerija → Status: *Korpa* → *Vrati*.
2. **Permanently deleted item** — re-upload the photo (originals are in the file backup) or re-add the link.
3. **Whole project lost / moving to a new project**:
   1. Create a new project, run `supabase/migrations/20261104120000_cms_init.sql`.
   2. Restore data: `pg_restore --data-only --no-owner -d "$NEW_DB_URL" -t categories -t media_assets -t site_settings cms-YYYY-MM-DD.dump` (delete the 4 seeded categories and the default `site_settings` row first, or restore with `--clean` on those tables).
   3. Upload files: `supabase storage cp -r ./media-backup-YYYY-MM-DD ss:///media --experimental`.
   4. Stored file URLs contain the old project address. Rewrite them:
      ```sql
      update media_assets set
        source_url    = replace(source_url,    'OLDREF.supabase.co', 'NEWREF.supabase.co'),
        thumbnail_url = replace(thumbnail_url, 'OLDREF.supabase.co', 'NEWREF.supabase.co'),
        poster_url    = replace(poster_url,    'OLDREF.supabase.co', 'NEWREF.supabase.co'),
        variants      = replace(variants::text,'OLDREF.supabase.co', 'NEWREF.supabase.co')::jsonb;
      ```
   5. Recreate the admin user(s) (`docs/DEPLOYMENT.md` §4) and update `assets/js/cms-config.js`.
4. **Supabase temporarily down or project paused** — nothing to do on the website: visitors see the last cached gallery or the built-in photos. Resume the project in the dashboard.
