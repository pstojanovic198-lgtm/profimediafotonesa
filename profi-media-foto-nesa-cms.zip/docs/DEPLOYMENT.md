# Deployment guide

Time needed: about 30–45 minutes. You need a Supabase account (free to start) and access to wherever the website is hosted. The site owner never needs GitHub after this.

Supabase's dashboard labels change from time to time; if a menu name below differs slightly, look for the closest equivalent.

---

## 1. Create the Supabase project

1. https://supabase.com → **New project**. Region: **Central EU (Frankfurt)** (closest to Serbia). Save the database password in a password manager.
2. Plan: Free works for launch. For a business site consider **Pro** — see "Plan limits" below.

## 2. Create the database (one time)

1. Dashboard → **SQL Editor** → **New query**.
2. Paste the whole file `supabase/migrations/20261104120000_cms_init.sql` → **Run**. It is idempotent (safe to run again).
3. Check: **Table Editor** shows `categories` (4 rows), `media_assets`, `site_settings`, `admin_users`; **Storage** shows a public bucket `media`.

(With the Supabase CLI instead: `supabase link --project-ref …` then `supabase db push`.)

## 3. Authentication settings

Dashboard → **Authentication**:

1. **Sign In / Providers → Email**: keep Email enabled; **turn OFF "Allow new users to sign up"**. (Even if left on, a new account gets no rights — RLS checks `admin_users` — but there is no reason to allow signups.)
2. **URL Configuration**:
   * Site URL: `https://YOUR-DOMAIN/admin/`
   * Redirect URLs: add `https://YOUR-DOMAIN/admin/**` (needed for the password-reset link).
3. **Password security** (if offered on your plan): minimum length 10, enable leaked-password protection.
4. **SMTP** (recommended): the built-in mailer is heavily rate-limited and meant for testing. For reliable password-reset e-mails configure your own SMTP (e.g. the domain's mail provider, Brevo, Resend) under Authentication → SMTP / Emails.
5. Optional: **Attack protection → CAPTCHA** for the login form if brute-force attempts appear in logs (Supabase already rate-limits sign-in).

## 4. Create the owner's administrator account

1. **Authentication → Users → Add user → Create new user**: owner's e-mail + a strong password, tick **Auto Confirm User**.
2. **SQL Editor**: open `supabase/admin-provisioning.sql`, replace `vlasnik@example.com` with that e-mail, **Run**. Exactly one row must be returned.
3. Give the owner the address `https://YOUR-DOMAIN/admin/`, the e-mail and the password through a secure channel; they can change the password in **Podešavanja**.

To add a second administrator repeat steps 1–2; to remove one, see the comments in `admin-provisioning.sql`.

## 5. Storage limits

Dashboard → **Storage → Settings** → *Upload file size limit*.

* **Free plan: maximum 50 MB per file** (project-wide). Keep **Podešavanja → Najveći video** at 50 MB or lower on the free plan; longer videos should go to YouTube/Vimeo and be added as links.
* Pro plan: raise the global limit (e.g. 500 MB); the `media` bucket itself allows 500 MB (change in the migration or Storage → bucket settings if you need more).
* Allowed types are enforced by the bucket: JPEG, PNG, WebP, AVIF, MP4, WebM.

## 6. Connect the website

Edit **`assets/js/cms-config.js`**:

```js
window.PMFN_CMS = Object.freeze({
  supabaseUrl: "https://abcdefghijklmn.supabase.co",   // Project Settings → API → Project URL
  supabaseAnonKey: "eyJhbGciOi…  or  sb_publishable_…",   // anon / publishable key
  storage: Object.freeze({ provider: "supabase", bucket: "media" }),
});
```

### What is public and what is secret

| Value | Where | Exposure |
|---|---|---|
| Project URL | `cms-config.js` | **Public** — fine. |
| `anon` / `sb_publishable_…` key | `cms-config.js` | **Public by design** — it only grants what RLS allows (read published media). |
| `service_role` / `sb_secret_…` key | nowhere in the site | **SECRET.** Bypasses all security. Never put it in HTML/JS or git. The CMS does not need it. |
| Database password / connection string | password manager, backup machine | **SECRET.** |
| JWT secret | Supabase only | **SECRET.** |
| SMTP password | Supabase dashboard only | **SECRET.** |

An automated test (`tests/e2e/01-security.test.mjs`) fails if a service-role or secret key appears in the shipped files.

### Content-Security-Policy

`index.html` contains a CSP `<meta>` that allows `https://*.supabase.co`. If you use a **custom API domain** for Supabase, put it in `cms-config.js` and run `node tools/csp.mjs` — it adds that origin and recomputes the hashes. Run the same command after editing any inline `<script>`/`<style>` in `index.html` (the test suite checks this).

## 7. Deploy the static files

Upload the project folder **except** `tests/`, `tools/`, `supabase/`, `docs/`, `package.json` (they are harmless if uploaded, just unnecessary). Required: `index.html`, `favicon.ico`, `robots.txt`, `_headers`, `assets/`, `admin/`.

* **GitHub Pages**: commit and push as before. `_headers` is ignored there; the CSP meta tags still apply.
* **Netlify / Cloudflare Pages**: drag-and-drop or connect the repo; `_headers` adds `frame-ancestors 'none'` for `/admin/` and other security headers.
* **Vercel / classic hosting**: upload files; optionally reproduce `_headers` in the host's config.

Before going live on the real domain, remove the demo's `<meta name="robots" content="noindex, nofollow">` from `index.html` (this does not affect the CSP hashes) and fill in `og:url`.

No build step exists. After this one deployment, content changes never require a redeploy.

## 8. Verify in production (10 minutes)

1. Open `https://YOUR-DOMAIN/admin/` → log in.
2. Dodaj fotografije → upload one photo → fill *Alternativni tekst* → **Objavi**.
3. Open the website → Galerija: the photo is there; the lightbox opens it.
4. Dodaj video → paste a YouTube link → **Objavi** → plays in the lightbox.
5. In a private window, open `/admin/` → you must see only the login form.
6. Galerija → delete the test items → Korpa → *Obriši trajno*.
7. Podešavanja → turn off the illustrative-photo notice once only real work is published.

## Plan limits worth knowing (check current Supabase pricing)

* Free projects can be **paused after a period of inactivity**; while paused, the website automatically shows the cached or built-in gallery (tested), but the admin cannot be used until the project is resumed from the dashboard. Pro projects are not paused.
* Free plan: 1 GB file storage, 5 GB egress/month (both enough for a portfolio of optimised photos; video traffic is the main egress cost — prefer YouTube/Vimeo for long videos), 50 MB per file, no downloadable daily backups → follow `docs/BACKUP.md`.

## Running the automated tests (developers)

The suite runs against a local Supabase-compatible stack (PostgreSQL 16, PostgREST 12, Supabase Auth v2.180, Supabase Storage v1.40 with TUS, a small gateway). See `tests/stack/start.sh` for how it is built, then:

```bash
bash tests/stack/start.sh && source $STACK_DIR/run/env.sh
node tests/stack/seed-users.mjs
node tests/serve.mjs &           # http://127.0.0.1:8080
npm test                          # CSP check + unit + e2e
```
