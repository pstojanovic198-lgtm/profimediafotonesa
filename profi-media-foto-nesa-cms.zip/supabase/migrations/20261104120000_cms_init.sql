-- =====================================================================
-- Profi Media – Foto Neša · CMS schema (Supabase / PostgreSQL 15+)
--
-- Security model
--   * anon (public website)  : may read PUBLISHED, non-deleted media in
--                              VISIBLE categories, visible categories and
--                              the public site settings. Nothing else.
--   * authenticated          : same as anon, PLUS full management rights
--                              only when the user is listed in
--                              public.admin_users (checked by is_admin()).
--   * Admins are provisioned by SQL only (see supabase/admin-provisioning.sql);
--     there is no API path that inserts into admin_users.
--   * All checks are enforced by Row Level Security and constraints in the
--     database, never only by the admin UI.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------

-- URL allowed to be stored and rendered: https only (http only for local
-- development hosts), no whitespace, no embedded credentials, max 2048 chars.
create or replace function public.is_safe_url(u text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select u is not null
     and char_length(u) <= 2048
     and u !~ '[[:space:]<>"''`]'
     and (
           u ~* '^https://[a-z0-9.-]+(:[0-9]{1,5})?(/|\?|#|$)'
        or u ~  '^http://(127\.0\.0\.1|localhost)(:[0-9]{1,5})?/'
     )
$$;

-- Only these iframe embeds may ever be stored (and rendered).
create or replace function public.is_allowed_embed(u text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select u ~ '^https://www\.youtube-nocookie\.com/embed/[A-Za-z0-9_-]{11}(\?[A-Za-z0-9=&_-]{0,200})?$'
      or u ~ '^https://player\.vimeo\.com/video/[0-9]{1,12}(\?[A-Za-z0-9=&_.-]{0,200})?$'
      or u ~ '^https://drive\.google\.com/file/d/[A-Za-z0-9_-]{10,100}/preview$'
$$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end
$$;

-- ---------------------------------------------------------------------
-- Administrators
-- ---------------------------------------------------------------------
create table if not exists public.admin_users (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  note       text check (note is null or char_length(note) <= 120),
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users a where a.user_id = (select auth.uid())
  )
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

drop policy if exists admin_users_read_self on public.admin_users;
create policy admin_users_read_self on public.admin_users
  for select to authenticated
  using (user_id = (select auth.uid()));

-- ---------------------------------------------------------------------
-- Categories
-- ---------------------------------------------------------------------
create table if not exists public.categories (
  id          uuid primary key default gen_random_uuid(),
  slug        text not null unique
              check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' and char_length(slug) between 2 and 40),
  name        text not null check (char_length(btrim(name)) between 1 and 60),
  description text check (description is null or char_length(description) <= 500),
  sort_order  integer not null default 0,
  is_visible  boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Slugs are the public filter identifiers (data-filter / data-cat on the
-- website, links like data-filter-link="vencanja"): they never change.
create or replace function public.categories_lock_slug()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.slug is distinct from old.slug then
    raise exception 'Identifikator kategorije (slug) se ne može menjati.'
      using errcode = 'check_violation';
  end if;
  return new;
end
$$;

drop trigger if exists categories_lock_slug on public.categories;
create trigger categories_lock_slug before update on public.categories
  for each row execute function public.categories_lock_slug();

drop trigger if exists categories_updated_at on public.categories;
create trigger categories_updated_at before update on public.categories
  for each row execute function public.set_updated_at();

alter table public.categories enable row level security;

drop policy if exists categories_public_read on public.categories;
create policy categories_public_read on public.categories
  for select to anon, authenticated
  using (is_visible);

drop policy if exists categories_admin_all on public.categories;
create policy categories_admin_all on public.categories
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- The four categories of the existing website (identifiers must match the
-- data-filter values already used in index.html).
insert into public.categories (slug, name, description, sort_order) values
  ('vencanja', 'Venčanja',             null, 10),
  ('detalji',  'Detalji',              null, 20),
  ('proslave', 'Rođendani i proslave', null, 30),
  ('video',    'Video snimanje',       null, 40)
on conflict (slug) do nothing;

-- ---------------------------------------------------------------------
-- Media
-- ---------------------------------------------------------------------
create table if not exists public.media_assets (
  id               uuid primary key default gen_random_uuid(),
  title            text not null check (char_length(btrim(title)) between 1 and 140),
  description      text check (description is null or char_length(description) <= 1000),
  alt_text         text check (alt_text is null or char_length(alt_text) <= 250),
  media_type       text not null check (media_type in ('image', 'video')),
  category_id      uuid not null references public.categories (id) on delete restrict,
  -- upload   : file in our storage bucket
  -- external : direct public image/video URL on any https host
  -- youtube / vimeo / gdrive : validated iframe embed (video only)
  source_type      text not null check (source_type in ('upload', 'external', 'youtube', 'vimeo', 'gdrive')),
  provider         text check (provider is null or provider ~ '^[a-z0-9-]{1,30}$'),
  source_url       text check (source_url is null or public.is_safe_url(source_url)),
  storage_path     text check (storage_path is null or (char_length(storage_path) <= 300 and storage_path ~ '^[a-z0-9][a-z0-9/_.-]*$')),
  thumbnail_url    text check (thumbnail_url is null or public.is_safe_url(thumbnail_url)),
  poster_url       text check (poster_url is null or public.is_safe_url(poster_url)),
  embed_url        text check (embed_url is null or public.is_allowed_embed(embed_url)),
  mime_type        text check (mime_type is null or mime_type ~ '^(image|video)/[a-z0-9.+-]{1,40}$'),
  width            integer check (width is null or width between 1 and 30000),
  height           integer check (height is null or height between 1 and 30000),
  duration_seconds numeric(10, 2) check (duration_seconds is null or duration_seconds >= 0),
  file_size_bytes  bigint check (file_size_bytes is null or file_size_bytes >= 0),
  -- responsive renditions: [{"w": 480, "url": "https://…"}, …]
  variants         jsonb not null default '[]'::jsonb,
  sort_order       integer,
  is_published     boolean not null default false,
  published_at     timestamptz,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  created_by       uuid default auth.uid() references auth.users (id) on delete set null,

  constraint media_variants_shape check (
    jsonb_typeof(variants) = 'array'
    and jsonb_array_length(variants) <= 8
    and not jsonb_path_exists(
      variants,
      '$[*] ? (@.w.type() != "number" || @.url.type() != "string" || !(@.url like_regex "^https?://"))'
    )
  ),
  constraint media_source_consistency check (
       (source_type = 'upload'   and storage_path is not null and source_url is not null)
    or (source_type = 'external' and source_url is not null)
    or (source_type in ('youtube', 'vimeo', 'gdrive') and media_type = 'video' and embed_url is not null)
  ),
  -- accessibility: a published photo must have alternative text
  constraint media_published_image_alt check (
    not is_published or media_type <> 'image' or char_length(btrim(coalesce(alt_text, ''))) > 0
  ),
  constraint media_published_not_deleted check (not (is_published and deleted_at is not null))
);

-- variants URLs must also be safe (checked here because jsonpath has no access to is_safe_url)
create or replace function public.media_assets_before_write()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  v jsonb;
begin
  for v in select * from jsonb_array_elements(new.variants) loop
    if not public.is_safe_url(v ->> 'url') then
      raise exception 'Neispravan URL u varijantama slike.' using errcode = 'check_violation';
    end if;
  end loop;

  -- moving to the trash always unpublishes
  if new.deleted_at is not null then
    new.is_published := false;
  end if;

  if new.is_published and (tg_op = 'INSERT' or not old.is_published) then
    new.published_at := now();
  end if;

  -- new items go to the top of the gallery unless an order is given
  if tg_op = 'INSERT' and new.sort_order is null then
    select coalesce(min(m.sort_order), 0) - 10 into new.sort_order from public.media_assets m;
  end if;

  if tg_op = 'UPDATE' then
    new.updated_at := now();
    new.created_at := old.created_at;
    new.created_by := old.created_by;
  end if;
  return new;
end
$$;

drop trigger if exists media_assets_before_write on public.media_assets;
create trigger media_assets_before_write before insert or update on public.media_assets
  for each row execute function public.media_assets_before_write();

alter table public.media_assets alter column sort_order set not null;

create index if not exists media_assets_public_idx
  on public.media_assets (sort_order, id)
  where is_published and deleted_at is null;
create index if not exists media_assets_category_idx on public.media_assets (category_id);
create index if not exists media_assets_created_idx on public.media_assets (created_at desc);

alter table public.media_assets enable row level security;

drop policy if exists media_public_read on public.media_assets;
create policy media_public_read on public.media_assets
  for select to anon, authenticated
  using (
    is_published
    and deleted_at is null
    and exists (select 1 from public.categories c where c.id = category_id and c.is_visible)
  );

drop policy if exists media_admin_all on public.media_assets;
create policy media_admin_all on public.media_assets
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- ---------------------------------------------------------------------
-- Site settings (single row)
-- ---------------------------------------------------------------------
create table if not exists public.site_settings (
  id                    smallint primary key default 1 check (id = 1),
  -- "illustrative photos" notice above the gallery
  stock_notice_enabled  boolean not null default true,
  -- null = keep the notice text that is built into index.html
  stock_notice_text     text check (stock_notice_text is null or char_length(stock_notice_text) <= 400),
  -- show the built-in illustrative photos while no media is published
  fallback_enabled      boolean not null default true,
  max_image_mb          integer not null default 25 check (max_image_mb between 1 and 100),
  max_video_mb          integer not null default 50 check (max_video_mb between 1 and 5000),
  keep_original_images  boolean not null default true,
  updated_at            timestamptz not null default now()
);

insert into public.site_settings (id) values (1) on conflict (id) do nothing;

drop trigger if exists site_settings_updated_at on public.site_settings;
create trigger site_settings_updated_at before update on public.site_settings
  for each row execute function public.set_updated_at();

alter table public.site_settings enable row level security;

drop policy if exists site_settings_public_read on public.site_settings;
create policy site_settings_public_read on public.site_settings
  for select to anon, authenticated using (true);

drop policy if exists site_settings_admin_update on public.site_settings;
create policy site_settings_admin_update on public.site_settings
  for update to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- ---------------------------------------------------------------------
-- Public read model for the website
-- ---------------------------------------------------------------------
create or replace view public.gallery_items
with (security_invoker = true)
as
select
  m.id,
  m.title,
  m.description,
  m.alt_text,
  m.media_type,
  m.source_type,
  m.provider,
  m.source_url,
  m.thumbnail_url,
  m.poster_url,
  m.embed_url,
  m.mime_type,
  m.width,
  m.height,
  m.duration_seconds,
  m.variants,
  m.sort_order,
  m.published_at,
  c.slug as category
from public.media_assets m
join public.categories c on c.id = m.category_id
where m.is_published
  and m.deleted_at is null
  and c.is_visible;

-- ---------------------------------------------------------------------
-- Admin RPCs (SECURITY INVOKER: RLS still applies, plus explicit check)
-- ---------------------------------------------------------------------

-- Put the given items in the given order, re-using the positions they
-- currently occupy (so reordering a filtered subset leaves others alone).
create or replace function public.reorder_media(p_ids uuid[])
returns void
language plpgsql
security invoker
set search_path = ''
as $$
declare
  dupes boolean;
begin
  if not public.is_admin() then
    raise exception 'Nemate administratorska prava.' using errcode = '42501';
  end if;
  if p_ids is null or cardinality(p_ids) < 2 then
    return;
  end if;
  if cardinality(p_ids) <> (select count(distinct x) from unnest(p_ids) x) then
    raise exception 'Duplikati u redosledu.' using errcode = '22023';
  end if;

  -- make positions unique first, preserving the current order
  select exists (
    select 1 from public.media_assets group by sort_order having count(*) > 1
  ) into dupes;
  if dupes then
    update public.media_assets m
       set sort_order = r.rn * 10
      from (
        select id, row_number() over (order by sort_order, created_at desc, id) as rn
          from public.media_assets
      ) r
     where r.id = m.id;
  end if;

  with wanted as (
    select id, ord from unnest(p_ids) with ordinality as t(id, ord)
  ),
  slots as (
    select sort_order, row_number() over (order by sort_order) as ord
      from public.media_assets
     where id = any (p_ids)
  )
  update public.media_assets m
     set sort_order = s.sort_order
    from wanted w
    join slots s on s.ord = w.ord
   where m.id = w.id;
end
$$;

create or replace function public.reorder_categories(p_ids uuid[])
returns void
language plpgsql
security invoker
set search_path = ''
as $$
begin
  if not public.is_admin() then
    raise exception 'Nemate administratorska prava.' using errcode = '42501';
  end if;
  update public.categories c
     set sort_order = t.ord * 10
    from unnest(p_ids) with ordinality as t(id, ord)
   where c.id = t.id;
end
$$;

create or replace function public.dashboard_stats()
returns jsonb
language plpgsql
stable
security invoker
set search_path = ''
as $$
declare
  result jsonb;
begin
  if not public.is_admin() then
    raise exception 'Nemate administratorska prava.' using errcode = '42501';
  end if;
  select jsonb_build_object(
    'images',    count(*) filter (where media_type = 'image' and deleted_at is null),
    'videos',    count(*) filter (where media_type = 'video' and deleted_at is null),
    'published', count(*) filter (where is_published and deleted_at is null),
    'drafts',    count(*) filter (where not is_published and deleted_at is null),
    'trash',     count(*) filter (where deleted_at is not null)
  ) into result
  from public.media_assets;

  result := result || jsonb_build_object('by_category', coalesce((
    select jsonb_agg(jsonb_build_object(
             'id', c.id, 'slug', c.slug, 'name', c.name, 'is_visible', c.is_visible,
             'total', coalesce(x.total, 0), 'published', coalesce(x.published, 0))
           order by c.sort_order, c.name)
      from public.categories c
      left join (
        select category_id,
               count(*) as total,
               count(*) filter (where is_published) as published
          from public.media_assets
         where deleted_at is null
         group by category_id
      ) x on x.category_id = c.id
  ), '[]'::jsonb));
  return result;
end
$$;

-- ---------------------------------------------------------------------
-- Privileges (explicit; do not rely on platform defaults)
-- ---------------------------------------------------------------------
revoke all on public.admin_users, public.categories, public.media_assets, public.site_settings
  from anon, authenticated;
revoke all on public.gallery_items from anon, authenticated;

grant select on public.admin_users to authenticated;

grant select on public.categories to anon, authenticated;
grant insert, update, delete on public.categories to authenticated;

-- anon may only see the columns the website needs
grant select (id, title, description, alt_text, media_type, category_id, source_type, provider,
              source_url, thumbnail_url, poster_url, embed_url, mime_type, width, height,
              duration_seconds, variants, sort_order, is_published, published_at, deleted_at)
  on public.media_assets to anon;
grant select, insert, update, delete on public.media_assets to authenticated;

grant select on public.site_settings to anon, authenticated;
grant update (stock_notice_enabled, stock_notice_text, fallback_enabled, max_image_mb,
              max_video_mb, keep_original_images)
  on public.site_settings to authenticated;

grant select on public.gallery_items to anon, authenticated;

revoke all on function public.reorder_media(uuid[]), public.reorder_categories(uuid[]),
                       public.dashboard_stats() from public, anon;
grant execute on function public.reorder_media(uuid[]), public.reorder_categories(uuid[]),
                          public.dashboard_stats() to authenticated;

-- ---------------------------------------------------------------------
-- Storage: public bucket "media", writable by admins only
-- ---------------------------------------------------------------------
-- Note: the effective upload limit is the LOWER of this bucket limit and the
-- project-wide limit (Supabase Free plan: 50 MB per file).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'media', 'media', true, 524288000,
  array['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'video/mp4', 'video/webm']
)
on conflict (id) do update
  set public             = excluded.public,
      file_size_limit    = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "media: admin read" on storage.objects;
create policy "media: admin read" on storage.objects
  for select to authenticated
  using (bucket_id = 'media' and (select public.is_admin()));

drop policy if exists "media: admin insert" on storage.objects;
create policy "media: admin insert" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'media'
    and (select public.is_admin())
    and lower(storage.extension(name)) in ('jpg', 'jpeg', 'png', 'webp', 'avif', 'mp4', 'webm')
  );

drop policy if exists "media: admin update" on storage.objects;
create policy "media: admin update" on storage.objects
  for update to authenticated
  using (bucket_id = 'media' and (select public.is_admin()))
  with check (
    bucket_id = 'media'
    and (select public.is_admin())
    and lower(storage.extension(name)) in ('jpg', 'jpeg', 'png', 'webp', 'avif', 'mp4', 'webm')
  );

drop policy if exists "media: admin delete" on storage.objects;
create policy "media: admin delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'media' and (select public.is_admin()));

-- ---------------------------------------------------------------------
-- One-request payload for the public website:
--   GET /rest/v1/rpc/public_gallery
-- SECURITY INVOKER: anon only ever sees what RLS allows.
-- ---------------------------------------------------------------------
create or replace function public.public_gallery()
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  select jsonb_build_object(
    'items', coalesce((
      select jsonb_agg(to_jsonb(g) - 'sort_order' order by g.sort_order, g.id)
        from (select * from public.gallery_items order by sort_order, id limit 1000) g
    ), '[]'::jsonb),
    'categories', coalesce((
      select jsonb_agg(jsonb_build_object('slug', c.slug, 'name', c.name, 'description', c.description)
                       order by c.sort_order, c.name)
        from public.categories c
       where c.is_visible
    ), '[]'::jsonb),
    'settings', (
      select jsonb_build_object(
               'stock_notice_enabled', s.stock_notice_enabled,
               'stock_notice_text',    s.stock_notice_text,
               'fallback_enabled',     s.fallback_enabled)
        from public.site_settings s
       where s.id = 1
    )
  )
$$;

revoke all on function public.public_gallery() from public;
grant execute on function public.public_gallery() to anon, authenticated;
