-- =====================================================================
-- Grant CMS administrator rights to an existing Supabase Auth user.
--
-- 1. Supabase Dashboard → Authentication → Users → "Add user"
--    → "Create new user", enter the owner's e-mail and a strong password,
--    tick "Auto Confirm User".
-- 2. Replace the e-mail below and run this script in Dashboard → SQL Editor.
--
-- Run it only from the SQL Editor (it uses the service role). There is no
-- API or admin-panel path that can create administrators.
-- =====================================================================

insert into public.admin_users (user_id, note)
select id, 'Vlasnik sajta'
from auth.users
where email = lower('vlasnik@example.com')   -- ← CHANGE THIS
on conflict (user_id) do nothing
returning user_id;

-- Expect exactly one row above. Zero rows = the e-mail does not exist in
-- Authentication → Users yet (create the user first).

-- List administrators:
--   select a.user_id, u.email, a.created_at from public.admin_users a join auth.users u on u.id = a.user_id;
--
-- Revoke administrator rights:
--   delete from public.admin_users where user_id = (select id from auth.users where email = 'old@example.com');
