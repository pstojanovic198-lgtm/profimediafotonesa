# Profi Media – Foto Neša · website + CMS

The existing static website (design, content and behaviour unchanged) now loads its gallery from an independent CMS. The owner manages photos and videos at **`/admin/`** — upload files or paste links, choose a category, preview, click **Objavi** — and the website updates on the next page load. No HTML editing, no GitHub, no redeploy.

* **Website**: still plain static files (GitHub Pages, Netlify, Vercel or any host). No build step.
* **CMS backend**: Supabase (Postgres + Row Level Security, Auth, Storage with resumable uploads), hosted independently of the website.

## Folder structure

```
index.html                 website (original page + CMS hooks, CSP meta)
assets/js/cms-config.js    ← the only file to edit when connecting the CMS (public values)
assets/js/gallery-cms.js   loads published media into the existing gallery
assets/js/media-safety.js  URL / embed validation shared by site and admin
admin/                     administration panel (vanilla JS modules, no build)
  js/app.js                auth + routing
  js/views/*.js            Pregled, Galerija, Dodaj fotografije/video, Kategorije, Podešavanja, Prijava
  js/storage/              storage-provider abstraction (Supabase + TUS)
  js/media-url.js          link analysis (YouTube, Vimeo, Drive, Dropbox, Cloudinary, any https URL)
  js/media-process.js      in-browser image resizing (WebP renditions), video metadata/poster
  vendor/                  supabase-js 2.118.0 (vendored; no CDN dependency)
supabase/migrations/       database schema, RLS, storage bucket + policies
supabase/admin-provisioning.sql   grant admin rights to a user (SQL editor only)
tools/csp.mjs              recomputes the website CSP hashes
tests/                     unit + end-to-end tests and the local Supabase-compatible stack
docs/                      architecture, deployment, backup, admin guide (Serbian), test report
_headers, robots.txt       security headers (Netlify/Cloudflare) and crawler rules
```

## Documents

| Document | For |
|---|---|
| [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) | Setting up Supabase, auth, the first admin, connecting and deploying — includes the public-vs-secret value table |
| [docs/UPUTSTVO-ZA-ADMINISTRATORA.md](docs/UPUTSTVO-ZA-ADMINISTRATORA.md) | The owner (Serbian, non-technical) |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Inspection findings, decisions, data model, security model |
| [docs/BACKUP.md](docs/BACKUP.md) | Backups and recovery |
| [docs/TEST-REPORT.md](docs/TEST-REPORT.md) | What was tested, how, and what was not |
| [.env.example](.env.example) | Every configuration value and where it belongs |

## What still needs the owner's / maintainer's credentials

The code is complete and tested against a local Supabase-compatible stack; production needs these one-time steps (details in `docs/DEPLOYMENT.md`):

1. Create a Supabase project and run the migration.
2. Disable public sign-ups; set Site URL / redirect URLs; ideally configure SMTP for password-reset e-mails.
3. Create the owner's user and run `supabase/admin-provisioning.sql` with their e-mail.
4. Put the project URL + anon/publishable key into `assets/js/cms-config.js` and deploy the files once.
5. Check the per-file upload limit for the chosen plan (Free: 50 MB).
