/* Small DOM toolkit. Every text value goes through textContent / attributes —
   administrator- or visitor-provided strings are never parsed as HTML. */

const SVG_NS = "http://www.w3.org/2000/svg";

/**
 * h("button", { class: "btn", onclick: fn, "aria-label": "…" }, "text", child)
 * Special keys: class, text, dataset, style (object, applied via CSSOM), on* handlers.
 */
export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "text") el.textContent = v;
      else if (k === "dataset") Object.assign(el.dataset, v);
      else if (k === "style") Object.assign(el.style, v);
      else if (k === "value") el.value = v;
      else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
      else if (k in el && typeof v !== "string" && k !== "list") el[k] = v;
      else el.setAttribute(k, v === true ? "" : String(v));
    }
  }
  append(el, children);
  return el;
}

function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

export function icon(name, cls = "icon") {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("class", cls);
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("focusable", "false");
  const use = document.createElementNS(SVG_NS, "use");
  use.setAttribute("href", "#i-" + name);
  svg.append(use);
  return svg;
}

export function clear(el) {
  while (el.firstChild) el.firstChild.remove();
  return el;
}

/* ---------- toasts ---------- */
export function toast(message, type = "info", ms = 5000) {
  const host = document.getElementById("toasts");
  const ic = type === "error" ? "alert" : type === "success" ? "check" : "info";
  const el = h("div", { class: "toast toast--" + type }, icon(ic), h("span", { text: message }));
  host.append(el);
  setTimeout(() => el.remove(), type === "error" ? Math.max(ms, 8000) : ms);
}

/* ---------- dialogs ---------- */
/** Opens a modal <dialog>. Returns { dialog, close }. Focus returns to the opener. */
export function openDialog({ title, body, footer, wide = false, onClose, labelledBy } = {}) {
  const opener = document.activeElement;
  const titleId = "dlg-" + Math.random().toString(36).slice(2);
  const closeBtn = h("button", { class: "icon-btn icon-btn--sm", type: "button", "aria-label": "Zatvori" }, icon("close"));
  const dialog = h(
    "dialog",
    { class: "dialog" + (wide ? " dialog--wide" : ""), "aria-labelledby": labelledBy || titleId },
    h(
      "div",
      { class: "dialog__inner" },
      h("div", { class: "dialog__head" }, h("h2", { id: titleId, text: title }), closeBtn),
      h("div", { class: "dialog__body" }, body),
      footer ? h("div", { class: "dialog__foot" }, footer) : null,
    ),
  );
  let closed = false;
  function close(result) {
    if (closed) return;
    closed = true;
    dialog.close();
    dialog.remove();
    onClose && onClose(result);
    if (opener && typeof opener.focus === "function" && document.contains(opener)) opener.focus();
  }
  closeBtn.addEventListener("click", () => close(false));
  dialog.addEventListener("cancel", (e) => {
    e.preventDefault();
    close(false);
  });
  document.body.append(dialog);
  dialog.showModal();
  return { dialog, close };
}

/** Promise<boolean>. Danger dialogs focus "Odustani" first so Enter never deletes by accident. */
export function confirmDialog({ title, message, confirmText = "Potvrdi", cancelText = "Odustani", danger = false, details }) {
  return new Promise((resolve) => {
    const cancel = h("button", { class: "btn btn--secondary", type: "button", text: cancelText });
    const ok = h("button", { class: "btn " + (danger ? "btn--danger" : "btn--primary"), type: "button", text: confirmText });
    const body = h("div", { class: "stack" }, h("p", { text: message }), details || null);
    const { dialog, close } = openDialog({ title, body, footer: [cancel, ok], onClose: (r) => resolve(!!r) });
    dialog.setAttribute("role", "alertdialog");
    cancel.addEventListener("click", () => close(false));
    ok.addEventListener("click", () => close(true));
    (danger ? cancel : ok).focus();
  });
}

/* ---------- formatting ---------- */
const dateFmt = new Intl.DateTimeFormat("sr-Latn-RS", { day: "numeric", month: "long", year: "numeric" });
const dateTimeFmt = new Intl.DateTimeFormat("sr-Latn-RS", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
export const fmtDate = (s) => (s ? dateFmt.format(new Date(s)) : "—");
export const fmtDateTime = (s) => (s ? dateTimeFmt.format(new Date(s)) : "—");

export function fmtBytes(n) {
  if (!Number.isFinite(n)) return "—";
  if (n < 1024) return n + " B";
  if (n < 1024 * 1024) return (n / 1024).toFixed(0) + " KB";
  if (n < 1024 ** 3) return (n / 1024 / 1024).toFixed(n < 10 * 1024 * 1024 ? 1 : 0).replace(".", ",") + " MB";
  return (n / 1024 ** 3).toFixed(2).replace(".", ",") + " GB";
}

export function fmtDuration(sec) {
  if (!Number.isFinite(+sec) || sec <= 0) return "";
  const s = Math.round(sec), m = Math.floor(s / 60);
  return m + ":" + String(s % 60).padStart(2, "0");
}

/** Serbian plural: plural(5, "fotografija", "fotografije", "fotografija") */
export function plural(n, one, few, many) {
  const d = n % 10, hh = n % 100;
  if (d === 1 && hh !== 11) return one;
  if (d >= 2 && d <= 4 && (hh < 12 || hh > 14)) return few;
  return many;
}

/** Labelled field wrapper with optional hint, counter and error slot. */
export function field({ label, control, hint, required, id, counterMax }) {
  const fid = id || control.id || "f-" + Math.random().toString(36).slice(2);
  control.id = fid;
  const hintId = hint ? fid + "-hint" : null;
  const errId = fid + "-err";
  const describedBy = [hintId, errId].filter(Boolean).join(" ");
  control.setAttribute("aria-describedby", describedBy);
  if (required) control.required = true;
  const err = h("p", { class: "field-error", id: errId, hidden: true });
  const wrap = h(
    "div",
    { class: "field" },
    h("label", { for: fid }, label, required ? h("span", { class: "req", "aria-hidden": "true", text: " *" }) : null),
    control,
    hint ? h("p", { class: "hint", id: hintId, text: hint }) : null,
    err,
  );
  if (counterMax) {
    const counter = h("p", { class: "counter", "aria-hidden": "true" });
    const upd = () => (counter.textContent = control.value.length + " / " + counterMax);
    control.maxLength = counterMax;
    control.addEventListener("input", upd);
    upd();
    wrap.insertBefore(counter, err);
  }
  wrap.setError = (msg) => {
    err.hidden = !msg;
    err.textContent = msg || "";
    if (msg) control.setAttribute("aria-invalid", "true");
    else control.removeAttribute("aria-invalid");
  };
  return wrap;
}

export function spinner(label = "Učitavanje…") {
  return h("span", { class: "spinner", role: "status", "aria-label": label });
}

export function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}
