/* Supabase Storage provider.
   - Files ≤ 6 MB: single request with upload progress (XHR).
   - Larger files: TUS resumable upload in 6 MB chunks (Supabase requires
     exactly 6 MB chunks). Interrupted uploads resume from the last chunk;
     the upload URL is remembered in localStorage (per browser) so a reload
     can continue the same upload within 24 h.
   Authorisation: the logged-in admin's JWT; RLS on storage.objects decides. */

import { UploadError } from "./errors.js";

const CHUNK = 6 * 1024 * 1024;
const RESUME_PREFIX = "pmfn-tus:";
const RESUME_TTL = 24 * 3600 * 1000;

function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}

function b64(s) {
  return btoa(unescape(encodeURIComponent(s)));
}

function readStore(key) {
  try {
    const v = JSON.parse(localStorage.getItem(RESUME_PREFIX + key) || "null");
    return v && Date.now() - v.t < RESUME_TTL ? v : null;
  } catch {
    return null;
  }
}
function writeStore(key, value) {
  try {
    if (value) localStorage.setItem(RESUME_PREFIX + key, JSON.stringify({ ...value, t: Date.now() }));
    else localStorage.removeItem(RESUME_PREFIX + key);
  } catch {
    /* storage unavailable: uploads still work, just not resumable across reloads */
  }
}

/** XHR wrapper with progress + AbortSignal. Resolves { status, headers(name), body }. */
function xhr({ method, url, headers = {}, body, signal, onUploadProgress }) {
  return new Promise((resolve, reject) => {
    // an XHR aborted before send() fires no event, so reject up front
    if (signal && signal.aborted) return reject(new UploadError("Otpremanje je otkazano.", { aborted: true }));
    const x = new XMLHttpRequest();
    x.open(method, url);
    for (const [k, v] of Object.entries(headers)) x.setRequestHeader(k, v);
    if (onUploadProgress) x.upload.onprogress = (e) => e.lengthComputable && onUploadProgress(e.loaded);
    x.onload = () => resolve({ status: x.status, header: (n) => x.getResponseHeader(n), body: x.responseText });
    x.onerror = () => reject(new UploadError("Veza je prekinuta tokom otpremanja.", { network: true }));
    x.ontimeout = x.onerror;
    x.onabort = () => reject(new UploadError("Otpremanje je otkazano.", { aborted: true }));
    if (signal) signal.addEventListener("abort", () => x.abort(), { once: true });
    x.send(body ?? null);
  });
}

function httpError(res) {
  let msg = "";
  try {
    msg = JSON.parse(res.body).message || "";
  } catch {
    msg = res.body || "";
  }
  if (res.status === 413 || /maximum allowed size|too large|exceeded/i.test(msg))
    return new UploadError("Fajl je veći od dozvoljenog ograničenja servera. Smanjite fajl ili povećajte ograničenje (vidi Podešavanja).");
  if (res.status === 401 || res.status === 403 || /row-level security|unauthorized/i.test(msg))
    return new UploadError("Nemate dozvolu za otpremanje. Prijavite se ponovo.");
  if (res.status === 415 || /mime type|not supported/i.test(msg)) return new UploadError("Ova vrsta fajla nije dozvoljena.");
  if (res.status === 409 || /already exists|Duplicate/i.test(msg)) return new UploadError("Fajl sa tom putanjom već postoji.");
  return new UploadError("Server je odbio fajl (" + res.status + "). " + (msg ? msg.slice(0, 160) : ""));
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function createSupabaseStorage({ url, anonKey, bucket, getAccessToken }) {
  const base = url.replace(/\/+$/, "") + "/storage/v1";

  async function authHeaders() {
    const token = await getAccessToken();
    if (!token) throw new UploadError("Sesija je istekla. Prijavite se ponovo.");
    return { authorization: "Bearer " + token, apikey: anonKey };
  }

  async function simpleUpload(blob, path, { contentType, onProgress, signal }) {
    const res = await xhr({
      method: "POST",
      url: `${base}/object/${bucket}/${encodePath(path)}`,
      headers: { ...(await authHeaders()), "content-type": contentType, "cache-control": "max-age=31536000", "x-upsert": "false" },
      body: blob,
      signal,
      onUploadProgress: onProgress,
    });
    if (res.status < 200 || res.status >= 300) throw httpError(res);
  }

  async function tusUpload(blob, path, { contentType, onProgress, signal, resumeKey }) {
    const endpoint = `${base}/upload/resumable`;
    let location = null, offset = 0;

    const saved = resumeKey ? readStore(resumeKey) : null;
    if (saved && saved.path === path && saved.size === blob.size) {
      const head = await xhr({ method: "HEAD", url: saved.location, headers: { ...(await authHeaders()), "tus-resumable": "1.0.0" }, signal }).catch(() => null);
      if (head && head.status === 200) {
        location = saved.location;
        offset = +head.header("upload-offset") || 0;
      } else writeStore(resumeKey, null);
    }

    if (!location) {
      const res = await xhr({
        method: "POST",
        url: endpoint,
        headers: {
          ...(await authHeaders()),
          "tus-resumable": "1.0.0",
          "upload-length": String(blob.size),
          "x-upsert": "false",
          "upload-metadata": [
            "bucketName " + b64(bucket),
            "objectName " + b64(path),
            "contentType " + b64(contentType),
            "cacheControl " + b64("max-age=31536000"),
          ].join(","),
        },
        signal,
      });
      if (res.status !== 201) throw httpError(res);
      location = res.header("location");
      if (!location) throw new UploadError("Server nije vratio adresu za otpremanje.");
      if (location.startsWith("/")) location = new URL(location, base).href;
      if (resumeKey) writeStore(resumeKey, { location, path, size: blob.size });
    }

    let failures = 0;
    while (offset < blob.size) {
      const chunk = blob.slice(offset, Math.min(offset + CHUNK, blob.size));
      try {
        const res = await xhr({
          method: "PATCH",
          url: location,
          headers: { ...(await authHeaders()), "tus-resumable": "1.0.0", "upload-offset": String(offset), "content-type": "application/offset+octet-stream" },
          body: chunk,
          signal,
          onUploadProgress: (n) => onProgress && onProgress(offset + n),
        });
        if (res.status === 409) {
          // offset mismatch (e.g. after a dropped connection): ask the server where we are
          const head = await xhr({ method: "HEAD", url: location, headers: { ...(await authHeaders()), "tus-resumable": "1.0.0" }, signal });
          offset = +head.header("upload-offset") || 0;
          continue;
        }
        if (res.status !== 204) throw httpError(res);
        offset = +res.header("upload-offset") || offset + chunk.size;
        failures = 0;
        onProgress && onProgress(offset);
      } catch (e) {
        if (!(e instanceof UploadError) || !e.network || ++failures > 4) {
          if (e.aborted) {
            // stop the server-side upload too; ignore errors (it expires anyway)
            xhr({ method: "DELETE", url: location, headers: { ...(await authHeaders().catch(() => ({}))), "tus-resumable": "1.0.0" } }).catch(() => {});
            if (resumeKey) writeStore(resumeKey, null);
          }
          throw e;
        }
        await sleep(1000 * 2 ** failures); // 2 s, 4 s, 8 s, 16 s
        const head = await xhr({ method: "HEAD", url: location, headers: { ...(await authHeaders()), "tus-resumable": "1.0.0" }, signal }).catch(() => null);
        if (head && head.status === 200) offset = +head.header("upload-offset") || offset;
      }
    }
    if (resumeKey) writeStore(resumeKey, null);
  }

  return {
    name: "supabase",
    chunkSize: CHUNK,

    publicUrl(path) {
      return `${base}/object/public/${bucket}/${encodePath(path)}`;
    },

    /** Upload a Blob/File to `path`. opts: { contentType, onProgress(bytesSent), signal, resumeKey } */
    async upload(blob, path, opts = {}) {
      const o = { contentType: blob.type || "application/octet-stream", ...opts };
      if (blob.size > CHUNK) await tusUpload(blob, path, o);
      else await simpleUpload(blob, path, o);
      return { path, url: this.publicUrl(path) };
    },

    /** Returns a previously interrupted upload for this resume key, if any. */
    findResumable(resumeKey) {
      const v = readStore(resumeKey);
      return v ? { path: v.path } : null;
    },

    async remove(paths) {
      if (!paths.length) return;
      const res = await xhr({
        method: "DELETE",
        url: `${base}/object/${bucket}`,
        headers: { ...(await authHeaders()), "content-type": "application/json" },
        body: JSON.stringify({ prefixes: paths }),
      });
      if (res.status < 200 || res.status >= 300) throw httpError(res);
    },

    /** Deletes every object directly inside `folder` (our items use one flat folder each). */
    async removeFolder(folder) {
      const res = await xhr({
        method: "POST",
        url: `${base}/object/list/${bucket}`,
        headers: { ...(await authHeaders()), "content-type": "application/json" },
        body: JSON.stringify({ prefix: folder.replace(/\/+$/, "") + "/", limit: 1000, offset: 0 }),
      });
      if (res.status < 200 || res.status >= 300) throw httpError(res);
      const names = JSON.parse(res.body || "[]").filter((o) => o.id).map((o) => folder.replace(/\/+$/, "") + "/" + o.name);
      await this.remove(names);
    },
  };
}
