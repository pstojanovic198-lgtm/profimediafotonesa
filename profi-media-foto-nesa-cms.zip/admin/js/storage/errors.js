export class UploadError extends Error {
  constructor(message, { network = false, aborted = false } = {}) {
    super(message);
    this.network = network;
    this.aborted = aborted;
  }
}
