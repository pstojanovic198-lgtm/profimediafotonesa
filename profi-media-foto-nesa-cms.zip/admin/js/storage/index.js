/* Storage provider abstraction.

   The CMS and the public gallery only ever store and read full public URLs
   plus a folder path (`storage_path`) per item, so switching providers does
   not touch existing records or the website. A provider implements:

     name                          string
     upload(blob, path, opts)  →   Promise<{ path, url }>
         opts: { contentType, onProgress(bytesSent), signal: AbortSignal, resumeKey }
     publicUrl(path)           →   string
     remove(paths[])           →   Promise<void>
     removeFolder(folder)      →   Promise<void>
     findResumable(resumeKey)  →   { path } | null     (optional)

   Adding e.g. S3 / Cloudflare R2 / Bunny Storage: write a provider that gets
   short-lived signed upload URLs from a server-side function (Supabase Edge
   Function) — provider secrets must never be shipped to the browser — and
   register it in createStorage() below. */

import { createSupabaseStorage } from "./supabase.js";

export { UploadError } from "./errors.js";

export function createStorage(config, client) {
  const provider = config.storage?.provider || "supabase";
  if (provider === "supabase") {
    return createSupabaseStorage({
      url: config.supabaseUrl,
      anonKey: config.supabaseAnonKey,
      bucket: config.storage?.bucket || "media",
      getAccessToken: async () => (await client.auth.getSession()).data.session?.access_token,
    });
  }
  throw new Error(`Nepoznat storage provider: ${provider}`);
}
