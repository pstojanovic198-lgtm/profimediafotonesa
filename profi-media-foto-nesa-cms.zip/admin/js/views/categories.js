/* Kategorije: add, rename, describe, reorder, show/hide, delete (only when empty).
   The identifier (slug) is fixed after creation because the website's filters
   and links ("data-filter-link") use it. */
import { h, icon, field, toast, confirmDialog, openDialog, plural } from "../ui.js";
import { slugify } from "../media-url.js";

export async function renderCategories(main, ctx) {
  const { api } = ctx;
  main.append(
    h(
      "div",
      { class: "page-head" },
      h("div", null, h("h1", { text: "Kategorije" }), h("p", { text: "Kategorije su filteri iznad galerije na sajtu (npr. „Venčanja“). Redosled ovde je redosled filtera na sajtu." })),
      h("div", { class: "page-actions" }, h("button", { class: "btn btn--primary", type: "button", onclick: () => openForm() }, icon("plus"), "Nova kategorija")),
    ),
  );
  const list = h("ul", { class: "cat-list", role: "list" });
  const live = h("p", { class: "sr-only", "aria-live": "polite" });
  main.append(
    h("div", { class: "notice notice--info", style: { marginBottom: "16px" } }, icon("info"), h("p", { text: "Na sajtu se prikazuju samo vidljive kategorije koje imaju bar jednu objavljenu stavku." })),
    live,
    list,
  );

  let cats = [];
  let counts = {};

  async function load() {
    list.setAttribute("aria-busy", "true");
    const [c, stats] = await Promise.all([ctx.refreshCategories(), api.stats()]);
    cats = c;
    counts = Object.fromEntries(stats.by_category.map((x) => [x.id, x]));
    list.removeAttribute("aria-busy");
    render();
  }

  function render() {
    list.replaceChildren(
      ...cats.map((c, i) => {
        const n = counts[c.id] || { total: 0, published: 0 };
        const up = h("button", { class: "icon-btn icon-btn--sm", type: "button", "aria-label": `Pomeri „${c.name}“ gore`, disabled: i === 0, onclick: () => move(i, -1) }, icon("up"));
        const down = h("button", { class: "icon-btn icon-btn--sm", type: "button", "aria-label": `Pomeri „${c.name}“ dole`, disabled: i === cats.length - 1, onclick: () => move(i, 1) }, icon("down"));
        const vis = h("input", { type: "checkbox", checked: c.is_visible, role: "switch", "aria-label": `Prikaži „${c.name}“ na sajtu` });
        vis.addEventListener("change", () => toggleVisible(c, vis));
        const del = h(
          "button",
          { class: "icon-btn icon-btn--sm icon-btn--danger", type: "button", "aria-label": `Obriši „${c.name}“`, title: n.total ? "Kategorija nije prazna" : "Obriši" },
          icon("trash"),
        );
        del.addEventListener("click", () => remove(c, n.total));
        return h(
          "li",
          { class: "cat" },
          h("div", { class: "cat__order" }, up, down),
          h(
            "div",
            null,
            h("p", { class: "cat__name", text: c.name }),
            h(
              "div",
              { class: "cat__meta" },
              h("span", null, "ID filtera: ", h("code", { text: c.slug })),
              h("span", { text: `${n.published} objavljeno · ${n.total} ${plural(n.total, "stavka", "stavke", "stavki")} ukupno` }),
              c.is_visible ? h("span", { class: "badge badge--published" }, icon("eye"), "Vidljiva") : h("span", { class: "badge badge--neutral" }, icon("eye-off"), "Skrivena"),
            ),
            c.description ? h("p", { class: "cat__desc", text: c.description }) : null,
          ),
          h(
            "div",
            { class: "cat__actions" },
            h("label", { class: "switch", style: { padding: 0, gap: "8px", alignItems: "center" } }, h("span", { class: "small", text: "Na sajtu" }), vis),
            h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => openForm(c) }, icon("edit"), "Uredi"),
            del,
          ),
        );
      }),
    );
  }

  async function move(i, d) {
    const j = i + d;
    [cats[i], cats[j]] = [cats[j], cats[i]];
    render();
    list.children[j].querySelector(d < 0 ? 'button[aria-label*="gore"]' : 'button[aria-label*="dole"]')?.focus();
    live.textContent = `„${cats[j].name}“ je sada na poziciji ${j + 1} od ${cats.length}.`;
    try {
      await api.reorderCategories(cats.map((c) => c.id));
      await ctx.refreshCategories();
    } catch (e) {
      toast(e.message, "error");
      load();
    }
  }

  async function toggleVisible(c, input) {
    try {
      await api.updateCategory(c.id, { is_visible: input.checked });
      c.is_visible = input.checked;
      toast(input.checked ? `„${c.name}“ se prikazuje na sajtu.` : `„${c.name}“ je skrivena na sajtu (stavke ostaju sačuvane).`, "success");
      await ctx.refreshCategories();
      render();
    } catch (e) {
      input.checked = !input.checked;
      toast(e.message, "error");
    }
  }

  async function remove(c, total) {
    if (total > 0) {
      toast(`„${c.name}“ sadrži ${total} ${plural(total, "stavku", "stavke", "stavki")} (uključujući korpu). Premestite ih u drugu kategoriju u Galeriji, pa obrišite kategoriju — ili je samo sakrijte.`, "error");
      return;
    }
    const ok = await confirmDialog({ title: "Obrisati kategoriju?", message: `Kategorija „${c.name}“ biće trajno obrisana.`, confirmText: "Obriši", danger: true });
    if (!ok) return;
    try {
      await api.deleteCategory(c.id);
      toast("Kategorija je obrisana.", "success");
      load();
    } catch (e) {
      toast(e.message, "error");
    }
  }

  function openForm(c) {
    const isNew = !c;
    const name = h("input", { class: "input", type: "text", value: c?.name || "", maxLength: 60, autocomplete: "off" });
    const slug = h("input", { class: "input", type: "text", value: c?.slug || "", maxLength: 40, autocomplete: "off", spellcheck: "false", readOnly: !isNew, pattern: "[a-z0-9]+(-[a-z0-9]+)*" });
    const desc = h("textarea", { class: "textarea", maxLength: 500, value: c?.description || "" });
    const fName = field({ label: "Naziv", control: name, required: true, counterMax: 60, hint: "Prikazuje se kao filter na sajtu." });
    const fSlug = field({
      label: "Identifikator (ID filtera)",
      control: slug,
      required: true,
      hint: isNew ? "Popunjava se sam iz naziva. Mala slova bez kvačica, brojevi i crtice. Kasnije se ne može menjati." : "Ne može se menjati jer ga koriste filteri i linkovi na sajtu.",
    });
    const fDesc = field({ label: "Opis", control: desc, counterMax: 500, hint: "Neobavezno. Prikazuje se ispod filtera kada posetilac izabere ovu kategoriju." });
    let slugTouched = !isNew;
    name.addEventListener("input", () => {
      fName.setError("");
      if (!slugTouched) slug.value = slugify(name.value);
    });
    slug.addEventListener("input", () => {
      slugTouched = true;
      fSlug.setError("");
    });
    const status = h("div", { role: "alert" });
    const form = h("form", { class: "stack", novalidate: true, id: "cat-form" }, status, fName, fSlug, fDesc);
    const save = h("button", { class: "btn btn--primary", type: "submit", form: "cat-form" }, icon("check"), isNew ? "Dodaj kategoriju" : "Sačuvaj");
    const cancel = h("button", { class: "btn btn--secondary", type: "button", text: "Otkaži" });
    const { close } = openDialog({ title: isNew ? "Nova kategorija" : "Uredi kategoriju", body: form, footer: [cancel, save] });
    cancel.addEventListener("click", () => close(false));
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!name.value.trim()) return fName.setError("Upišite naziv."), name.focus();
      if (isNew && (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug.value) || slug.value.length < 2)) return fSlug.setError("Neispravan identifikator (npr. „krstenja“)."), slug.focus();
      save.disabled = true;
      try {
        if (isNew) {
          const maxOrder = Math.max(0, ...cats.map((x) => x.sort_order));
          await api.createCategory({ name: name.value.trim(), slug: slug.value, description: desc.value.trim() || null, sort_order: maxOrder + 10 });
        } else await api.updateCategory(c.id, { name: name.value.trim(), description: desc.value.trim() || null });
        close(true);
        toast(isNew ? "Kategorija je dodata." : "Kategorija je sačuvana.", "success");
        load();
      } catch (err) {
        status.replaceChildren(h("div", { class: "notice notice--error" }, icon("alert"), h("p", { text: err.message })));
        save.disabled = false;
      }
    });
    name.focus();
  }

  await load();
}
