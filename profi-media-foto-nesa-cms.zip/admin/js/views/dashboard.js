import { h, icon, fmtDateTime, plural } from "../ui.js";
import { isSafeUrl } from "../../../assets/js/media-safety.js";

export function thumbOf(m) {
  const v = Array.isArray(m.variants) && m.variants.length ? m.variants[0].url : null;
  const u = m.thumbnail_url || v || m.poster_url || (m.media_type === "image" ? m.source_url : null);
  return u && isSafeUrl(u) ? u : null;
}

export function statusBadge(m) {
  if (m.deleted_at) return h("span", { class: "badge badge--trash" }, icon("trash"), "U korpi");
  return m.is_published
    ? h("span", { class: "badge badge--published" }, icon("check"), "Objavljeno")
    : h("span", { class: "badge badge--draft" }, icon("eye-off"), "Nacrt");
}

export async function renderDashboard(main, ctx) {
  const { api } = ctx;
  main.append(
    h(
      "div",
      { class: "page-head" },
      h("div", null, h("h1", { text: "Pregled" }), h("p", { text: "Stanje galerije na sajtu i poslednje dodato." })),
      h("div", { class: "page-actions" }, h("a", { class: "btn btn--secondary", href: "../#radovi", target: "_blank", rel: "noopener" }, icon("external"), "Pogledaj galeriju na sajtu")),
    ),
  );
  const statsHost = h("div", { class: "stats", "aria-busy": "true" }, [0, 1, 2, 3].map(() => h("div", { class: "stat skeleton", style: { height: "96px" } })));
  main.append(statsHost);

  main.append(
    h(
      "section",
      { class: "section", "aria-labelledby": "quick-title" },
      h("h2", { id: "quick-title", class: "sr-only", text: "Brze radnje" }),
      h(
        "div",
        { class: "quick" },
        h("a", { href: "#/dodaj-fotografije" }, h("span", { class: "quick__icon" }, icon("image")), h("span", null, "Dodaj fotografije", h("small", { text: "Otpremite sa računara ili telefona, ili nalepite link" }))),
        h("a", { href: "#/dodaj-video" }, h("span", { class: "quick__icon" }, icon("video")), h("span", null, "Dodaj video", h("small", { text: "MP4/WebM fajl, link, YouTube ili Vimeo" }))),
      ),
    ),
  );

  const recentHost = h("div", { class: "panel" }, h("h2", { text: "Poslednje dodato" }), h("div", { class: "skeleton", style: { height: "200px" } }));
  const catHost = h("div", { class: "panel" }, h("h2", { text: "Po kategorijama" }), h("div", { class: "skeleton", style: { height: "200px" } }));
  const noticeHost = h("div");
  main.append(noticeHost, h("div", { class: "dash-grid" }, recentHost, catHost));

  const [stats, recent] = await Promise.all([api.stats(), api.recentMedia(8)]);

  const stat = (label, value, ic, href) =>
    h("a", { class: "stat", href }, h("span", { class: "stat__label" }, icon(ic), label), h("span", { class: "stat__value", text: String(value) }));
  statsHost.removeAttribute("aria-busy");
  statsHost.replaceChildren(
    stat("Fotografije", stats.images, "image", "#/galerija?tip=image"),
    stat("Video snimci", stats.videos, "video", "#/galerija?tip=video"),
    stat("Objavljeno", stats.published, "eye", "#/galerija?status=published"),
    stat("Nacrti", stats.drafts, "eye-off", "#/galerija?status=draft"),
  );

  if (ctx.settings?.stock_notice_enabled && stats.published > 0) {
    noticeHost.append(
      h(
        "div",
        { class: "notice notice--warn section" },
        icon("info"),
        h("p", null, "Na sajtu se još prikazuje napomena da su fotografije ilustrativne. Kada objavite prave radove, isključite je u ", h("a", { href: "#/podesavanja", text: "Podešavanjima" }), "."),
      ),
    );
  } else if (stats.published === 0) {
    noticeHost.append(
      h(
        "div",
        { class: "notice notice--info section" },
        icon("info"),
        h("p", { text: "Još nema objavljenih radova — sajt zato prikazuje ilustrativne fotografije. Čim objavite prvu fotografiju ili video, galerija će prikazivati vaše radove." }),
      ),
    );
  }

  recentHost.replaceChildren(
    h("h2", { text: "Poslednje dodato" }),
    recent.length
      ? h(
          "ul",
          { class: "recent", role: "list" },
          recent.map((m) => {
            const t = thumbOf(m);
            const cat = ctx.categories.find((c) => c.id === m.category_id);
            return h(
              "li",
              null,
              t ? h("img", { class: "recent__thumb", src: t, alt: "", loading: "lazy", width: 56, height: 56 }) : h("span", { class: "recent__thumb mcard__media" }, h("span", { class: "mcard__ph" }, icon(m.media_type === "video" ? "video" : "image"))),
              h("div", { style: { minWidth: 0 } }, h("p", { class: "recent__title", text: m.title }), h("p", { class: "recent__meta", text: (m.media_type === "video" ? "Video" : "Fotografija") + " · " + (cat?.name || "—") + " · " + fmtDateTime(m.created_at) })),
              statusBadge(m),
            );
          }),
        )
      : h("p", { class: "muted", text: "Još ništa nije dodato." }),
    h("p", { class: "section small" }, h("a", { href: "#/galerija", text: "Otvori celu galeriju →" })),
  );

  const max = Math.max(1, ...stats.by_category.map((c) => c.total));
  catHost.replaceChildren(
    ...[h("h2", { text: "Po kategorijama" }),
    h(
      "ul",
      { class: "bars", role: "list" },
      stats.by_category.map((c) =>
        h(
          "li",
          null,
          h(
            "div",
            { class: "bar__head" },
            h("span", null, c.name, c.is_visible ? null : h("span", { class: "badge badge--neutral", style: { marginLeft: "6px" } }, "skrivena")),
            h("span", { class: "muted", text: `${c.published} od ${c.total} ${plural(c.total, "stavke", "stavke", "stavki")} objavljeno` }),
          ),
          h("div", { class: "bar__track", role: "img", "aria-label": `${c.name}: ${c.total}` }, h("div", { class: "bar__fill", style: { width: (c.total / max) * 100 + "%" } })),
        ),
      ),
    ),
    stats.trash ? h("p", { class: "section small muted" }, `U korpi: ${stats.trash}. `, h("a", { href: "#/galerija?status=trash", text: "Otvori korpu" })) : null].filter(Boolean),
  );
}
