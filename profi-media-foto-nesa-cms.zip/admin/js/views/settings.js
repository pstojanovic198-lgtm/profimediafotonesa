import { h, icon, field, toast } from "../ui.js";

const DEFAULT_NOTICE = "Fotografije u galeriji su ilustrativne (Unsplash), dok ne postavimo prave radove. Najnovije radove pogledajte na Instagramu.";

export async function renderSettings(main, ctx) {
  const { api } = ctx;
  const s = (ctx.settings = await api.getSettings());

  main.append(h("div", { class: "page-head" }, h("div", null, h("h1", { text: "Podešavanja" }), h("p", { text: "Prikaz galerije na sajtu, ograničenja otpremanja i vaša lozinka." }))));

  /* ---------- website ---------- */
  const noticeOn = h("input", { type: "checkbox", checked: s.stock_notice_enabled, role: "switch" });
  const noticeText = h("textarea", { class: "textarea", maxLength: 400, value: s.stock_notice_text || "", placeholder: DEFAULT_NOTICE });
  const fallbackOn = h("input", { type: "checkbox", checked: s.fallback_enabled, role: "switch" });
  const siteStatus = h("div", { role: "alert" });
  const siteSave = h("button", { class: "btn btn--primary", type: "submit" }, icon("check"), "Sačuvaj");
  const siteForm = h(
    "form",
    { class: "panel stack", novalidate: true, "aria-labelledby": "set-site" },
    h("h2", { id: "set-site", text: "Galerija na sajtu" }),
    siteStatus,
    h("label", { class: "switch" }, h("span", { class: "switch__text" }, h("strong", { text: "Napomena o ilustrativnim fotografijama" }), h("span", { text: "Isključite kada su u galeriji samo vaši pravi radovi." })), noticeOn),
    field({ label: "Tekst napomene", control: noticeText, counterMax: 400, hint: "Ostavite prazno za podrazumevani tekst (sa linkom ka Instagramu)." }),
    h("label", { class: "switch" }, h("span", { class: "switch__text" }, h("strong", { text: "Ilustrativne fotografije dok nema objava" }), h("span", { text: "Dok nijedan rad nije objavljen, sajt prikazuje ugrađene ilustrativne fotografije. Ako isključite, galerija je prazna dok ne objavite prve radove." })), fallbackOn),
    h("div", null, siteSave),
  );
  siteForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    siteSave.disabled = true;
    try {
      ctx.settings = await api.updateSettings({ stock_notice_enabled: noticeOn.checked, stock_notice_text: noticeText.value.trim() || null, fallback_enabled: fallbackOn.checked });
      toast("Sačuvano. Promene se na sajtu vide pri sledećem otvaranju stranice.", "success");
      siteStatus.replaceChildren();
    } catch (err) {
      siteStatus.replaceChildren(h("div", { class: "notice notice--error" }, icon("alert"), h("p", { text: err.message })));
    } finally {
      siteSave.disabled = false;
    }
  });

  /* ---------- uploads ---------- */
  const maxImg = h("input", { class: "input", type: "number", min: 1, max: 100, step: 1, value: String(s.max_image_mb), inputmode: "numeric" });
  const maxVid = h("input", { class: "input", type: "number", min: 1, max: 5000, step: 1, value: String(s.max_video_mb), inputmode: "numeric" });
  const keepOrig = h("input", { type: "checkbox", checked: s.keep_original_images, role: "switch" });
  const fImg = field({ label: "Najveća fotografija (MB)", control: maxImg });
  const fVid = field({ label: "Najveći video (MB)", control: maxVid });
  const upStatus = h("div", { role: "alert" });
  const upSave = h("button", { class: "btn btn--primary", type: "submit" }, icon("check"), "Sačuvaj");
  const upForm = h(
    "form",
    { class: "panel stack", novalidate: true, "aria-labelledby": "set-up" },
    h("h2", { id: "set-up", text: "Otpremanje" }),
    upStatus,
    h("div", { class: "field-row field-row--2" }, fImg, fVid),
    h(
      "div",
      { class: "notice notice--info" },
      icon("info"),
      h("p", { text: "Server ima i sopstveno ograničenje (na besplatnom Supabase planu 50 MB po fajlu). Ako je ovde upisano više, veći fajlovi će biti odbijeni pri otpremanju. Za duže video snimke preporučujemo YouTube ili Vimeo." }),
    ),
    h("label", { class: "switch" }, h("span", { class: "switch__text" }, h("strong", { text: "Čuvaj originalne fotografije" }), h("span", { text: "Pored verzija za sajt čuva se i originalni fajl (rezervna kopija). Isključivanjem štedite prostor." })), keepOrig),
    h("div", null, upSave),
  );
  upForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    fImg.setError("");
    fVid.setError("");
    const a = +maxImg.value, b = +maxVid.value;
    if (!Number.isInteger(a) || a < 1 || a > 100) return fImg.setError("Upišite broj od 1 do 100."), maxImg.focus();
    if (!Number.isInteger(b) || b < 1 || b > 5000) return fVid.setError("Upišite broj od 1 do 5000."), maxVid.focus();
    upSave.disabled = true;
    try {
      ctx.settings = await api.updateSettings({ max_image_mb: a, max_video_mb: b, keep_original_images: keepOrig.checked });
      toast("Ograničenja su sačuvana.", "success");
      upStatus.replaceChildren();
    } catch (err) {
      upStatus.replaceChildren(h("div", { class: "notice notice--error" }, icon("alert"), h("p", { text: err.message })));
    } finally {
      upSave.disabled = false;
    }
  });

  /* ---------- password ---------- */
  const p1 = h("input", { class: "input", type: "password", autocomplete: "new-password", minLength: 10 });
  const p2 = h("input", { class: "input", type: "password", autocomplete: "new-password", minLength: 10 });
  const f1 = field({ label: "Nova lozinka", control: p1, hint: "Najmanje 10 znakova." });
  const f2 = field({ label: "Ponovite novu lozinku", control: p2 });
  const pwStatus = h("div", { role: "alert" });
  const pwSave = h("button", { class: "btn btn--primary", type: "submit", text: "Promeni lozinku" });
  const pwForm = h(
    "form",
    { class: "panel stack", novalidate: true, "aria-labelledby": "set-pw" },
    h("h2", { id: "set-pw", text: "Lozinka" }),
    h("p", { class: "small muted" }, "Prijavljeni ste kao ", h("strong", { text: ctx.user?.email || "" }), "."),
    h("input", { type: "email", autocomplete: "username", value: ctx.user?.email || "", hidden: true, readOnly: true, tabindex: "-1", "aria-hidden": "true" }),
    pwStatus,
    h("div", { class: "field-row field-row--2" }, f1, f2),
    h("div", null, pwSave),
  );
  pwForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    f1.setError("");
    f2.setError("");
    if (p1.value.length < 10) return f1.setError("Lozinka mora imati najmanje 10 znakova."), p1.focus();
    if (p1.value !== p2.value) return f2.setError("Lozinke se ne poklapaju."), p2.focus();
    pwSave.disabled = true;
    try {
      await api.updatePassword(p1.value);
      p1.value = p2.value = "";
      pwStatus.replaceChildren(h("div", { class: "notice notice--success" }, icon("check"), h("p", { text: "Lozinka je promenjena." })));
    } catch (err) {
      pwStatus.replaceChildren(h("div", { class: "notice notice--error" }, icon("alert"), h("p", { text: err.message })));
    } finally {
      pwSave.disabled = false;
    }
  });

  /* ---------- connection info ---------- */
  const info = h(
    "section",
    { class: "panel stack", "aria-labelledby": "set-info" },
    h("h2", { id: "set-info", text: "Tehnički podaci" }),
    h(
      "dl",
      { class: "kv" },
      h("dt", { text: "Server (Supabase)" }),
      h("dd", { text: ctx.config.supabaseUrl }),
      h("dt", { text: "Skladište fajlova" }),
      h("dd", { text: `${ctx.storage.name} · bucket „${ctx.config.storage?.bucket || "media"}“` }),
    ),
  );

  main.append(h("div", { class: "stack stack--lg" }, siteForm, upForm, pwForm, info));
}
