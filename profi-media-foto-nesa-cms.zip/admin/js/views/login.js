import { h, icon, field } from "../ui.js";

function authCard(...children) {
  return h(
    "main",
    { class: "auth", id: "main" },
    h(
      "div",
      { class: "auth__card" },
      h(
        "div",
        { class: "auth__brand" },
        h("img", { src: "../assets/brand/profi-media-foto-nesa-logo-160.webp", width: 52, height: 52, alt: "" }),
        h("div", null, h("p", { class: "auth__brand-name", text: "Profi Media – Foto Neša" }), h("p", { class: "auth__brand-sub", text: "Administracija sajta" })),
      ),
      ...children,
    ),
  );
}

function statusBox() {
  const box = h("div", { class: "notice notice--error", role: "alert", hidden: true });
  box.show = (msg, type = "error") => {
    box.className = "notice notice--" + type;
    box.replaceChildren(icon(type === "error" ? "alert" : type === "success" ? "check" : "info"), h("p", { text: msg }));
    box.hidden = !msg;
  };
  return box;
}

export function renderLogin(ctx, { message, onSignedIn }) {
  const email = h("input", { class: "input", type: "email", name: "email", autocomplete: "username", inputmode: "email", spellcheck: "false" });
  const password = h("input", { class: "input", type: "password", name: "password", autocomplete: "current-password" });
  const show = h("label", { class: "check small" }, h("input", { type: "checkbox", onchange: (e) => (password.type = e.target.checked ? "text" : "password") }), "Prikaži lozinku");
  const submit = h("button", { class: "btn btn--primary btn--block", type: "submit" }, "Prijavi se");
  const status = statusBox();
  const fEmail = field({ label: "E-mail", control: email, required: true });
  const fPass = field({ label: "Lozinka", control: password, required: true });

  const form = h("form", { class: "auth__form", novalidate: true }, status, fEmail, fPass, show, submit);
  const forgot = h("button", { class: "link-btn", type: "button", text: "Zaboravili ste lozinku?" });
  const view = authCard(
    h("h1", { text: "Prijava" }),
    h("p", { class: "auth__lead", text: "Prijavite se da biste dodavali i uređivali fotografije i video snimke na sajtu." }),
    form,
    h("div", { class: "auth__links" }, forgot, h("a", { href: "../", text: "← Nazad na sajt" })),
  );
  if (message) status.show(message, /istekla|odjav/i.test(message) ? "info" : "error");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    fEmail.setError("");
    fPass.setError("");
    let bad = false;
    if (!email.value.trim() || !email.checkValidity()) {
      fEmail.setError("Upišite ispravnu e-mail adresu.");
      bad = true;
    }
    if (!password.value) {
      fPass.setError("Upišite lozinku.");
      bad = true;
    }
    if (bad) return (email.getAttribute("aria-invalid") ? email : password).focus();
    submit.disabled = true;
    submit.replaceChildren(h("span", { class: "spinner", "aria-hidden": "true" }), "Prijavljivanje…");
    status.show("");
    try {
      await ctx.api.signIn(email.value, password.value);
      password.value = "";
      await onSignedIn();
    } catch (err) {
      status.show(err.message);
      password.select();
      password.focus();
    } finally {
      submit.disabled = false;
      submit.replaceChildren("Prijavi se");
    }
  });

  forgot.addEventListener("click", () => {
    const resetEmail = h("input", { class: "input", type: "email", autocomplete: "username", value: email.value });
    const send = h("button", { class: "btn btn--primary btn--block", type: "submit", text: "Pošalji link za novu lozinku" });
    const st = statusBox();
    const f = field({ label: "E-mail administratora", control: resetEmail, required: true });
    const resetForm = h("form", { class: "auth__form", novalidate: true }, st, f, send);
    const back = h("button", { class: "link-btn", type: "button", text: "← Nazad na prijavu" });
    const card = view.querySelector(".auth__card");
    const brandNode = card.firstChild;
    card.replaceChildren(
      brandNode,
      h("h1", { text: "Nova lozinka" }),
      h("p", { class: "auth__lead", text: "Poslaćemo vam e-mail sa linkom za postavljanje nove lozinke." }),
      resetForm,
      h("div", { class: "auth__links" }, back),
    );
    back.addEventListener("click", () => view.replaceWith(renderLogin(ctx, { onSignedIn })));
    resetForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!resetEmail.value.trim() || !resetEmail.checkValidity()) return f.setError("Upišite ispravnu e-mail adresu.");
      f.setError("");
      send.disabled = true;
      try {
        await ctx.api.requestPasswordReset(resetEmail.value, location.origin + location.pathname);
        // Same message whether or not the address exists (no account enumeration)
        st.show("Ako je adresa registrovana, uskoro ćete dobiti e-mail sa linkom. Proverite i folder „Spam“.", "success");
      } catch (err) {
        st.show(err.message);
      } finally {
        send.disabled = false;
      }
    });
    resetEmail.focus();
  });

  queueMicrotask(() => email.focus());
  return view;
}

export function renderRecovery(ctx, { onDone }) {
  const p1 = h("input", { class: "input", type: "password", autocomplete: "new-password", minLength: 10 });
  const p2 = h("input", { class: "input", type: "password", autocomplete: "new-password", minLength: 10 });
  const f1 = field({ label: "Nova lozinka", control: p1, required: true, hint: "Najmanje 10 znakova. Preporuka: tri nasumične reči i broj." });
  const f2 = field({ label: "Ponovite lozinku", control: p2, required: true });
  const st = statusBox();
  const save = h("button", { class: "btn btn--primary btn--block", type: "submit", text: "Sačuvaj novu lozinku" });
  const form = h("form", { class: "auth__form", novalidate: true }, st, f1, f2, save);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    f1.setError("");
    f2.setError("");
    if (p1.value.length < 10) return f1.setError("Lozinka mora imati najmanje 10 znakova."), p1.focus();
    if (p1.value !== p2.value) return f2.setError("Lozinke se ne poklapaju."), p2.focus();
    save.disabled = true;
    try {
      await ctx.api.updatePassword(p1.value);
      st.show("Lozinka je promenjena.", "success");
      setTimeout(onDone, 800);
    } catch (err) {
      st.show(err.message);
      save.disabled = false;
    }
  });
  queueMicrotask(() => p1.focus());
  return authCard(h("h1", { text: "Postavite novu lozinku" }), h("p", { class: "auth__lead", text: "Unesite novu lozinku za administraciju." }), form);
}
