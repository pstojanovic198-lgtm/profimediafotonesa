/* "Dodaj fotografije" / "Dodaj video": one queue for uploads and links.
   Flow: choose source → add files/links (validated immediately) → fill title,
   description, alt text, category → Pregled → "Objavi" or "Sačuvaj kao nacrt". */
import { h, icon, field, toast, fmtBytes, fmtDuration, plural, confirmDialog } from "../ui.js";
import { analyzeMediaUrl, titleFromFilename } from "../media-url.js";
import { validateFile, readVideoMeta, decodeImage, fileType, IMAGE_TYPES, VIDEO_TYPES } from "../media-process.js";
import { probeImage, vimeoInfo } from "../media-probe.js";
import { newFolder, resumeKeyFor, uploadImageFile, uploadVideoFile, prepareExternalImage, prepareExternalVideo } from "../pipeline.js";
import { openPublicPreview } from "../preview.js";

const SOURCES = {
  image: [
    { id: "upload", label: "Otpremi fajlove", icon: "upload" },
    { id: "url", label: "Link do fotografije", icon: "link" },
  ],
  video: [
    { id: "upload", label: "Otpremi video", icon: "upload" },
    { id: "url", label: "Link do video fajla", icon: "link" },
    { id: "youtube", label: "YouTube", icon: "play" },
    { id: "vimeo", label: "Vimeo", icon: "play" },
  ],
};

const URL_HELP = {
  url_image: {
    label: "Link do fotografije",
    placeholder: "https://…/fotografija.jpg",
    hint: "Direktan javni link do slike (Cloudinary, Dropbox, Google Drive, ImageKit, Amazon S3, Bunny CDN… ). Najlakše: desni klik na fotografiju → „Kopiraj adresu slike“. Može više linkova odjednom, svaki u novom redu.",
  },
  url_video: {
    label: "Link do video fajla",
    placeholder: "https://…/video.mp4",
    hint: "Direktan javni link do MP4 ili WebM fajla (Cloudinary, Bunny CDN, Amazon S3, Dropbox…) ili Google Drive link fajla podeljenog sa „Svako ko ima link“.",
  },
  youtube: { label: "YouTube link", placeholder: "https://www.youtube.com/watch?v=…", hint: "Otvorite video na YouTube-u → „Podeli“ → „Kopiraj“. Radi i za Shorts i za neizlistane (unlisted) video snimke." },
  vimeo: { label: "Vimeo link", placeholder: "https://vimeo.com/123456789", hint: "Otvorite video na Vimeo-u → „Share“ → kopirajte link. Za privatne video snimke ugrađivanje mora biti dozvoljeno u podešavanjima videa na Vimeo-u." },
};

let seq = 0;

export async function renderAddMedia(main, ctx, kind) {
  const { api, storage } = ctx;
  const settings = ctx.settings || { max_image_mb: 25, max_video_mb: 50, keep_original_images: true };
  const limits = { maxImageMb: settings.max_image_mb, maxVideoMb: settings.max_video_mb };
  const isImage = kind === "image";
  const queue = [];
  let running = false;
  let source = "upload";

  const visibleCats = () => ctx.categories;
  const defaultCat = () => {
    const pref = isImage ? null : ctx.categories.find((c) => c.slug === "video");
    return (pref || ctx.categories[0])?.id || "";
  };

  /* ---------- head ---------- */
  main.append(
    h(
      "div",
      { class: "page-head" },
      h(
        "div",
        null,
        h("h1", { text: isImage ? "Dodaj fotografije" : "Dodaj video" }),
        h("p", {
          text: isImage
            ? "Otpremite fotografije sa računara ili telefona, ili nalepite link do fotografije koja je već na internetu. Pre objave možete pogledati kako će izgledati."
            : "Otpremite MP4/WebM video, nalepite link do video fajla, ili dodajte YouTube / Vimeo video. Video se na sajtu nikada ne pušta sam.",
        }),
      ),
    ),
  );

  if (!ctx.categories.length) {
    main.append(h("div", { class: "notice notice--warn" }, icon("alert"), h("p", null, "Nema nijedne kategorije. Prvo dodajte kategoriju u ", h("a", { href: "#/kategorije", text: "Kategorijama" }), ".")));
    return;
  }

  /* ---------- source selector ---------- */
  const seg = h(
    "fieldset",
    { class: "segmented" },
    h("legend", { text: "Izvor" }),
    SOURCES[kind].map((s, i) =>
      h("label", null, h("input", { type: "radio", name: "source", value: s.id, checked: i === 0, onchange: () => setSource(s.id) }), icon(s.icon), s.label),
    ),
  );

  /* ---------- upload zone ---------- */
  const accept = (isImage ? IMAGE_TYPES : VIDEO_TYPES).join(",") + (isImage ? ",.jpg,.jpeg,.png,.webp,.avif" : ",.mp4,.webm");
  const fileInput = h("input", { type: "file", multiple: true, accept, "aria-label": isImage ? "Izaberite fotografije" : "Izaberite video fajlove" });
  const dropzone = h(
    "label",
    { class: "dropzone" },
    fileInput,
    h("span", { class: "dropzone__icon" }, icon("upload")),
    h("span", { class: "dropzone__title", text: isImage ? "Prevucite fotografije ovde ili kliknite za izbor" : "Prevucite video ovde ili kliknite za izbor" }),
    h("span", {
      class: "dropzone__hint",
      text: isImage
        ? `JPG, PNG, WebP ili AVIF · najviše ${settings.max_image_mb} MB po fotografiji · može više odjednom`
        : `MP4 ili WebM · najviše ${settings.max_video_mb} MB po videu · veliki fajlovi se nastavljaju ako se veza prekine`,
    }),
  );
  fileInput.addEventListener("change", () => {
    addFiles([...fileInput.files]);
    fileInput.value = "";
  });
  ["dragenter", "dragover"].forEach((ev) =>
    dropzone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropzone.classList.add("is-over");
    }),
  );
  ["dragleave", "drop"].forEach((ev) => dropzone.addEventListener(ev, () => dropzone.classList.remove("is-over")));
  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    addFiles([...(e.dataTransfer?.files || [])]);
  });

  /* ---------- url form ---------- */
  const urlInput = h("textarea", { class: "textarea", rows: 2, spellcheck: "false", autocomplete: "off", style: { minHeight: "56px" } });
  const urlField = field({ label: "", control: urlInput });
  const urlBtn = h("button", { class: "btn btn--secondary", type: "submit" }, icon("plus"), "Dodaj link");
  const urlForm = h("form", { class: "url-form", novalidate: true }, urlField, h("div", null, urlBtn));
  urlForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const lines = urlInput.value.split(/\s+/).map((s) => s.trim()).filter(Boolean);
    if (!lines.length) {
      urlField.setError("Nalepite link.");
      return urlInput.focus();
    }
    urlField.setError("");
    lines.slice(0, 30).forEach(addUrl);
    urlInput.value = "";
  });
  urlInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      urlForm.requestSubmit();
    }
  });

  function setSource(id) {
    source = id;
    dropzone.hidden = id !== "upload";
    urlForm.hidden = id === "upload";
    const help = URL_HELP[id === "url" ? "url_" + kind : id];
    if (help) {
      urlField.querySelector("label").textContent = help.label;
      urlInput.placeholder = help.placeholder;
      let hint = urlField.querySelector(".hint");
      if (!hint) {
        hint = h("p", { class: "hint", id: urlInput.id + "-hint" });
        urlInput.after(hint);
        urlInput.setAttribute("aria-describedby", hint.id + " " + urlInput.id + "-err");
      }
      hint.textContent = help.hint;
    }
  }

  /* ---------- queue + aside ---------- */
  const queueEl = h("ul", { class: "queue", role: "list", "aria-label": "Stavke za dodavanje" });
  const emptyHint = h("p", { class: "muted small section", text: isImage ? "Dodate fotografije pojaviće se ovde, gde im možete upisati naziv i opis." : "Dodati video snimci pojaviće se ovde, gde im možete upisati naziv i opis." });
  const live = h("p", { class: "sr-only", "aria-live": "polite" });

  const catSelect = h("select", { class: "select" }, visibleCats().map((c) => h("option", { value: c.id, text: c.name + (c.is_visible ? "" : " (skrivena)") })));
  catSelect.value = defaultCat();
  catSelect.addEventListener("change", () => queue.forEach((it) => it.state === "ready" && !it.catTouched && (it.ui.cat.value = catSelect.value)));
  const summary = h("p", { class: "small muted", "aria-live": "polite" });
  const publishBtn = h("button", { class: "btn btn--primary btn--block", type: "button", disabled: true }, icon("check"), "Objavi");
  const draftBtn = h("button", { class: "btn btn--secondary btn--block", type: "button", disabled: true }, "Sačuvaj kao nacrt");
  const clearBtn = h("button", { class: "btn btn--ghost btn--sm", type: "button", hidden: true, text: "Ukloni završene sa liste" });
  publishBtn.addEventListener("click", () => submit(true));
  draftBtn.addEventListener("click", () => submit(false));
  clearBtn.addEventListener("click", () => {
    for (const it of [...queue]) if (it.state === "done") removeItem(it);
  });

  const aside = h(
    "aside",
    { class: "add-aside", "aria-label": "Objava" },
    h(
      "div",
      { class: "panel" },
      h("h2", { text: "Objava" }),
      field({ label: "Kategorija", control: catSelect, hint: "Važi za sve nove stavke; za pojedinačnu stavku možete izabrati drugu." }),
      summary,
      h("div", { class: "publish-actions" }, publishBtn, draftBtn),
      h("p", { class: "small muted", text: "„Objavi“ — odmah se prikazuje na sajtu. „Nacrt“ — sačuvano, ali vidljivo samo u administraciji." }),
      clearBtn,
    ),
  );

  main.append(h("div", { class: "add-layout" }, h("div", null, seg, h("div", { class: "section" }, dropzone, urlForm), emptyHint, queueEl, live), aside));
  setSource("upload");

  /* ---------- adding ---------- */
  function addFiles(files) {
    if (!files.length) return;
    if (source !== "upload") {
      source = "upload";
      seg.querySelector('input[value="upload"]').checked = true;
      setSource("upload");
    }
    for (const file of files) {
      const err = validateFile(file, kind, limits);
      const it = createItem({ origin: "file", file, title: titleFromFilename(file.name) });
      if (err) setState(it, "invalid", err);
      else inspectFile(it);
    }
    live.textContent = `Dodato: ${files.length} ${plural(files.length, "fajl", "fajla", "fajlova")}.`;
  }

  function addUrl(text) {
    const expect = isImage ? "image" : "video";
    const analysis = analyzeMediaUrl(text, { expect });
    const it = createItem({ origin: "url", rawUrl: text, analysis, title: "" });
    if (!analysis.ok) return setState(it, "invalid", analysis.message);
    if (source === "youtube" && analysis.sourceType !== "youtube") it.notes.push("Ovo nije YouTube link — prepoznat je i dodat kao " + providerLabel(analysis) + ".");
    if (source === "vimeo" && analysis.sourceType !== "vimeo") it.notes.push("Ovo nije Vimeo link — prepoznat je i dodat kao " + providerLabel(analysis) + ".");
    inspectUrl(it);
  }

  function providerLabel(a) {
    return { youtube: "YouTube video", vimeo: "Vimeo video", gdrive: "Google Drive video" }[a.sourceType] || (a.kind === "image" ? "link do fotografije" : "link do video fajla");
  }

  async function inspectFile(it) {
    setState(it, "checking", "Proveravam fajl…");
    try {
      if (isImage) {
        const bmp = await decodeImage(it.file);
        it.meta = { width: bmp.naturalWidth || bmp.width, height: bmp.naturalHeight || bmp.height };
        if (bmp.close) bmp.close();
      } else {
        try {
          it.meta = await readVideoMeta(it.file);
        } catch {
          it.meta = {};
          it.notes.push("Ovaj pregledač ne može da prikaže pregled videa. Proverite fajl — posetioci možda neće moći da ga pogledaju.");
        }
      }
      it.previewUrl = URL.createObjectURL(it.file);
      const resumable = !isImage && storage.findResumable && storage.findResumable(resumeKeyFor(it.file));
      if (resumable) {
        it.folder = resumable.path.split("/").slice(0, -1).join("/");
        it.notes.push("Prethodno prekinuto otpremanje ovog fajla biće nastavljeno.");
      }
      setState(it, "ready");
    } catch (e) {
      setState(it, "invalid", e.message || "Fajl ne može da se otvori.");
    }
  }

  async function inspectUrl(it) {
    const a = it.analysis;
    setState(it, "checking", "Proveravam link…");
    try {
      if (a.kind === "image") {
        it.meta = await probeImage(a.url);
        it.previewUrl = a.thumbnailUrl || a.url;
      } else if (a.kind === "video") {
        it.meta = await readVideoMeta(a.url);
        it.previewUrl = a.url;
      } else {
        // embed
        if (a.sourceType === "vimeo") {
          const info = await vimeoInfo(a.url);
          if (!info) it.notes.push("Podaci o Vimeo videu nisu dostupni (privatan video ili ugrađivanje nije dozvoljeno). Proverite pregled pre objave i po želji dodajte naslovnu sliku.");
          else {
            it.info = info;
            if (!it.ui.title.value && info.title) it.ui.title.value = info.title;
          }
        }
        const thumb = it.info?.thumbnailUrl || a.thumbnailUrl;
        if (thumb) {
          try {
            await probeImage(thumb, { timeout: 10000 });
            it.previewUrl = thumb;
          } catch {
            if (a.sourceType === "youtube") throw new Error("YouTube video nije pronađen ili je privatan. Proverite link i da je video „Javni“ ili „Neizlistan“.");
            if (a.sourceType === "gdrive") it.notes.push("Google Drive ne prikazuje pregled ovog fajla — proverite da je podeljen sa „Svako ko ima link“.");
          }
        }
      }
      it.notes.push(...(a.notes || []));
      setState(it, "ready");
    } catch (e) {
      setState(it, "invalid", e.message);
    }
  }

  /* ---------- item UI ---------- */
  function createItem(init) {
    const it = { key: ++seq, state: "new", notes: [], meta: null, posterFile: null, catTouched: false, controller: null, ...init };
    const title = h("input", { class: "input", type: "text", value: init.title || "", maxLength: 140, autocomplete: "off" });
    const desc = h("textarea", { class: "textarea", maxLength: 1000, rows: 2 });
    const alt = h("input", { class: "input", type: "text", maxLength: 250, autocomplete: "off" });
    const cat = h("select", { class: "select" }, visibleCats().map((c) => h("option", { value: c.id, text: c.name })));
    cat.value = catSelect.value;
    cat.addEventListener("change", () => (it.catTouched = true));
    const fTitle = field({ label: "Naziv", control: title, required: true, counterMax: 140 });
    const fDesc = field({ label: "Opis", control: desc, hint: "Neobavezno. Prikazuje se ispod fotografije u uvećanom prikazu.", counterMax: 1000 });
    const fAlt = isImage
      ? field({ label: "Alternativni tekst", control: alt, required: true, hint: "Kratko opišite šta se vidi (npr. „Mladenci ispred crkve u Despotovcu“). Čitaju ga slabovidi posetioci i Google.", counterMax: 250 })
      : null;
    const fCat = field({ label: "Kategorija", control: cat });
    title.addEventListener("input", () => fTitle.setError(""));
    alt.addEventListener("input", () => fAlt && fAlt.setError(""));

    const posterInput = h("input", { type: "file", accept: "image/jpeg,image/png,image/webp,image/avif", class: "sr-only" });
    const posterLabel = h("span", { class: "small muted" });
    const posterBtn = h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => posterInput.click() }, icon("image"), "Izaberi naslovnu sliku");
    const posterRow = !isImage
      ? h("div", { class: "field" }, h("span", { class: "label", text: "Naslovna slika (poster)" }), h("div", { class: "poster-pick" }, posterBtn, posterInput, posterLabel), h("p", { class: "hint", text: "Neobavezno. Prikazuje se u galeriji pre puštanja videa. Ako je ne izaberete, koristi se kadar iz videa ili sličica sa YouTube-a/Vimeo-a." }))
      : null;
    posterInput.addEventListener("change", () => {
      const f = posterInput.files[0];
      if (!f) return;
      const err = validateFile(f, "image", { maxImageMb: 15, maxVideoMb: 0 });
      if (err) return toast(err, "error");
      it.posterFile = f;
      posterLabel.textContent = f.name;
      if (it.posterPreview) URL.revokeObjectURL(it.posterPreview);
      it.posterPreview = URL.createObjectURL(f);
      renderPreview(it);
    });

    const previewBox = h("div", { class: "qitem__preview" });
    const status = h("div", { class: "small", "aria-live": "polite" });
    const progressFill = h("div", { class: "progress__fill" });
    const progressPct = h("span");
    const progressStage = h("span");
    const progress = h("div", { class: "progress", hidden: true }, h("div", { class: "progress__track" }, progressFill), h("div", { class: "progress__text" }, progressStage, progressPct));
    const previewBtn = h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => previewItem(it) }, icon("eye"), "Pregled");
    const removeBtn = h("button", { class: "btn btn--ghost btn--sm", type: "button", onclick: () => onRemove(it) }, icon("close"), "Ukloni");
    const retryBtn = h("button", { class: "btn btn--secondary btn--sm", type: "button", hidden: true, onclick: () => processOne(it, it.lastPublish) }, icon("refresh"), "Pokušaj ponovo");
    const name = it.origin === "file" ? `${it.file.name} · ${fmtBytes(it.file.size)}` : it.rawUrl;
    const notes = h("div", { class: "stack", style: { gap: "8px" } });
    const fields = h("div", { class: "qitem__fields" }, fTitle, fDesc, fAlt, h("div", { class: "field-row field-row--2" }, fCat), posterRow);

    const li = h(
      "li",
      { class: "qitem" },
      previewBox,
      h(
        "div",
        { class: "stack" },
        h("div", { class: "qitem__head" }, h("p", { class: "qitem__name", text: name }), removeBtn),
        status,
        notes,
        progress,
        fields,
        h("div", { class: "qitem__tools" }, previewBtn, retryBtn),
      ),
    );
    it.ui = { li, title, desc, alt, cat, fTitle, fAlt, previewBox, status, progress, progressFill, progressPct, progressStage, previewBtn, removeBtn, retryBtn, fields, notes, posterBtn };
    queue.push(it);
    queueEl.append(li);
    emptyHint.hidden = true;
    return it;
  }

  function renderPreview(it) {
    const box = it.ui.previewBox;
    box.replaceChildren();
    const src = it.posterPreview || it.previewUrl;
    const isVid = !isImage;
    if (isVid && it.origin === "file" && !it.posterPreview && it.previewUrl) {
      box.append(h("video", { src: it.previewUrl + "#t=1", preload: "metadata", muted: true, playsInline: true, "aria-hidden": "true" }));
    } else if (isVid && it.analysis?.kind === "video" && !it.posterPreview) {
      box.append(h("video", { src: it.analysis.url + "#t=1", preload: "metadata", muted: true, playsInline: true, "aria-hidden": "true" }));
    } else if (src) {
      const img = h("img", { src, alt: "", decoding: "async", referrerpolicy: "no-referrer" });
      img.addEventListener("error", () => img.replaceWith(h("span", { class: "mcard__ph" }, icon(isImage ? "image" : "video"))), { once: true });
      box.append(img);
    } else box.append(h("span", { class: "mcard__ph" }, icon(isImage ? "image" : "video")));
    if (isVid) box.append(h("span", { class: "mcard__play", "aria-hidden": "true" }, icon("play", "icon icon--fill")));
  }

  function setState(it, state, message) {
    it.state = state;
    const u = it.ui;
    u.li.classList.toggle("is-error", state === "invalid" || state === "error");
    u.li.classList.toggle("is-done", state === "done");
    const busy = state === "processing";
    if (busy) u.li.setAttribute("data-busy-upload", "");
    else u.li.removeAttribute("data-busy-upload");
    u.fields.hidden = state === "invalid" || state === "done";
    u.previewBtn.hidden = !(state === "ready" || state === "error" || state === "done");
    u.retryBtn.hidden = state !== "error";
    u.progress.hidden = !busy;
    u.removeBtn.replaceChildren(icon("close"), busy ? "Otkaži" : state === "done" ? "Ukloni sa liste" : "Ukloni");
    [u.title, u.desc, u.alt, u.cat, u.posterBtn].forEach((c) => c && (c.disabled = busy));

    u.notes.replaceChildren(...(state === "ready" || state === "error" ? it.notes.map((n) => h("div", { class: "notice notice--info" }, icon("info"), h("p", { text: n }))) : []));
    let msg = null;
    if (state === "checking") msg = h("p", { class: "muted", style: { display: "flex", gap: "8px", alignItems: "center" } }, h("span", { class: "spinner", "aria-hidden": "true" }), message);
    else if (state === "invalid" || state === "error") msg = h("div", { class: "notice notice--error", role: "alert" }, icon("alert"), h("p", { text: message }));
    else if (state === "done") {
      msg = h(
        "div",
        { class: "notice notice--success" },
        icon("check"),
        h("p", null, it.published ? "Objavljeno na sajtu. " : "Sačuvano kao nacrt. ", h("a", { href: "#/galerija", text: "Otvori galeriju" })),
      );
    } else if (state === "ready" && it.meta) {
      const bits = [];
      if (it.meta.width) bits.push(`${it.meta.width} × ${it.meta.height} px`);
      if (it.meta.duration) bits.push(fmtDuration(it.meta.duration));
      if (it.analysis?.ok) bits.push(providerLabel(it.analysis) + (it.analysis.provider && !["youtube", "vimeo", "gdrive"].includes(it.analysis.provider) ? ` (${it.analysis.provider})` : ""));
      msg = bits.length ? h("p", { class: "muted", text: bits.join(" · ") }) : null;
    }
    u.status.replaceChildren(...(msg ? [msg] : []));
    if (state === "ready" || state === "done" || state === "error") renderPreview(it);
    if (state === "invalid") u.previewBox.replaceChildren(h("span", { class: "mcard__ph" }, icon("alert")));
    updateSummary();
  }

  function updateSummary() {
    const ready = queue.filter((i) => i.state === "ready" || i.state === "error").length;
    const done = queue.filter((i) => i.state === "done").length;
    const checking = queue.some((i) => i.state === "checking");
    publishBtn.disabled = draftBtn.disabled = running || !ready || checking;
    const word = isImage ? plural(ready, "fotografija", "fotografije", "fotografija") : plural(ready, "video", "videa", "videa");
    summary.textContent = queue.length ? `Spremno: ${ready} ${word}${done ? ` · Završeno: ${done}` : ""}${checking ? " · provera u toku…" : ""}` : "Još ništa nije dodato.";
    publishBtn.replaceChildren(icon("check"), ready > 1 ? `Objavi sve (${ready})` : "Objavi");
    draftBtn.textContent = ready > 1 ? `Sačuvaj sve kao nacrt (${ready})` : "Sačuvaj kao nacrt";
    clearBtn.hidden = !done;
  }

  async function onRemove(it) {
    if (it.state === "processing") {
      it.controller?.abort();
      return;
    }
    removeItem(it);
  }

  function removeItem(it) {
    if (it.previewUrl?.startsWith("blob:")) URL.revokeObjectURL(it.previewUrl);
    if (it.posterPreview) URL.revokeObjectURL(it.posterPreview);
    it.ui.li.remove();
    queue.splice(queue.indexOf(it), 1);
    emptyHint.hidden = queue.length > 0;
    updateSummary();
  }

  function previewItem(it) {
    const base = { title: it.ui.title.value.trim() || "(bez naziva)", description: it.ui.desc.value.trim() };
    if (it.origin === "file") {
      openPublicPreview(isImage ? { kind: "image", src: it.previewUrl, alt: it.ui.alt.value, ...base } : { kind: "video", src: it.previewUrl, poster: it.posterPreview, ...base });
    } else {
      const a = it.analysis;
      if (a.kind === "embed") openPublicPreview({ kind: "embed", embedUrl: a.embedUrl, ...base });
      else if (a.kind === "video") openPublicPreview({ kind: "video", src: a.url, poster: it.posterPreview || a.posterUrl, ...base });
      else openPublicPreview({ kind: "image", src: a.url, alt: it.ui.alt.value, ...base });
    }
  }

  /* ---------- saving ---------- */
  function validateItem(it, publish) {
    let ok = true;
    if (!it.ui.title.value.trim()) {
      it.ui.fTitle.setError("Upišite naziv.");
      ok = false;
    }
    if (isImage && publish && !it.ui.alt.value.trim()) {
      it.ui.fAlt.setError("Za objavu je potreban alternativni tekst. Ako ga sada ne znate, sačuvajte kao nacrt.");
      ok = false;
    }
    if (!it.ui.cat.value) ok = false;
    return ok;
  }

  async function submit(publish) {
    const items = queue.filter((i) => i.state === "ready" || i.state === "error");
    const invalid = items.filter((i) => !validateItem(i, publish));
    if (invalid.length) {
      const first = invalid[0].ui;
      (first.title.getAttribute("aria-invalid") ? first.title : first.alt).focus();
      toast(`Popunite obavezna polja (${invalid.length} ${plural(invalid.length, "stavka", "stavke", "stavki")}).`, "error");
      return;
    }
    const hidden = items.map((i) => ctx.categories.find((c) => c.id === i.ui.cat.value)).filter((c) => c && !c.is_visible);
    if (publish && hidden.length && !(await confirmDialog({ title: "Skrivena kategorija", message: `Kategorija „${hidden[0].name}“ je skrivena na sajtu, pa se ove stavke neće videti dok je ne prikažete. Nastaviti?`, confirmText: "Nastavi" }))) return;

    running = true;
    updateSummary();
    let ok = 0, failed = 0;
    for (const it of items) {
      (await processOne(it, publish)) ? ok++ : failed++;
    }
    running = false;
    updateSummary();
    const what = isImage ? plural(ok, "fotografija", "fotografije", "fotografija") : plural(ok, "video", "videa", "videa");
    if (ok) toast(publish ? `Objavljeno: ${ok} ${what}. Već se vidi na sajtu.` : `Sačuvano kao nacrt: ${ok} ${what}.`, "success");
    if (failed) toast(`${failed} ${plural(failed, "stavka nije sačuvana", "stavke nisu sačuvane", "stavki nije sačuvano")}. Pogledajte poruke na listi.`, "error");
    live.textContent = `Završeno. Uspešno: ${ok}. Neuspešno: ${failed}.`;
  }

  async function processOne(it, publish) {
    it.lastPublish = publish;
    it.controller = new AbortController();
    const signal = it.controller.signal;
    const u = it.ui;
    setState(it, "processing");
    u.progressFill.style.width = "0%";
    const onProgress = (p) => {
      const pct = Math.round(p * 100);
      u.progressFill.style.width = pct + "%";
      u.progressPct.textContent = pct + " %";
    };
    const onStage = (s) => (u.progressStage.textContent = s);
    const id = crypto.randomUUID();
    // keep the same folder across retries so an interrupted large upload can resume
    const folder = it.folder || (it.folder = newFolder(id));
    let paths = [];
    try {
      let result;
      if (it.origin === "file") {
        result = isImage
          ? await uploadImageFile({ file: it.file, folder, storage, keepOriginal: settings.keep_original_images, signal, onProgress, onStage })
          : await uploadVideoFile({ file: it.file, folder, storage, posterFile: it.posterFile, meta: it.meta, signal, onProgress, onStage });
      } else if (isImage) {
        result = await prepareExternalImage({ analysis: it.analysis, dims: it.meta, folder, storage, signal, onProgress, onStage });
      } else {
        result = await prepareExternalVideo({ analysis: it.analysis, info: { ...(it.info || {}), ...(it.meta || {}) }, posterFile: it.posterFile, folder, storage, signal, onProgress, onStage });
      }
      paths = result.paths;
      onStage("Čuvanje…");
      if (signal.aborted) throw Object.assign(new Error("Otpremanje je otkazano."), { aborted: true });
      const row = {
        ...result.row,
        id,
        title: u.title.value.trim(),
        description: u.desc.value.trim() || null,
        alt_text: isImage ? u.alt.value.trim() || null : null,
        category_id: u.cat.value,
        is_published: publish,
      };
      await api.insertMedia(row);
      it.folder = null;
      it.published = publish;
      onProgress(1);
      setState(it, "done");
      return true;
    } catch (e) {
      if (paths.length) await storage.remove(paths).catch(() => {});
      if (e.aborted) {
        setState(it, "ready");
        toast("Otpremanje je otkazano.", "info");
      } else setState(it, "error", e.message || "Čuvanje nije uspelo.");
      return false;
    } finally {
      it.controller = null;
    }
  }

  // Navigation away during uploads: abort them
  return () => queue.forEach((it) => it.controller?.abort());
}
