/* Galerija: search, filter, select, bulk actions, drag-and-drop reordering
   (with keyboard and button alternatives), edit, preview, trash/restore. */
import { h, icon, field, toast, confirmDialog, openDialog, fmtDateTime, fmtBytes, fmtDuration, plural, debounce } from "../ui.js";
import { thumbOf, statusBadge } from "./dashboard.js";
import { inlinePreview, openPublicPreview, toPreviewModel } from "../preview.js";
import { replacePoster } from "../pipeline.js";
import { validateFile } from "../media-process.js";
import { isSafeUrl } from "../../../assets/js/media-safety.js";

const PAGE = 60;
const SOURCE_LABEL = { upload: "Otpremljen fajl", external: "Spoljni link", youtube: "YouTube", vimeo: "Vimeo", gdrive: "Google Drive" };

function hashParams() {
  const q = location.hash.split("?")[1] || "";
  return new URLSearchParams(q);
}

export async function renderGallery(main, ctx) {
  const { api, storage } = ctx;
  const params = hashParams();
  const state = {
    search: params.get("q") || "",
    categoryId: params.get("kategorija") || "",
    status: ["published", "draft", "trash"].includes(params.get("status")) ? params.get("status") : "all",
    type: ["image", "video"].includes(params.get("tip")) ? params.get("tip") : "all",
    rows: [],
    count: 0,
    selected: new Set(),
    loading: false,
  };
  const catName = (id) => ctx.categories.find((c) => c.id === id)?.name || "—";

  /* ---------- head + toolbar ---------- */
  main.append(
    h(
      "div",
      { class: "page-head" },
      h("div", null, h("h1", { text: "Galerija" }), h("p", { text: "Sve fotografije i video snimci. Redosled ovde je redosled na sajtu — prevucite stavku za ručicu da biste je pomerili." })),
      h("div", { class: "page-actions" }, h("a", { class: "btn btn--primary", href: "#/dodaj-fotografije" }, icon("image"), "Dodaj fotografije"), h("a", { class: "btn btn--secondary", href: "#/dodaj-video" }, icon("video"), "Dodaj video")),
    ),
  );

  const search = h("input", { class: "input", type: "search", value: state.search, placeholder: "Naziv, opis…", autocomplete: "off" });
  const catSel = h("select", { class: "select" }, h("option", { value: "", text: "Sve kategorije" }), ctx.categories.map((c) => h("option", { value: c.id, text: c.name })));
  catSel.value = state.categoryId;
  const statusSel = h(
    "select",
    { class: "select" },
    [
      ["all", "Svi statusi"],
      ["published", "Objavljeno"],
      ["draft", "Nacrti"],
      ["trash", "Korpa (obrisano)"],
    ].map(([v, t]) => h("option", { value: v, text: t })),
  );
  statusSel.value = state.status;
  const typeSel = h(
    "select",
    { class: "select" },
    [
      ["all", "Fotografije i video"],
      ["image", "Samo fotografije"],
      ["video", "Samo video"],
    ].map(([v, t]) => h("option", { value: v, text: t })),
  );
  typeSel.value = state.type;
  const searchField = field({ label: "Pretraga", control: search });
  const searchWrap = h("div", { class: "search" });
  search.replaceWith(searchWrap);
  searchWrap.append(icon("search"), search);
  main.append(
    h("div", { class: "toolbar", role: "search" }, searchField, field({ label: "Kategorija", control: catSel }), field({ label: "Status", control: statusSel }), field({ label: "Vrsta", control: typeSel })),
  );

  const selectAll = h("input", { type: "checkbox" });
  const countText = h("span", { "aria-live": "polite" });
  const listbar = h("div", { class: "listbar" }, h("label", { class: "check" }, selectAll, "Izaberi sve prikazano"), countText);
  const bulkbar = h("div", { class: "bulkbar", role: "region", "aria-label": "Radnje za izabrane stavke", hidden: true });
  const grid = h("ul", { class: "media-grid", role: "list", "aria-describedby": "reorder-help" });
  const reorderHelp = h("p", { id: "reorder-help", class: "sr-only", text: "Za promenu redosleda: fokusirajte ručicu stavke i koristite strelice levo/desno ili gore/dole." });
  const live = h("p", { class: "sr-only", "aria-live": "assertive" });
  const moreBtn = h("button", { class: "btn btn--secondary", type: "button", hidden: true, text: "Učitaj još" });
  const emptyBox = h("div", { hidden: true });
  main.append(listbar, bulkbar, reorderHelp, live, grid, emptyBox, h("div", { class: "load-more" }, moreBtn));

  /* ---------- data ---------- */
  function syncHash() {
    const p = new URLSearchParams();
    if (state.search) p.set("q", state.search);
    if (state.categoryId) p.set("kategorija", state.categoryId);
    if (state.status !== "all") p.set("status", state.status);
    if (state.type !== "all") p.set("tip", state.type);
    const s = p.toString();
    history.replaceState(null, "", "#/galerija" + (s ? "?" + s : ""));
  }

  let requestNo = 0;
  async function load(reset = true) {
    // a newer request (e.g. a filter change) always wins; stale responses are dropped
    if (!reset && state.loading) return;
    const my = ++requestNo;
    state.loading = true;
    grid.setAttribute("aria-busy", "true");
    if (reset) {
      state.selected.clear();
      grid.replaceChildren(...Array.from({ length: 8 }, () => h("li", { class: "mcard skeleton", style: { height: "300px" }, "aria-hidden": "true" })));
    }
    moreBtn.disabled = true;
    try {
      const from = reset ? 0 : state.rows.length;
      const { rows, count } = await api.listMedia({ search: state.search, categoryId: state.categoryId, status: state.status, type: state.type, from, to: from + PAGE - 1 });
      if (my !== requestNo) return;
      state.rows = reset ? rows : state.rows.concat(rows);
      state.count = count;
      render();
    } catch (e) {
      if (my !== requestNo) return;
      grid.replaceChildren();
      emptyBox.hidden = false;
      emptyBox.replaceChildren(
        h("div", { class: "notice notice--error", role: "alert" }, icon("alert"), h("div", { class: "stack" }, h("p", { text: e.message }), h("div", null, h("button", { class: "btn btn--secondary btn--sm", type: "button", text: "Pokušaj ponovo", onclick: () => load(true) })))),
      );
    } finally {
      if (my === requestNo) {
        state.loading = false;
        grid.removeAttribute("aria-busy");
        moreBtn.disabled = false;
      }
    }
  }

  const canReorder = () => state.status !== "trash";

  function render() {
    grid.replaceChildren(...state.rows.map(card));
    const filtered = state.search || state.categoryId || state.status !== "all" || state.type !== "all";
    emptyBox.hidden = state.rows.length > 0;
    if (!state.rows.length) {
      emptyBox.replaceChildren(
        h(
          "div",
          { class: "empty" },
          icon(state.status === "trash" ? "trash" : "image"),
          h("strong", { text: state.status === "trash" ? "Korpa je prazna" : filtered ? "Nema rezultata" : "Galerija je prazna" }),
          h("p", { text: state.status === "trash" ? "Obrisane stavke ostaju ovde dok ih ne vratite ili trajno obrišete." : filtered ? "Promenite pretragu ili filtere." : "Dodajte prve fotografije ili video snimke." }),
          !filtered ? h("a", { class: "btn btn--primary", href: "#/dodaj-fotografije" }, icon("plus"), "Dodaj fotografije") : null,
        ),
      );
    }
    countText.textContent = `Prikazano ${state.rows.length} od ${state.count}`;
    moreBtn.hidden = state.rows.length >= state.count;
    updateBulk();
  }

  /* ---------- card ---------- */
  function card(m) {
    const t = thumbOf(m);
    const media = h(
      "div",
      { class: "mcard__media" },
      t ? h("img", { src: t, alt: "", loading: "lazy", decoding: "async", referrerpolicy: "no-referrer" }) : h("span", { class: "mcard__ph" }, icon(m.media_type === "video" ? "video" : "image")),
      m.media_type === "video" ? h("span", { class: "mcard__play", "aria-hidden": "true" }, icon("play", "icon icon--fill")) : null,
      h("span", { class: "mcard__type badge badge--neutral" }, icon(m.media_type === "video" ? "video" : "image"), m.media_type === "video" ? SOURCE_LABEL[m.source_type] === "Otpremljen fajl" ? "Video" : SOURCE_LABEL[m.source_type] : "Fotografija"),
    );
    const img = media.querySelector("img");
    if (img) img.addEventListener("error", () => img.replaceWith(h("span", { class: "mcard__ph" }, icon("alert"))), { once: true });

    const cb = h("input", { type: "checkbox", checked: state.selected.has(m.id), "aria-label": "Izaberi: " + m.title });
    cb.addEventListener("change", () => {
      if (cb.checked) state.selected.add(m.id);
      else state.selected.delete(m.id);
      li.classList.toggle("is-selected", cb.checked);
      updateBulk();
    });
    const grip = canReorder()
      ? h("button", { class: "mcard__grip", type: "button", "aria-label": "Pomeri: " + m.title, "aria-describedby": "reorder-help" }, icon("grip"))
      : null;

    const publishToggle = m.deleted_at
      ? null
      : h(
          "button",
          { class: "icon-btn icon-btn--sm", type: "button", "aria-label": (m.is_published ? "Povuci sa sajta: " : "Objavi: ") + m.title, title: m.is_published ? "Povuci sa sajta" : "Objavi" },
          icon(m.is_published ? "eye-off" : "check"),
        );
    publishToggle?.addEventListener("click", () => setPublished([m.id], !m.is_published));

    const actions = m.deleted_at
      ? [
          h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => restore([m.id]) }, icon("restore"), "Vrati"),
          h("button", { class: "icon-btn icon-btn--sm icon-btn--danger", type: "button", "aria-label": "Trajno obriši: " + m.title, onclick: () => destroy([m.id]) }, icon("trash")),
        ]
      : [
          h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => openEditor(m) }, icon("edit"), "Uredi"),
          h("button", { class: "icon-btn icon-btn--sm", type: "button", "aria-label": "Pregled: " + m.title, title: "Pregled", onclick: () => openPublicPreview(toPreviewModel(m)) }, icon("eye")),
          publishToggle,
        ];

    const li = h(
      "li",
      { class: "mcard" + (state.selected.has(m.id) ? " is-selected" : ""), dataset: { id: m.id } },
      h("label", { class: "mcard__select" }, cb),
      grip,
      media,
      h(
        "div",
        { class: "mcard__body" },
        h("p", { class: "mcard__title", text: m.title, title: m.title }),
        h("div", { class: "mcard__meta" }, statusBadge(m), h("span", { text: catName(m.category_id) })),
      ),
      h("div", { class: "mcard__actions" }, actions),
    );
    if (grip) wireReorder(li, grip, m);
    return li;
  }

  /* ---------- reordering ---------- */
  function idsInDom() {
    return [...grid.children].map((li) => li.dataset.id).filter(Boolean);
  }

  const persistOrder = debounce(async () => {
    const ids = idsInDom();
    const before = state.rows.map((r) => r.id).join();
    if (ids.join() === before) return;
    state.rows = ids.map((id) => state.rows.find((r) => r.id === id));
    try {
      await api.reorderMedia(ids);
      toast("Redosled je sačuvan i već važi na sajtu.", "success", 2500);
    } catch (e) {
      toast(e.message, "error");
      load(true);
    }
  }, 600);

  function wireReorder(li, grip, m) {
    grip.addEventListener("keydown", (e) => {
      const delta = { ArrowUp: -1, ArrowLeft: -1, ArrowDown: 1, ArrowRight: 1 }[e.key];
      if (!delta) return;
      e.preventDefault();
      const sib = delta < 0 ? li.previousElementSibling : li.nextElementSibling;
      if (!sib) return;
      if (delta < 0) grid.insertBefore(li, sib);
      else grid.insertBefore(sib, li);
      grip.focus();
      const pos = [...grid.children].indexOf(li) + 1;
      live.textContent = `${m.title}: pozicija ${pos} od ${grid.children.length}.`;
      persistOrder();
    });

    grip.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      // listen on the document: re-inserting the card in the DOM releases pointer capture
      li.classList.add("is-dragging");
      let moved = false, raf = 0, lastY = e.clientY;
      const scroll = () => {
        const edge = 70, speed = 14;
        if (lastY < edge) window.scrollBy(0, -speed);
        else if (lastY > innerHeight - edge) window.scrollBy(0, speed);
        raf = requestAnimationFrame(scroll);
      };
      raf = requestAnimationFrame(scroll);
      const move = (ev) => {
        lastY = ev.clientY;
        const target = document.elementFromPoint(ev.clientX, ev.clientY)?.closest(".mcard");
        if (!target || target === li || target.parentNode !== grid) return;
        const kids = [...grid.children];
        grid.insertBefore(li, kids.indexOf(li) < kids.indexOf(target) ? target.nextSibling : target);
        moved = true;
      };
      const up = (ev) => {
        if (ev && ev.type === "pointerup") move(ev); // settle on the slot under the final pointer position
        cancelAnimationFrame(raf);
        li.classList.remove("is-dragging");
        document.removeEventListener("pointermove", move);
        document.removeEventListener("pointerup", up);
        document.removeEventListener("pointercancel", up);
        if (moved) {
          live.textContent = `${m.title}: pozicija ${[...grid.children].indexOf(li) + 1} od ${grid.children.length}.`;
          persistOrder();
        }
      };
      document.addEventListener("pointermove", move);
      document.addEventListener("pointerup", up);
      document.addEventListener("pointercancel", up);
    });
  }

  /* ---------- selection + bulk ---------- */
  selectAll.addEventListener("change", () => {
    state.rows.forEach((r) => (selectAll.checked ? state.selected.add(r.id) : state.selected.delete(r.id)));
    grid.querySelectorAll(".mcard").forEach((li) => {
      li.classList.toggle("is-selected", selectAll.checked);
      li.querySelector(".mcard__select input").checked = selectAll.checked;
    });
    updateBulk();
  });

  function updateBulk() {
    const n = state.selected.size;
    selectAll.checked = n > 0 && state.rows.every((r) => state.selected.has(r.id));
    selectAll.indeterminate = n > 0 && !selectAll.checked;
    bulkbar.hidden = n === 0;
    if (!n) return;
    const ids = [...state.selected];
    const items = [
      h("span", { class: "bulkbar__count", text: `Izabrano: ${n}` }),
    ];
    if (state.status === "trash") {
      items.push(
        h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => restore(ids) }, icon("restore"), "Vrati"),
        h("button", { class: "btn btn--danger btn--sm", type: "button", onclick: () => destroy(ids) }, icon("trash"), "Obriši trajno"),
      );
    } else {
      const moveSel = h("select", { class: "select", "aria-label": "Premesti u kategoriju" }, h("option", { value: "", text: "Premesti u…" }), ctx.categories.map((c) => h("option", { value: c.id, text: c.name })));
      moveSel.addEventListener("change", () => moveSel.value && moveTo(ids, moveSel.value));
      items.push(
        h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => setPublished(ids, true) }, icon("eye"), "Objavi"),
        h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => setPublished(ids, false) }, icon("eye-off"), "Povuci sa sajta"),
        moveSel,
        h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => trash(ids) }, icon("trash"), "Obriši"),
      );
    }
    items.push(h("button", { class: "btn btn--secondary btn--sm", type: "button", text: "Poništi izbor", onclick: () => (state.selected.clear(), render()) }));
    bulkbar.replaceChildren(...items);
  }

  const rowsFor = (ids) => ids.map((id) => state.rows.find((r) => r.id === id)).filter(Boolean);

  async function setPublished(ids, publish) {
    let target = ids;
    if (publish) {
      const missingAlt = rowsFor(ids).filter((r) => r.media_type === "image" && !(r.alt_text || "").trim());
      target = ids.filter((id) => !missingAlt.some((r) => r.id === id));
      if (missingAlt.length) {
        toast(`${missingAlt.length} ${plural(missingAlt.length, "fotografija nema", "fotografije nemaju", "fotografija nema")} alternativni tekst i ${missingAlt.length === 1 ? "nije objavljena" : "nisu objavljene"}. Dodajte ga preko „Uredi“.`, "error");
        if (ids.length === 1) return openEditor(missingAlt[0], { focusAlt: true });
      }
    }
    if (!target.length) return;
    try {
      const n = await api.updateMany(target, { is_published: publish });
      toast(publish ? `Objavljeno: ${n}. Vidi se na sajtu.` : `Povučeno sa sajta: ${n}.`, "success");
      load(true);
    } catch (e) {
      toast(e.message, "error");
    }
  }

  async function moveTo(ids, categoryId) {
    try {
      const n = await api.updateMany(ids, { category_id: categoryId });
      toast(`Premešteno u „${catName(categoryId)}“: ${n}.`, "success");
      load(true);
    } catch (e) {
      toast(e.message, "error");
    }
  }

  async function trash(ids) {
    const ok = await confirmDialog({
      title: ids.length > 1 ? `Obrisati ${ids.length} stavki?` : "Obrisati stavku?",
      message: "Stavke se uklanjaju sa sajta i premeštaju u korpu. Iz korpe ih možete vratiti.",
      confirmText: "Premesti u korpu",
      danger: true,
    });
    if (!ok) return;
    try {
      await api.moveToTrash(ids);
      toast("Premešteno u korpu.", "success");
      load(true);
    } catch (e) {
      toast(e.message, "error");
    }
  }

  async function restore(ids) {
    try {
      await api.restore(ids);
      toast("Vraćeno iz korpe kao nacrt. Objavite ponovo kada želite.", "success");
      load(true);
    } catch (e) {
      toast(e.message, "error");
    }
  }

  async function destroy(ids) {
    const rows = rowsFor(ids);
    const files = rows.filter((r) => r.storage_path).length;
    const ok = await confirmDialog({
      title: "Trajno brisanje",
      message: `Trajno obrisati ${rows.length} ${plural(rows.length, "stavku", "stavke", "stavki")}?${files ? " Otpremljeni fajlovi biće obrisani sa servera." : ""} Ovo se ne može poništiti.`,
      confirmText: "Obriši trajno",
      danger: true,
    });
    if (!ok) return;
    const failed = await api.deletePermanently(rows, storage);
    if (failed.length) toast(`Nije obrisano: ${failed.length}. ${failed[0].error.message}`, "error");
    else toast("Trajno obrisano.", "success");
    load(true);
  }

  /* ---------- editor ---------- */
  function openEditor(m, { focusAlt = false } = {}) {
    const isImage = m.media_type === "image";
    const title = h("input", { class: "input", type: "text", value: m.title, maxLength: 140 });
    const desc = h("textarea", { class: "textarea", maxLength: 1000, value: m.description || "" });
    const alt = h("input", { class: "input", type: "text", value: m.alt_text || "", maxLength: 250 });
    const cat = h("select", { class: "select" }, ctx.categories.map((c) => h("option", { value: c.id, text: c.name + (c.is_visible ? "" : " (skrivena)") })));
    cat.value = m.category_id;
    const pub = h("input", { type: "checkbox", checked: !!m.is_published, role: "switch" });
    const fTitle = field({ label: "Naziv", control: title, required: true, counterMax: 140 });
    const fAlt = field({ label: "Alternativni tekst", control: alt, required: isImage, counterMax: 250, hint: isImage ? "Šta se vidi na fotografiji — za slabovide posetioce i Google. Obavezno za objavu." : "Neobavezno: kratak opis naslovne slike videa." });
    const status = h("div", { role: "alert" });

    let newPoster = null;
    const posterInput = h("input", { type: "file", accept: "image/jpeg,image/png,image/webp,image/avif", class: "sr-only" });
    const posterName = h("span", { class: "small muted" });
    posterInput.addEventListener("change", () => {
      const f = posterInput.files[0];
      if (!f) return;
      const err = validateFile(f, "image", { maxImageMb: 15 });
      if (err) return toast(err, "error");
      newPoster = f;
      posterName.textContent = "Nova naslovna slika: " + f.name;
    });
    const posterField = !isImage
      ? h(
          "div",
          { class: "field" },
          h("span", { class: "label", text: "Naslovna slika (poster)" }),
          h("div", { class: "poster-pick" }, h("button", { class: "btn btn--secondary btn--sm", type: "button", onclick: () => posterInput.click() }, icon("image"), m.poster_url ? "Zameni naslovnu sliku" : "Dodaj naslovnu sliku"), posterInput, posterName),
        )
      : null;

    const original = m.source_url && isSafeUrl(m.source_url) ? h("a", { href: m.source_url, target: "_blank", rel: "noopener noreferrer", text: "Otvori original" }) : "—";
    const info = h(
      "dl",
      { class: "kv" },
      h("dt", { text: "Vrsta" }), h("dd", { text: isImage ? "Fotografija" : "Video" }),
      h("dt", { text: "Izvor" }), h("dd", { text: SOURCE_LABEL[m.source_type] + (m.provider && !["youtube", "vimeo", "gdrive"].includes(m.provider) ? ` (${m.provider})` : "") }),
      h("dt", { text: "Original" }), h("dd", null, original),
      m.width ? [h("dt", { text: "Dimenzije" }), h("dd", { text: `${m.width} × ${m.height}` })] : null,
      m.file_size_bytes ? [h("dt", { text: "Veličina" }), h("dd", { text: fmtBytes(+m.file_size_bytes) })] : null,
      m.duration_seconds ? [h("dt", { text: "Trajanje" }), h("dd", { text: fmtDuration(+m.duration_seconds) })] : null,
      h("dt", { text: "Dodato" }), h("dd", { text: fmtDateTime(m.created_at) }),
      h("dt", { text: "Izmenjeno" }), h("dd", { text: fmtDateTime(m.updated_at) }),
      m.published_at ? [h("dt", { text: "Objavljeno" }), h("dd", { text: fmtDateTime(m.published_at) })] : null,
    );

    const body = h(
      "div",
      { class: "editor" },
      h("div", { class: "stack" }, inlinePreview(toPreviewModel(m)), info),
      h(
        "form",
        { class: "stack", novalidate: true, id: "edit-form" },
        status,
        fTitle,
        field({ label: "Opis", control: desc, counterMax: 1000, hint: "Prikazuje se ispod fotografije u uvećanom prikazu na sajtu." }),
        fAlt,
        field({ label: "Kategorija", control: cat }),
        posterField,
        h("label", { class: "switch" }, h("span", { class: "switch__text" }, h("strong", { text: "Objavljeno na sajtu" }), h("span", { text: "Isključite da stavku sakrijete sa sajta bez brisanja." })), pub),
      ),
    );
    const save = h("button", { class: "btn btn--primary", type: "submit", form: "edit-form" }, icon("check"), "Sačuvaj");
    const cancel = h("button", { class: "btn btn--secondary", type: "button", text: "Otkaži" });
    const del = h("button", { class: "btn btn--ghost spacer", type: "button" }, icon("trash"), "Obriši");
    const preview = h("button", { class: "btn btn--secondary", type: "button" }, icon("eye"), "Pregled");
    const { close } = openDialog({ title: "Uredi: " + m.title, body, footer: [del, preview, cancel, save], wide: true });
    cancel.addEventListener("click", () => close(false));
    preview.addEventListener("click", () => openPublicPreview({ ...toPreviewModel(m), title: title.value, description: desc.value }));
    del.addEventListener("click", async () => {
      close(false);
      await trash([m.id]);
    });
    body.querySelector("form").addEventListener("submit", async (e) => {
      e.preventDefault();
      fTitle.setError("");
      fAlt.setError("");
      if (!title.value.trim()) return fTitle.setError("Upišite naziv."), title.focus();
      if (isImage && pub.checked && !alt.value.trim()) return fAlt.setError("Za objavu je potreban alternativni tekst."), alt.focus();
      save.disabled = true;
      save.replaceChildren(h("span", { class: "spinner", "aria-hidden": "true" }), "Čuvanje…");
      let uploaded = [];
      try {
        const patch = {
          title: title.value.trim(),
          description: desc.value.trim() || null,
          alt_text: alt.value.trim() || null,
          category_id: cat.value,
          is_published: pub.checked,
        };
        if (newPoster) {
          const r = await replacePoster({ row: m, file: newPoster, storage });
          uploaded = r.paths;
          Object.assign(patch, r.patch);
        }
        await api.updateMedia(m.id, patch);
        close(true);
        toast("Izmene su sačuvane." + (pub.checked ? " Već se vide na sajtu." : ""), "success");
        load(true);
      } catch (err) {
        if (uploaded.length) storage.remove(uploaded).catch(() => {});
        status.replaceChildren(h("div", { class: "notice notice--error" }, icon("alert"), h("p", { text: err.message })));
        save.disabled = false;
        save.replaceChildren(icon("check"), "Sačuvaj");
      }
    });
    (focusAlt ? alt : title).focus();
  }

  /* ---------- events ---------- */
  const reload = () => {
    syncHash();
    load(true);
  };
  search.addEventListener("input", debounce(() => ((state.search = search.value.trim()), reload()), 350));
  catSel.addEventListener("change", () => ((state.categoryId = catSel.value), reload()));
  statusSel.addEventListener("change", () => ((state.status = statusSel.value), reload()));
  typeSel.addEventListener("change", () => ((state.type = typeSel.value), reload()));
  moreBtn.addEventListener("click", () => load(false));

  await load(true);
}
