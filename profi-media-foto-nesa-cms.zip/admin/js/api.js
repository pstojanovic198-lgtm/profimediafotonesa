/* Data access for the admin panel. All authorisation is enforced by the
   database (RLS + is_admin()); this module only translates errors into
   messages a non-technical administrator can act on. */

export class CmsError extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
  }
}

const CONSTRAINT_MSG = {
  media_published_image_alt: "Fotografija mora imati alternativni tekst (opis za slabovide) pre objavljivanja.",
  media_source_consistency: "Nedostaje izvor medija (fajl ili link).",
  media_variants_shape: "Neispravni podaci o veličinama slike.",
  categories_slug_key: "Kategorija sa tim identifikatorom već postoji. Izaberite drugi naziv.",
  categories_slug_check: "Identifikator može sadržati samo mala slova bez kvačica, brojeve i crtice (2–40 znakova).",
  media_assets_category_id_fkey: "Kategorija sadrži stavke. Prvo ih premestite u drugu kategoriju ili obrišite.",
};

export function toCmsError(err, fallback = "Došlo je do greške. Pokušajte ponovo.") {
  if (err instanceof CmsError) return err;
  const msg = String(err?.message || "");
  const details = String(err?.details || "") + " " + msg;
  if (err?.name === "TypeError" || /Failed to fetch|NetworkError|Load failed/i.test(msg)) {
    return new CmsError("Nema veze sa serverom. Proverite internet konekciju i pokušajte ponovo.", err);
  }
  if (err?.code === "PGRST301" || /JWT expired|invalid JWT/i.test(msg)) {
    return new CmsError("Sesija je istekla. Prijavite se ponovo.", err);
  }
  if (err?.code === "42501" || /permission denied|row-level security/i.test(msg)) {
    return new CmsError("Nemate dozvolu za ovu radnju. Prijavite se nalogom administratora.", err);
  }
  for (const [name, text] of Object.entries(CONSTRAINT_MSG)) if (details.includes(name)) return new CmsError(text, err);
  if (err?.code === "23505") return new CmsError("Takav zapis već postoji.", err);
  if (err?.code === "23503") return new CmsError(CONSTRAINT_MSG.media_assets_category_id_fkey, err);
  if (err?.code === "23514" || err?.code === "22001") return new CmsError("Neka polja nisu ispravno popunjena ili su predugačka.", err);
  // messages raised by our own SQL functions are already in Serbian
  if (err?.code === "P0001" || /se ne može menjati|Nemate administratorska/.test(msg)) return new CmsError(msg, err);
  return new CmsError(fallback, err);
}

async function run(promise, fallback) {
  let res;
  try {
    res = await promise;
  } catch (e) {
    throw toCmsError(e, fallback);
  }
  if (res.error) throw toCmsError(res.error, fallback);
  return res;
}

/** Characters that have meaning in PostgREST filter syntax are removed from search input. */
export function sanitizeSearch(s) {
  return String(s || "").replace(/[,()*%\\:."']/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
}

export const MEDIA_COLUMNS =
  "id,title,description,alt_text,media_type,category_id,source_type,provider,source_url,storage_path,thumbnail_url,poster_url,embed_url,mime_type,width,height,duration_seconds,file_size_bytes,variants,sort_order,is_published,published_at,created_at,updated_at,deleted_at";

export function createApi(client) {
  const db = client;
  return {
    client,

    /* ---------- auth ---------- */
    async signIn(email, password) {
      const { data, error } = await db.auth.signInWithPassword({ email: email.trim(), password });
      if (error) {
        if (/invalid login credentials/i.test(error.message)) throw new CmsError("Pogrešan e-mail ili lozinka.");
        if (/email not confirmed/i.test(error.message)) throw new CmsError("E-mail adresa još nije potvrđena.");
        if (error.status === 429) throw new CmsError("Previše pokušaja. Sačekajte nekoliko minuta pa pokušajte ponovo.");
        throw toCmsError(error, "Prijava nije uspela. Pokušajte ponovo.");
      }
      return data.session;
    },
    async signOut() {
      // revokes the refresh token server-side, then clears the local session
      const { error } = await db.auth.signOut();
      if (error) await db.auth.signOut({ scope: "local" });
    },
    async session() {
      const { data } = await db.auth.getSession();
      return data.session;
    },
    onAuthChange(cb) {
      return db.auth.onAuthStateChange(cb).data.subscription;
    },
    async isAdmin() {
      const { data } = await run(db.rpc("is_admin"), "Provera prava nije uspela.");
      return data === true;
    },
    async requestPasswordReset(email, redirectTo) {
      await run(db.auth.resetPasswordForEmail(email.trim(), { redirectTo }), "Slanje e-maila nije uspelo.");
    },
    async updatePassword(password) {
      const { error } = await db.auth.updateUser({ password });
      if (error) {
        if (/should be different/i.test(error.message)) throw new CmsError("Nova lozinka mora biti drugačija od stare.");
        if (/weak|at least/i.test(error.message)) throw new CmsError("Lozinka je preslaba. Koristite najmanje 10 znakova, slova i brojeve.");
        if (/reauthentication/i.test(error.message)) throw new CmsError("Iz bezbednosnih razloga se odjavite i prijavite ponovo, pa promenite lozinku.");
        throw toCmsError(error, "Promena lozinke nije uspela.");
      }
    },

    /* ---------- categories ---------- */
    async listCategories() {
      const { data } = await run(db.from("categories").select("*").order("sort_order").order("name"), "Kategorije nisu učitane.");
      return data;
    },
    async createCategory(row) {
      const { data } = await run(db.from("categories").insert(row).select().single(), "Kategorija nije sačuvana.");
      return data;
    },
    async updateCategory(id, patch) {
      const { data } = await run(db.from("categories").update(patch).eq("id", id).select().single(), "Kategorija nije sačuvana.");
      return data;
    },
    async deleteCategory(id) {
      await run(db.from("categories").delete().eq("id", id), "Kategorija nije obrisana.");
    },
    async reorderCategories(ids) {
      await run(db.rpc("reorder_categories", { p_ids: ids }), "Redosled nije sačuvan.");
    },

    /* ---------- media ---------- */
    async listMedia({ search, categoryId, status = "all", type = "all", from = 0, to = 59 } = {}) {
      let q = db.from("media_assets").select(MEDIA_COLUMNS, { count: "exact" });
      if (status === "trash") q = q.not("deleted_at", "is", null).order("deleted_at", { ascending: false });
      else {
        q = q.is("deleted_at", null).order("sort_order").order("id");
        if (status === "published") q = q.eq("is_published", true);
        if (status === "draft") q = q.eq("is_published", false);
      }
      if (categoryId) q = q.eq("category_id", categoryId);
      if (type === "image" || type === "video") q = q.eq("media_type", type);
      const s = sanitizeSearch(search);
      if (s) q = q.or(`title.ilike.*${s}*,description.ilike.*${s}*,alt_text.ilike.*${s}*`);
      const { data, count } = await run(q.range(from, to), "Galerija nije učitana.");
      return { rows: data, count: count ?? data.length };
    },
    async recentMedia(limit = 8) {
      const { data } = await run(
        db.from("media_assets").select(MEDIA_COLUMNS).is("deleted_at", null).order("created_at", { ascending: false }).limit(limit),
        "Poslednje stavke nisu učitane.",
      );
      return data;
    },
    async stats() {
      const { data } = await run(db.rpc("dashboard_stats"), "Statistika nije učitana.");
      return data;
    },
    async insertMedia(row) {
      const { data } = await run(db.from("media_assets").insert(row).select(MEDIA_COLUMNS).single(), "Stavka nije sačuvana.");
      return data;
    },
    async updateMedia(id, patch) {
      const { data } = await run(db.from("media_assets").update(patch).eq("id", id).select(MEDIA_COLUMNS).single(), "Izmene nisu sačuvane.");
      return data;
    },
    async updateMany(ids, patch) {
      const { data } = await run(db.from("media_assets").update(patch).in("id", ids).select("id"), "Izmene nisu sačuvane.");
      return data.length;
    },
    async moveToTrash(ids) {
      return this.updateMany(ids, { deleted_at: new Date().toISOString(), is_published: false });
    },
    async restore(ids) {
      return this.updateMany(ids, { deleted_at: null });
    },
    /** Permanent delete: storage files first, then the record (so no file is orphaned silently). */
    async deletePermanently(rows, storage) {
      const failed = [];
      for (const row of rows) {
        try {
          // storage_path holds the item's folder: the uploaded file and/or its generated thumbnails/poster
          if (row.storage_path && storage) await storage.removeFolder(row.storage_path);
          await run(db.from("media_assets").delete().eq("id", row.id), "Brisanje nije uspelo.");
        } catch (e) {
          failed.push({ row, error: toCmsError(e, "Brisanje nije uspelo.") });
        }
      }
      return failed;
    },
    async reorderMedia(ids) {
      await run(db.rpc("reorder_media", { p_ids: ids }), "Redosled nije sačuvan.");
    },

    /* ---------- settings ---------- */
    async getSettings() {
      const { data } = await run(db.from("site_settings").select("*").eq("id", 1).single(), "Podešavanja nisu učitana.");
      return data;
    },
    async updateSettings(patch) {
      const { data } = await run(db.from("site_settings").update(patch).eq("id", 1).select().single(), "Podešavanja nisu sačuvana.");
      return data;
    },
  };
}
