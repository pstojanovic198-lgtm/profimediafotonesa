/* Checks pasted links in the administrator's browser — the same way a
   visitor's browser will load them. No server ever fetches these URLs. */

import { decodeImage, makeVariants } from "./media-process.js";

/** Loads an image URL: { width, height } or throws a user-facing error. */
export function probeImage(url, { timeout = 20000 } = {}) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.referrerPolicy = "no-referrer";
    const t = setTimeout(() => {
      img.src = "";
      reject(new Error("Slika se predugo učitava. Proverite link ili internet konekciju."));
    }, timeout);
    img.onload = () => {
      clearTimeout(t);
      if (!img.naturalWidth) return reject(new Error("Link ne vodi do slike."));
      resolve({ width: img.naturalWidth, height: img.naturalHeight });
    };
    img.onerror = () => {
      clearTimeout(t);
      reject(new Error("Slika ne može da se učita sa ovog linka. Proverite da li je fajl javno dostupan (bez prijave) i da link vodi direktno do slike, a ne do stranice."));
    };
    img.src = url;
  });
}

/** When the host allows CORS, download once and build our own thumbnails. Otherwise null. */
export async function tryBuildVariantsFromUrl(url, { maxBytes = 40 * 1024 * 1024 } = {}) {
  try {
    const res = await fetch(url, { mode: "cors", credentials: "omit", referrerPolicy: "no-referrer" });
    if (!res.ok) return null;
    const len = +res.headers.get("content-length");
    if (len && len > maxBytes) return null;
    const blob = await res.blob();
    if (!/^image\//.test(blob.type) || blob.size > maxBytes) return null;
    const bmp = await decodeImage(blob);
    const variants = await makeVariants(bmp, [480, 960]);
    if (bmp.close) bmp.close();
    return variants;
  } catch {
    return null; // no CORS, network issue, or not decodable — the original URL will be used
  }
}

/** Vimeo oEmbed (public videos and unlisted links with hash): thumbnail, size, title. */
export async function vimeoInfo(pageUrl) {
  try {
    const res = await fetch("https://vimeo.com/api/oembed.json?width=1280&url=" + encodeURIComponent(pageUrl), { credentials: "omit" });
    if (!res.ok) return null;
    const j = await res.json();
    return {
      title: typeof j.title === "string" ? j.title.slice(0, 140) : null,
      thumbnailUrl: typeof j.thumbnail_url === "string" && j.thumbnail_url.startsWith("https://") ? j.thumbnail_url : null,
      width: +j.width || null,
      height: +j.height || null,
    };
  } catch {
    return null;
  }
}
