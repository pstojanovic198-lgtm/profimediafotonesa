/* Media previews in the admin: inline (editor/queue) and full-screen
   ("Pregled" — how a visitor will see it in the website lightbox). */
import { h, icon } from "./ui.js";
import { isAllowedEmbed, isSafeUrl } from "../../assets/js/media-safety.js";

/** Normalises a DB row or a queue item into { kind, src, poster, embedUrl, alt, title, description } */
export function toPreviewModel(m) {
  if (m.embed_url || m.embedUrl) return { kind: "embed", embedUrl: m.embed_url || m.embedUrl, poster: m.poster_url || m.thumbnail_url, title: m.title, description: m.description };
  if (m.media_type === "video" || m.kind === "video")
    return { kind: "video", src: m.source_url || m.src, poster: m.poster_url || m.poster, title: m.title, description: m.description };
  const variants = m.variants || [];
  const largest = variants.length ? variants[variants.length - 1].url : null;
  return { kind: "image", src: largest || m.source_url || m.src, alt: m.alt_text || m.alt || "", title: m.title, description: m.description };
}

function mediaNode(model, { controls = true } = {}) {
  const fail = (msg) => h("p", { class: "preview__msg", text: msg });
  const okSrc = (u) => u && (u.startsWith("blob:") || isSafeUrl(u));
  if (model.kind === "embed") {
    if (!isAllowedEmbed(model.embedUrl)) return fail("Ovaj video link nije dozvoljen za prikaz.");
    return h("iframe", {
      src: model.embedUrl,
      title: model.title || "Video",
      loading: "lazy",
      allow: "fullscreen; picture-in-picture; encrypted-media",
      allowfullscreen: true,
      referrerpolicy: "strict-origin-when-cross-origin",
      sandbox: "allow-scripts allow-same-origin allow-presentation allow-popups",
    });
  }
  if (model.kind === "video") {
    if (!okSrc(model.src)) return fail("Video link nije ispravan.");
    const v = h("video", { controls, playsInline: true, preload: "metadata", src: model.src });
    if (okSrc(model.poster)) v.poster = model.poster;
    v.addEventListener("error", () => v.replaceWith(fail("Video ne može da se reprodukuje. Proverite link ili format (MP4/WebM).")), { once: true });
    return v;
  }
  if (!okSrc(model.src)) return fail("Slika nije dostupna.");
  const img = h("img", { src: model.src, alt: model.alt || "", decoding: "async" });
  img.addEventListener("error", () => img.replaceWith(fail("Slika ne može da se učita.")), { once: true });
  return img;
}

export function inlinePreview(model) {
  return h("div", { class: "preview" }, mediaNode(model));
}

/** Full-screen preview modelled on the public lightbox. Videos never autoplay. */
export function openPublicPreview(model) {
  const opener = document.activeElement;
  const close = h("button", { class: "icon-btn pv__close", type: "button", "aria-label": "Zatvori pregled" }, icon("close"));
  const caption = h("div", { class: "pv__caption" }, h("strong", { text: model.title || "" }), model.description ? h("span", { text: model.description }) : null);
  const dlg = h(
    "dialog",
    { class: "pv", "aria-label": "Pregled kako će izgledati na sajtu" },
    h("p", { class: "pv__label", text: "Pregled — ovako će izgledati na sajtu" }),
    h("div", { class: "pv__stage" }, mediaNode(model)),
    caption,
    close,
  );
  const shut = () => {
    dlg.querySelectorAll("video").forEach((v) => v.pause());
    dlg.close();
    dlg.remove();
    if (opener && document.contains(opener)) opener.focus();
  };
  close.addEventListener("click", shut);
  dlg.addEventListener("cancel", (e) => {
    e.preventDefault();
    shut();
  });
  dlg.addEventListener("click", (e) => e.target === dlg && shut());
  document.body.append(dlg);
  dlg.showModal();
  close.focus();
}
