/* In-browser media processing for uploads.
   - Photos: decoded once (EXIF orientation applied) and re-encoded to WebP at
     480 / 960 / 1920 px wide, so the website never downloads the original
     just to show a thumbnail. Works on every Supabase plan (no paid image
     transformation service needed) and with any storage provider.
   - Videos: dimensions/duration read from metadata; a poster frame is
     captured automatically (the admin can replace it). */

export const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/avif"];
export const VIDEO_TYPES = ["video/mp4", "video/webm"];
export const IMAGE_EXT = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/avif": "avif" };
export const VIDEO_EXT = { "video/mp4": "mp4", "video/webm": "webm" };
export const VARIANT_WIDTHS = [480, 960, 1920];

const EXT_TO_TYPE = { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", avif: "image/avif", mp4: "video/mp4", m4v: "video/mp4", webm: "video/webm" };

/** Browsers sometimes report an empty type (Windows + .avif / .webm): fall back to the extension. */
export function fileType(file) {
  if (file.type && (IMAGE_TYPES.includes(file.type) || VIDEO_TYPES.includes(file.type))) return file.type;
  const ext = (file.name.split(".").pop() || "").toLowerCase();
  return EXT_TO_TYPE[ext] || file.type || "";
}

/** Returns an error message, or null when the file is acceptable. */
export function validateFile(file, kind, { maxImageMb, maxVideoMb }) {
  const type = fileType(file);
  if (kind === "image") {
    if (!IMAGE_TYPES.includes(type)) {
      if (VIDEO_TYPES.includes(type)) return "Ovo je video. Video dodajte na stranici „Dodaj video“.";
      if (/heic|heif/i.test(type + file.name)) return "HEIC fotografije (iPhone) nisu podržane u pregledačima. Na iPhone-u: Podešavanja → Kamera → Formati → „Najkompatibilniji“, ili pošaljite fotografiju kao JPG.";
      return "Format nije podržan. Dozvoljeno: JPG, PNG, WebP, AVIF.";
    }
    if (file.size > maxImageMb * 1024 * 1024) return `Fotografija je veća od ${maxImageMb} MB.`;
  } else {
    if (!VIDEO_TYPES.includes(type)) {
      if (IMAGE_TYPES.includes(type)) return "Ovo je fotografija. Fotografije dodajte na stranici „Dodaj fotografije“.";
      if (/quicktime|\.mov$/i.test(type + file.name)) return "MOV video se ne reprodukuje u svim pregledačima. Konvertujte ga u MP4 (npr. besplatnim programom HandBrake) ili ga postavite na YouTube.";
      return "Format nije podržan. Dozvoljeno: MP4, WebM.";
    }
    if (file.size > maxVideoMb * 1024 * 1024) return `Video je veći od ${maxVideoMb} MB. Smanjite ga ili ga postavite na YouTube/Vimeo i dodajte link.`;
  }
  if (file.size === 0) return "Fajl je prazan.";
  return null;
}

/** Decodes an image File/Blob with EXIF orientation applied. */
export async function decodeImage(blob) {
  if ("createImageBitmap" in window) {
    try {
      return await createImageBitmap(blob, { imageOrientation: "from-image" });
    } catch {
      /* fall through to <img> decoding (older Safari, some AVIF) */
    }
  }
  const url = URL.createObjectURL(blob);
  try {
    const img = new Image();
    img.decoding = "async";
    img.src = url;
    await img.decode();
    return img;
  } catch {
    throw new Error("Fajl nije ispravna slika ili ga ovaj pregledač ne može da otvori.");
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

const dims = (src) => ({ w: src.naturalWidth || src.videoWidth || src.width, h: src.naturalHeight || src.videoHeight || src.height });

function canvasToBlob(canvas, type, quality) {
  return new Promise((resolve) => canvas.toBlob(resolve, type, quality));
}

/** Resizes a decoded source to `width` (never upscales). WebP, JPEG if WebP encoding is unavailable. */
export async function resize(source, width, quality = 0.82) {
  const { w, h } = dims(source);
  const tw = Math.min(width, w), th = Math.max(1, Math.round((h * tw) / w));
  const canvas = document.createElement("canvas");
  canvas.width = tw;
  canvas.height = th;
  const ctx = canvas.getContext("2d", { alpha: true });
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(source, 0, 0, tw, th);
  let blob = await canvasToBlob(canvas, "image/webp", quality);
  if (!blob || blob.type !== "image/webp") blob = await canvasToBlob(canvas, "image/jpeg", 0.85);
  if (!blob) throw new Error("Pravljenje umanjene verzije nije uspelo.");
  canvas.width = canvas.height = 0; // free memory early (iOS)
  return { blob, width: tw, height: th, ext: blob.type === "image/webp" ? "webp" : "jpg" };
}

/** All responsive renditions for a decoded image: one per width up to the original size. */
export async function makeVariants(source, widths = VARIANT_WIDTHS) {
  const { w } = dims(source);
  const targets = widths.filter((x) => x < w);
  if (!targets.length || targets[targets.length - 1] < w) targets.push(Math.min(w, widths[widths.length - 1]));
  const unique = [...new Set(targets)].sort((a, b) => a - b);
  const out = [];
  for (const tw of unique) out.push(await resize(source, tw));
  return out;
}

/** Reads metadata of a video File/Blob or URL: { width, height, duration } */
export function readVideoMeta(src, { timeout = 20000 } = {}) {
  return new Promise((resolve, reject) => {
    const v = document.createElement("video");
    const url = src instanceof Blob ? URL.createObjectURL(src) : src;
    const done = (fn, val) => {
      clearTimeout(t);
      v.removeAttribute("src");
      v.load();
      if (src instanceof Blob) URL.revokeObjectURL(url);
      fn(val);
    };
    const t = setTimeout(() => done(reject, new Error("Video se predugo učitava. Proverite link ili internet konekciju.")), timeout);
    v.preload = "metadata";
    v.muted = true;
    v.playsInline = true;
    v.onloadedmetadata = () => done(resolve, { width: v.videoWidth || null, height: v.videoHeight || null, duration: Number.isFinite(v.duration) ? v.duration : null });
    v.onerror = () => {
      const code = v.error && v.error.code;
      done(reject, new Error(code === 4 ? "Ovaj video ne može da se reprodukuje (nepodržan format ili link nije javan)." : "Video ne može da se učita."));
    };
    v.src = url;
  });
}

/** Captures a frame as a poster image (WebP). Returns null when not possible (e.g. no CORS). */
export function captureVideoFrame(src, { at = 1, width = 1280, timeout = 20000 } = {}) {
  return new Promise((resolve) => {
    const v = document.createElement("video");
    const url = src instanceof Blob ? URL.createObjectURL(src) : src;
    let finished = false;
    const done = (val) => {
      if (finished) return;
      finished = true;
      clearTimeout(t);
      v.removeAttribute("src");
      v.load();
      if (src instanceof Blob) URL.revokeObjectURL(url);
      resolve(val);
    };
    const t = setTimeout(() => done(null), timeout);
    if (!(src instanceof Blob)) v.crossOrigin = "anonymous";
    v.preload = "auto";
    v.muted = true;
    v.playsInline = true;
    v.onloadedmetadata = () => {
      const d = Number.isFinite(v.duration) ? v.duration : 0;
      v.currentTime = Math.min(at, d > 0 ? d / 3 : 0);
    };
    v.onseeked = async () => {
      try {
        if (!v.videoWidth) return done(null);
        done(await resize(v, width, 0.85));
      } catch {
        done(null); // tainted canvas (cross-origin without CORS) or decode problem
      }
    };
    v.onerror = () => done(null);
    v.src = url;
  });
}
