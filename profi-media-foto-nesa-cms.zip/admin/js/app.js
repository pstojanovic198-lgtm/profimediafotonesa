/* Admin entry point: configuration check, authentication, routing. */
import { createApi } from "./api.js";
import { createStorage } from "./storage/index.js";
import { h, icon, clear, toast } from "./ui.js";
import { renderLogin, renderRecovery } from "./views/login.js";
import { renderDashboard } from "./views/dashboard.js";
import { renderGallery } from "./views/gallery.js";
import { renderAddMedia } from "./views/add-media.js";
import { renderCategories } from "./views/categories.js";
import { renderSettings } from "./views/settings.js";

// Refuse to run inside a frame (clickjacking); a <meta> CSP cannot set frame-ancestors.
if (window.top !== window.self) {
  document.body.textContent = "";
  throw new Error("framed");
}

const ROUTES = {
  pregled: { title: "Pregled", icon: "home", render: renderDashboard },
  galerija: { title: "Galerija", icon: "grid", render: renderGallery },
  "dodaj-fotografije": { title: "Dodaj fotografije", icon: "image", render: (el, ctx) => renderAddMedia(el, ctx, "image") },
  "dodaj-video": { title: "Dodaj video", icon: "video", render: (el, ctx) => renderAddMedia(el, ctx, "video") },
  kategorije: { title: "Kategorije", icon: "tag", render: renderCategories },
  podesavanja: { title: "Podešavanja", icon: "settings", render: renderSettings },
};
const DEFAULT_ROUTE = "pregled";

const boot = document.getElementById("boot");
const app = document.getElementById("app");
const bootText = boot.querySelector("[data-boot-text]");

function fatal(message, detail) {
  bootText.textContent = message;
  if (detail) boot.append(h("p", { class: "small muted", text: detail }));
  boot.hidden = false;
  app.hidden = true;
}

const config = window.PMFN_CMS || {};
if (!config.supabaseUrl || !config.supabaseAnonKey || !window.supabase?.createClient) {
  fatal(
    "CMS još nije povezan.",
    "Upišite adresu Supabase projekta i javni (anon) ključ u assets/js/cms-config.js — vidi docs/DEPLOYMENT.md.",
  );
} else {
  start().catch((e) => {
    console.error(e);
    fatal("Administracija trenutno ne može da se učita.", "Proverite internet konekciju i osvežite stranicu.");
  });
}

async function start() {
  const client = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, storageKey: "pmfn-admin-auth" },
  });
  const api = createApi(client);
  const storage = createStorage(config, client);
  const ctx = { api, storage, config, categories: [], settings: null, user: null, navigate, refreshCategories, cleanup: null };

  let shell = null;
  let recovery = location.hash.includes("type=recovery");

  api.onAuthChange((event, session) => {
    if (event === "PASSWORD_RECOVERY") {
      recovery = true;
      showRecovery();
    } else if (event === "SIGNED_OUT") {
      ctx.user = null;
      shell = null;
      showLogin();
    } else if (event === "TOKEN_REFRESHED" && !session) {
      showLogin("Sesija je istekla. Prijavite se ponovo.");
    }
  });

  function show(node) {
    boot.hidden = true;
    clear(app).append(node);
    app.hidden = false;
  }

  function showLogin(message) {
    if (ctx.cleanup) ctx.cleanup();
    ctx.cleanup = null;
    document.title = "Prijava · Administracija";
    show(renderLogin(ctx, { message, onSignedIn: enter }));
  }

  function showRecovery() {
    document.title = "Nova lozinka · Administracija";
    show(
      renderRecovery(ctx, {
        onDone: () => {
          recovery = false;
          history.replaceState(null, "", location.pathname + "#/pregled");
          enter();
        },
      }),
    );
  }

  async function enter() {
    const session = await api.session();
    if (!session) return showLogin();
    let admin = false;
    try {
      admin = await api.isAdmin();
    } catch (e) {
      return showLogin(e.message);
    }
    if (!admin) {
      await api.signOut();
      return showLogin("Ovaj nalog nema administratorska prava. Obratite se osobi koja održava sajt.");
    }
    ctx.user = session.user;
    try {
      [ctx.categories, ctx.settings] = await Promise.all([api.listCategories(), api.getSettings()]);
    } catch (e) {
      toast(e.message, "error");
    }
    shell = buildShell();
    show(shell.root);
    route();
  }

  async function refreshCategories() {
    ctx.categories = await api.listCategories();
    return ctx.categories;
  }

  function navigate(name) {
    if (location.hash === "#/" + name) route();
    else location.hash = "#/" + name;
  }

  function currentRoute() {
    const m = /^#\/([a-z-]+)/.exec(location.hash);
    return m && ROUTES[m[1]] ? m[1] : DEFAULT_ROUTE;
  }

  async function route() {
    if (!shell || recovery) return;
    const name = currentRoute();
    const r = ROUTES[name];
    if (ctx.cleanup) {
      ctx.cleanup();
      ctx.cleanup = null;
    }
    shell.setActive(name);
    document.title = r.title + " · Administracija · Profi Media";
    const main = shell.main;
    clear(main);
    try {
      const cleanup = await r.render(main, ctx);
      if (typeof cleanup === "function") ctx.cleanup = cleanup;
    } catch (e) {
      console.error(e);
      clear(main).append(
        h("div", { class: "notice notice--error" }, icon("alert"), h("div", null, h("p", { text: e.message || "Stranica nije učitana." }),
          h("button", { class: "btn btn--secondary btn--sm", type: "button", text: "Pokušaj ponovo", onclick: route }))),
      );
    }
    main.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  window.addEventListener("hashchange", route);

  // Warn before leaving while uploads are running
  window.addEventListener("beforeunload", (e) => {
    if (document.querySelector("[data-busy-upload]")) {
      e.preventDefault();
      e.returnValue = "";
    }
  });

  function buildShell() {
    const main = h("main", { class: "main", id: "main", tabindex: "-1" });
    const links = {};
    const nav = h(
      "ul",
      { class: "nav", role: "list" },
      Object.entries(ROUTES).map(([name, r]) => {
        const a = h("a", { href: "#/" + name }, icon(r.icon), r.title);
        a.addEventListener("click", () => root.classList.remove("nav-open"));
        links[name] = a;
        return h("li", null, a);
      }),
      h("li", { class: "nav__sep", role: "presentation" }),
      h("li", null, h("a", { href: "../#radovi", target: "_blank", rel: "noopener" }, icon("external"), "Otvori sajt")),
      h(
        "li",
        null,
        h(
          "button",
          {
            type: "button",
            onclick: async (e) => {
              e.currentTarget.disabled = true;
              await api.signOut();
            },
          },
          icon("logout"),
          "Odjava",
        ),
      ),
    );
    const brand = () =>
      h(
        "a",
        { class: "brand", href: "#/pregled" },
        h("img", { src: "../assets/brand/profi-media-foto-nesa-logo-160.webp", width: 36, height: 36, alt: "" }),
        h("span", null, h("span", { class: "brand__name", text: "Profi Media" }), h("span", { class: "brand__sub", text: "Administracija" })),
      );
    const menuBtn = h("button", { class: "icon-btn menu-btn", type: "button", "aria-label": "Meni", "aria-expanded": "false", "aria-controls": "sidebar" }, icon("menu"));
    const sidebar = h(
      "nav",
      { class: "sidebar", id: "sidebar", "aria-label": "Administracija" },
      h("div", { class: "brand-wrap" }, brand()),
      nav,
      h("p", { class: "sidebar__foot" }, "Prijavljeni: ", h("strong", { text: ctx.user?.email || "" })),
    );
    const root = h(
      "div",
      { class: "shell" },
      h("header", { class: "topbar" }, brand(), h("span", { class: "topbar__spacer" }), menuBtn),
      sidebar,
      main,
    );
    menuBtn.addEventListener("click", () => {
      const open = root.classList.toggle("nav-open");
      menuBtn.setAttribute("aria-expanded", String(open));
      menuBtn.setAttribute("aria-label", open ? "Zatvori meni" : "Meni");
      menuBtn.replaceChildren(icon(open ? "close" : "menu"));
      if (open) links[currentRoute()]?.focus();
    });
    root.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && root.classList.contains("nav-open")) {
        menuBtn.click();
        menuBtn.focus();
      }
    });
    return {
      root,
      main,
      setActive(name) {
        for (const [n, a] of Object.entries(links)) {
          if (n === name) a.setAttribute("aria-current", "page");
          else a.removeAttribute("aria-current");
        }
        root.classList.remove("nav-open");
        menuBtn.setAttribute("aria-expanded", "false");
        menuBtn.replaceChildren(icon("menu"));
      },
    };
  }

  // Start
  if (recovery) {
    // detectSessionInUrl processes the recovery token; PASSWORD_RECOVERY fires shortly after
    await api.session();
    showRecovery();
  } else if (await api.session()) await enter();
  else showLogin();
}
