/* Turns a queued upload or link into storage objects + a media_assets row.
   Every function cleans up the files it uploaded if a later step fails. */
import { decodeImage, makeVariants, fileType, IMAGE_EXT, VIDEO_EXT, captureVideoFrame } from "./media-process.js";
import { tryBuildVariantsFromUrl } from "./media-probe.js";

export function newFolder(id) {
  const d = new Date();
  return `${d.getUTCFullYear()}/${String(d.getUTCMonth() + 1).padStart(2, "0")}/${id}`;
}

export function resumeKeyFor(file) {
  return [file.name, file.size, file.lastModified].join("|");
}

/** Uploads a list of {blob, name} into `folder` with combined progress (0..1). */
async function uploadAll(storage, folder, parts, { signal, onProgress }) {
  const total = parts.reduce((s, p) => s + p.blob.size, 0) || 1;
  let done = 0;
  const urls = [], paths = [];
  try {
    for (const p of parts) {
      if (signal && signal.aborted) throw Object.assign(new Error("Otpremanje je otkazano."), { aborted: true });
      const r = await storage.upload(p.blob, `${folder}/${p.name}`, {
        contentType: p.type || p.blob.type,
        signal,
        resumeKey: p.resumeKey,
        onProgress: (n) => onProgress && onProgress(Math.min(1, (done + n) / total)),
      });
      done += p.blob.size;
      onProgress && onProgress(done / total);
      urls.push(r.url);
      paths.push(r.path);
    }
  } catch (e) {
    await storage.remove(paths).catch(() => {});
    throw e;
  }
  return { urls, paths };
}

/** Poster/thumbnail renditions from an image File/Blob. */
async function posterParts(source, prefix = "poster") {
  const bmp = await decodeImage(source);
  const variants = await makeVariants(bmp, [480, 960, 1600]);
  if (bmp.close) bmp.close();
  return variants.map((v) => ({ blob: v.blob, name: `${prefix}-w${v.width}.${v.ext}`, w: v.width }));
}

function posterFields(parts, urls) {
  const variants = parts.map((p, i) => ({ w: p.w, url: urls[i] }));
  return { thumbnail_url: variants[0].url, poster_url: variants[variants.length - 1].url, variants };
}

/* ---------------- photos ---------------- */
export async function uploadImageFile({ file, folder, storage, keepOriginal, signal, onProgress, onStage }) {
  onStage && onStage("Pripremam umanjene verzije…");
  const type = fileType(file);
  const bmp = await decodeImage(file);
  const width = bmp.naturalWidth || bmp.width, height = bmp.naturalHeight || bmp.height;
  const variants = await makeVariants(bmp);
  if (bmp.close) bmp.close();
  const parts = variants.map((v) => ({ blob: v.blob, name: `w${v.width}.${v.ext}`, w: v.width }));
  if (keepOriginal) parts.push({ blob: file, name: `original.${IMAGE_EXT[type]}`, type });
  onStage && onStage("Otpremanje…");
  const { urls, paths } = await uploadAll(storage, folder, parts, { signal, onProgress });
  const vs = variants.map((v, i) => ({ w: v.width, url: urls[i] }));
  return {
    paths,
    row: {
      media_type: "image",
      source_type: "upload",
      storage_path: folder,
      source_url: keepOriginal ? urls[urls.length - 1] : vs[vs.length - 1].url,
      thumbnail_url: vs[0].url,
      variants: vs,
      width,
      height,
      mime_type: type,
      file_size_bytes: file.size,
    },
  };
}

/* ---------------- videos ---------------- */
export async function uploadVideoFile({ file, folder, storage, posterFile, meta, signal, onProgress, onStage }) {
  const type = fileType(file);
  onStage && onStage("Pripremam naslovnu sliku…");
  let pParts = [];
  const posterSource = posterFile || (await captureVideoFrame(file))?.blob;
  if (posterSource) pParts = await posterParts(posterSource);
  onStage && onStage("Otpremanje videa…");
  const parts = [{ blob: file, name: `video.${VIDEO_EXT[type]}`, type, resumeKey: resumeKeyFor(file) }, ...pParts];
  const { urls, paths } = await uploadAll(storage, folder, parts, { signal, onProgress });
  return {
    paths,
    row: {
      media_type: "video",
      source_type: "upload",
      storage_path: folder,
      source_url: urls[0],
      ...(pParts.length ? posterFields(pParts, urls.slice(1)) : {}),
      width: meta?.width || null,
      height: meta?.height || null,
      duration_seconds: meta?.duration ? Math.round(meta.duration * 100) / 100 : null,
      mime_type: type,
      file_size_bytes: file.size,
    },
  };
}

/* ---------------- links ---------------- */
export async function prepareExternalImage({ analysis, dims, folder, storage, signal, onProgress, onStage }) {
  let variants = analysis.variants || [];
  let thumbnail = analysis.thumbnailUrl;
  let storagePath = null, paths = [];
  if (!variants.length) {
    onStage && onStage("Pravim umanjene verzije…");
    const built = await tryBuildVariantsFromUrl(analysis.url);
    if (built) {
      const parts = built.map((v) => ({ blob: v.blob, name: `w${v.width}.${v.ext}`, w: v.width }));
      const up = await uploadAll(storage, folder, parts, { signal, onProgress });
      variants = parts.map((p, i) => ({ w: p.w, url: up.urls[i] }));
      thumbnail = variants[0].url;
      storagePath = folder;
      paths = up.paths;
    }
  }
  return {
    paths,
    row: {
      media_type: "image",
      source_type: "external",
      provider: analysis.provider,
      source_url: analysis.url,
      storage_path: storagePath,
      thumbnail_url: thumbnail || analysis.url,
      variants,
      width: dims?.width || null,
      height: dims?.height || null,
    },
  };
}

export async function prepareExternalVideo({ analysis, info, posterFile, folder, storage, signal, onProgress, onStage }) {
  let pParts = [];
  if (posterFile) pParts = await posterParts(posterFile);
  else if (analysis.kind === "video" && !analysis.posterUrl) {
    onStage && onStage("Pokušavam da napravim naslovnu sliku…");
    const frame = await captureVideoFrame(analysis.url); // works only if the host allows CORS
    if (frame) pParts = await posterParts(frame.blob);
  }
  let posterRow = {}, paths = [], storagePath = null;
  if (pParts.length) {
    onStage && onStage("Otpremanje naslovne slike…");
    const up = await uploadAll(storage, folder, pParts, { signal, onProgress });
    posterRow = posterFields(pParts, up.urls);
    paths = up.paths;
    storagePath = folder;
  } else {
    const t = info?.thumbnailUrl || analysis.posterUrl || analysis.thumbnailUrl;
    if (t) posterRow = { thumbnail_url: t, poster_url: t };
  }
  const isEmbed = analysis.kind === "embed";
  const aspect = analysis.aspect || { w: 16, h: 9 };
  return {
    paths,
    row: {
      media_type: "video",
      source_type: isEmbed ? analysis.sourceType : "external",
      provider: analysis.provider,
      source_url: analysis.url,
      embed_url: isEmbed ? analysis.embedUrl : null,
      storage_path: storagePath,
      variants: posterRow.variants || [],
      thumbnail_url: posterRow.thumbnail_url || null,
      poster_url: posterRow.poster_url || null,
      width: info?.width || (aspect.w > aspect.h ? 1920 : 1080),
      height: info?.height || (aspect.w > aspect.h ? 1080 : 1920),
      duration_seconds: info?.duration ? Math.round(info.duration * 100) / 100 : null,
    },
  };
}

/** Replaces the poster of an existing item (editor). */
export async function replacePoster({ row, file, storage, onProgress }) {
  const folder = row.storage_path || newFolder(row.id);
  const stamp = Date.now().toString(36);
  const parts = await posterParts(file, "poster-" + stamp);
  const up = await uploadAll(storage, folder, parts, { onProgress });
  return { paths: up.paths, patch: { ...posterFields(parts, up.urls), storage_path: folder } };
}
