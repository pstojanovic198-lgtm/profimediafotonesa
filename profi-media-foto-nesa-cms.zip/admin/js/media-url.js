/* Analysis and normalisation of pasted media links.

   Principles
   - Any public https image/video URL is accepted; hosts are NOT allow-listed.
   - Provider-specific rewriting is applied only where the provider documents
     a stable URL format (YouTube, Vimeo, Dropbox raw links, Cloudinary and
     ImageKit transformations, Unsplash image CDN, Google Drive preview).
   - Links that are sharing pages, folders, albums or private items are
     rejected with an explanation and a suggested alternative.
   - Nothing is fetched by a server: validation of the real file happens in
     the administrator's browser (see media-probe.js), so there is no SSRF.

   Result: { ok: true, kind, sourceType, provider, url, embedUrl, thumbnailUrl,
             variants, aspect, notes[] }
         | { ok: false, code, message } */

import { isSafeUrl, isAllowedEmbed } from "../../assets/js/media-safety.js";

const IMAGE_EXT = /\.(jpe?g|png|webp|avif)$/i;
const VIDEO_EXT = /\.(mp4|m4v|webm)$/i;
const OTHER_MEDIA_EXT = /\.(gif|svg|heic|heif|tiff?|bmp|mov|avi|mkv|wmv|flv)$/i;

const MSG = {
  empty: "Nalepite link.",
  invalid: "Ovo nije ispravan internet link. Proverite da li ste kopirali celu adresu (počinje sa https://).",
  http: "Link mora počinjati sa https:// — nezaštićeni (http) linkovi se ne prikazuju na sajtu.",
  credentials: "Link sadrži korisničko ime ili lozinku. Takav link se ne sme objaviti.",
  privateHost: "Ovaj link vodi do lokalnog ili privatnog računara i posetioci ga ne mogu otvoriti.",
  ytPlaylist: "Ovo je YouTube plejlista ili kanal, a ne pojedinačan video. Otvorite sam video i kopirajte njegov link.",
  ytBad: "Ne mogu da pronađem ID YouTube videa u ovom linku. Otvorite video na YouTube-u, kliknite „Podeli“ i kopirajte link.",
  vimeoBad: "Ne mogu da pronađem broj Vimeo videa. Otvorite video na Vimeo-u, kliknite „Share“ i kopirajte link.",
  vimeoShowcase: "Ovo je Vimeo kolekcija (showcase/album). Dodajte svaki video posebno.",
  driveFolder: "Ovo je Google Drive folder. Otvorite pojedinačnu fotografiju ili video, izaberite „Deli“ → „Svako ko ima link“ i kopirajte link tog fajla.",
  driveBad: "Ne mogu da pronađem ID fajla u ovom Google Drive linku.",
  dropboxFolder: "Ovo je Dropbox folder. Podelite pojedinačan fajl i kopirajte njegov link.",
  gphotos: "Google Photos linkovi vode na stranicu albuma, a ne na sam fajl, i ne mogu se pouzdano prikazati. Preuzmite fotografiju i otpremite je, ili koristite Google Drive / Dropbox.",
  onedrive: "OneDrive / SharePoint linkovi vode na stranicu za pregled, a ne na sam fajl. Preuzmite fajl i otpremite ga, ili koristite Dropbox / Google Drive.",
  social: "Linkovi sa Instagrama, Facebook-a i TikTok-a ne mogu se ugraditi bez njihovih skripti za praćenje. Postavite video na YouTube ili Vimeo, ili otpremite fajl.",
  icloud: "iCloud linkovi vode na stranicu za preuzimanje, a ne na sam fajl. Preuzmite fajl i otpremite ga.",
  unsplashPage: "Ovo je stranica sa fotografijom, a ne sama slika. Desnim klikom na fotografiju izaberite „Kopiraj adresu slike“ (Copy image address).",
  imgurPage: "Ovo je Imgur stranica, a ne sama slika. Desnim klikom na sliku izaberite „Kopiraj adresu slike“.",
  htmlPage: "Ovaj link vodi na internet stranicu, a ne direktno na fotografiju ili video. Otvorite sam fajl (desni klik → „Kopiraj adresu slike“ / „Kopiraj adresu videa“).",
  unsupportedFormat: "Ovaj format nije podržan na sajtu. Podržano: JPG, PNG, WebP, AVIF za fotografije i MP4, WebM za video.",
  movFormat: "MOV video se ne reprodukuje u svim pregledačima (npr. Chrome na Windows-u). Konvertujte ga u MP4 ili ga postavite na YouTube/Vimeo.",
  expectImage: "Ovaj link vodi do videa. Video dodajte na stranici „Dodaj video“.",
  expectVideo: "Ovaj link vodi do fotografije. Fotografije dodajte na stranici „Dodaj fotografije“.",
};

const NOTE = {
  unknownType: "Iz linka se ne vidi vrsta fajla — proveravamo ga učitavanjem.",
  drive: "Google Drive fajl mora biti podeljen kao „Svako ko ima link“. Google ponekad ograničava prikaz velikih ili često otvaranih fajlova — za najpouzdaniji prikaz otpremite fajl.",
  dropbox: "Dropbox link je pretvoren u direktan link do fajla.",
  noThumbs: "Ovaj servis ne pravi umanjene verzije — galerija će učitavati pun fajl. Ako je fajl velik, bolje ga je otpremiti.",
};

function fail(code) {
  return { ok: false, code, message: MSG[code] };
}

function ok(fields) {
  return { ok: true, provider: null, embedUrl: null, thumbnailUrl: null, variants: [], aspect: null, notes: [], ...fields };
}

function isPrivateHost(host) {
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal")) return true;
  if (host.startsWith("[")) return true; // IPv6 literal — not useful for a public gallery
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!m) return false;
  const [a, b] = [+m[1], +m[2]];
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
}

function hostIs(host, ...domains) {
  return domains.some((d) => host === d || host.endsWith("." + d));
}

/* ---------------- YouTube ---------------- */
const YT_ID = /^[A-Za-z0-9_-]{11}$/;

function parseYouTubeTime(t) {
  if (!t) return 0;
  if (/^\d+$/.test(t)) return +t;
  const m = /^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/.exec(t);
  return m ? (+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0) : 0;
}

function youtube(u) {
  const host = u.hostname.replace(/^(www|m|music)\./, "");
  let id = null, shorts = false;
  if (host === "youtu.be") id = u.pathname.split("/")[1];
  else {
    const parts = u.pathname.split("/").filter(Boolean);
    if (parts[0] === "watch") id = u.searchParams.get("v");
    else if (["embed", "shorts", "live", "v"].includes(parts[0])) {
      id = parts[1];
      shorts = parts[0] === "shorts";
    } else if (parts[0] === "playlist" || parts[0] === "channel" || parts[0] === "c" || parts[0]?.startsWith("@")) {
      return fail("ytPlaylist");
    }
  }
  if (!id || !YT_ID.test(id)) return fail(u.searchParams.get("list") ? "ytPlaylist" : "ytBad");
  const start = parseYouTubeTime(u.searchParams.get("t") || u.searchParams.get("start"));
  const embedUrl = `https://www.youtube-nocookie.com/embed/${id}?rel=0${start ? "&start=" + start : ""}`;
  return ok({
    kind: "embed",
    sourceType: "youtube",
    provider: "youtube",
    url: `https://www.youtube.com/watch?v=${id}${start ? "&t=" + start : ""}`,
    embedUrl,
    thumbnailUrl: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    aspect: shorts ? { w: 9, h: 16 } : { w: 16, h: 9 },
    videoId: id,
  });
}

/* ---------------- Vimeo ---------------- */
function vimeo(u) {
  const parts = u.pathname.split("/").filter(Boolean);
  if (["showcase", "album"].includes(parts[0])) return fail("vimeoShowcase");
  let id = null, hash = u.searchParams.get("h");
  if (u.hostname === "player.vimeo.com") {
    if (parts[0] === "video") id = parts[1];
  } else {
    const i = parts.findIndex((p) => /^\d{1,12}$/.test(p));
    if (i >= 0) {
      id = parts[i];
      if (!hash && parts[i + 1] && /^[0-9a-f]{6,20}$/i.test(parts[i + 1])) hash = parts[i + 1];
    }
  }
  if (!id || !/^\d{1,12}$/.test(id)) return fail("vimeoBad");
  if (hash && !/^[0-9a-f]{6,20}$/i.test(hash)) hash = null;
  const embedUrl = `https://player.vimeo.com/video/${id}?dnt=1${hash ? "&h=" + hash : ""}`;
  return ok({
    kind: "embed",
    sourceType: "vimeo",
    provider: "vimeo",
    url: `https://vimeo.com/${id}${hash ? "/" + hash : ""}`,
    embedUrl,
    aspect: { w: 16, h: 9 },
    videoId: id,
  });
}

/* ---------------- Google Drive ---------------- */
function googleDrive(u, expect) {
  if (/\/drive\/(u\/\d+\/)?folders\//.test(u.pathname) || u.pathname.includes("/folderview")) return fail("driveFolder");
  let id = null;
  const m = /\/file\/d\/([A-Za-z0-9_-]{10,100})/.exec(u.pathname);
  if (m) id = m[1];
  else id = u.searchParams.get("id");
  if (!id || !/^[A-Za-z0-9_-]{10,100}$/.test(id)) return fail("driveBad");
  if (expect === "video") {
    return ok({
      kind: "embed",
      sourceType: "gdrive",
      provider: "gdrive",
      url: `https://drive.google.com/file/d/${id}/view`,
      embedUrl: `https://drive.google.com/file/d/${id}/preview`,
      thumbnailUrl: `https://drive.google.com/thumbnail?id=${id}&sz=w960`,
      aspect: { w: 16, h: 9 },
      notes: [NOTE.drive],
    });
  }
  const at = (w) => `https://drive.google.com/thumbnail?id=${id}&sz=w${w}`;
  return ok({
    kind: "image",
    sourceType: "external",
    provider: "gdrive",
    url: at(2000),
    thumbnailUrl: at(480),
    variants: [480, 960, 2000].map((w) => ({ w, url: at(w) })),
    notes: [NOTE.drive],
  });
}

/* ---------------- Dropbox ---------------- */
function dropbox(u) {
  if (u.pathname.startsWith("/sh/") || u.pathname.startsWith("/scl/fo/")) return fail("dropboxFolder");
  const out = new URL(u.href);
  if (out.hostname !== "dl.dropboxusercontent.com") {
    out.hostname = "www.dropbox.com";
    out.searchParams.delete("dl");
    out.searchParams.set("raw", "1");
  }
  return { url: out.href, note: NOTE.dropbox };
}

/* ---------------- CDN transformations ---------------- */
// Cloudinary: only when the URL has no transformation yet (…/upload/v123/… or …/upload/id)
function cloudinary(u, kind) {
  const m = /^\/([^/]+)\/(image|video)\/upload\/(.+)$/.exec(u.pathname);
  if (!m) return null;
  const rest = m[3];
  const first = rest.split("/")[0];
  const hasTransform = rest.includes("/") && !/^v\d+$/.test(first) && /[a-z]{1,3}_[^/]*/.test(first);
  const base = `${u.origin}/${m[1]}/${m[2]}/upload/`;
  if (m[2] === "image" && kind === "image") {
    if (hasTransform) return { variants: [] };
    const at = (w) => `${base}w_${w},c_limit,f_auto,q_auto/${rest}`;
    return { thumbnailUrl: at(480), variants: [480, 960, 1920].map((w) => ({ w, url: at(w) })) };
  }
  if (m[2] === "video" && kind === "video" && !hasTransform) {
    const poster = `${base}so_1,w_960,c_limit,f_jpg/${rest.replace(/\.(mp4|m4v|webm|mov)$/i, "")}.jpg`;
    return { thumbnailUrl: poster, posterUrl: poster };
  }
  return null;
}

function imagekit(u) {
  if (u.searchParams.has("tr") || u.pathname.includes("/tr:")) return { variants: [] };
  const at = (w) => {
    const x = new URL(u.href);
    x.searchParams.set("tr", `w-${w},c-at_max`);
    return x.href;
  };
  return { thumbnailUrl: at(480), variants: [480, 960, 1920].map((w) => ({ w, url: at(w) })) };
}

function unsplashCdn(u) {
  const at = (w) => {
    const x = new URL(u.href);
    x.searchParams.set("w", String(w));
    x.searchParams.set("auto", "format");
    x.searchParams.set("fit", "max");
    x.searchParams.set("q", "80");
    return x.href;
  };
  return { url: at(2000), thumbnailUrl: at(480), variants: [480, 960, 2000].map((w) => ({ w, url: at(w) })) };
}

/* ---------------- main ---------------- */

/**
 * @param {string} input pasted text
 * @param {{expect?: "image"|"video"}} opts what the admin is adding
 */
export function analyzeMediaUrl(input, { expect = "image" } = {}) {
  const raw = String(input ?? "").trim();
  if (!raw) return fail("empty");
  let u;
  try {
    u = new URL(/^[a-z][a-z0-9+.-]*:/i.test(raw) ? raw : "https://" + raw);
  } catch {
    return fail("invalid");
  }
  if (u.protocol === "http:") {
    if (u.hostname === "localhost" || u.hostname === "127.0.0.1") {
      // allowed only for local development
    } else return fail("http");
  } else if (u.protocol !== "https:") return fail("invalid");
  if (u.username || u.password) return fail("credentials");
  if (u.protocol === "https:" && isPrivateHost(u.hostname)) return fail("privateHost");

  const host = u.hostname.toLowerCase();

  // Embeddable video platforms
  if (hostIs(host, "youtube.com", "youtu.be", "youtube-nocookie.com")) {
    return expect === "image" ? fail("expectImage") : youtube(u);
  }
  if (hostIs(host, "vimeo.com")) {
    return expect === "image" ? fail("expectImage") : vimeo(u);
  }

  // Known sharing pages that are not media files
  if (hostIs(host, "photos.google.com", "photos.app.goo.gl") || (host === "goo.gl" && u.pathname.startsWith("/photos"))) return fail("gphotos");
  if (hostIs(host, "onedrive.live.com", "1drv.ms", "sharepoint.com")) return fail("onedrive");
  if (hostIs(host, "instagram.com", "facebook.com", "fb.watch", "tiktok.com", "instagr.am")) return fail("social");
  if (hostIs(host, "icloud.com")) return fail("icloud");
  if (host === "unsplash.com" || host === "www.unsplash.com") return fail("unsplashPage");
  if ((host === "imgur.com" || host === "www.imgur.com") && !IMAGE_EXT.test(u.pathname) && !VIDEO_EXT.test(u.pathname)) return fail("imgurPage");
  if (hostIs(host, "drive.google.com", "docs.google.com")) return googleDrive(u, expect);

  let url = u.href;
  const notes = [];
  if (hostIs(host, "dropbox.com", "dropboxusercontent.com")) {
    const d = dropbox(u);
    if (!d.url) return d;
    url = d.url;
    notes.push(d.note);
  }

  const path = decodeURIComponent(new URL(url).pathname);
  if (/\.mov$/i.test(path)) return fail("movFormat");
  if (OTHER_MEDIA_EXT.test(path)) return fail("unsupportedFormat");
  if (/\.(html?|php|aspx?)$/i.test(path)) return fail("htmlPage");

  let kind = IMAGE_EXT.test(path) ? "image" : VIDEO_EXT.test(path) ? "video" : null;
  if (host === "images.unsplash.com") kind = "image";
  if (kind && kind !== expect) return fail(kind === "video" ? "expectImage" : "expectVideo");
  if (!kind) {
    kind = expect;
    notes.push(NOTE.unknownType);
  }

  const result = ok({ kind, sourceType: "external", provider: null, url, notes });
  let extra = null;
  if (host === "res.cloudinary.com") {
    result.provider = "cloudinary";
    extra = cloudinary(new URL(url), kind);
  } else if (host === "ik.imagekit.io" && kind === "image") {
    result.provider = "imagekit";
    extra = imagekit(new URL(url));
  } else if (host === "images.unsplash.com") {
    result.provider = "unsplash";
    extra = unsplashCdn(new URL(url));
  } else if (hostIs(host, "dropbox.com", "dropboxusercontent.com")) {
    result.provider = "dropbox";
  } else if (hostIs(host, "b-cdn.net")) {
    result.provider = "bunny";
  } else if (hostIs(host, "amazonaws.com")) {
    result.provider = "s3";
  } else if (host === "storage.googleapis.com") {
    result.provider = "gcs";
  } else if (hostIs(host, "supabase.co")) {
    result.provider = "supabase";
  }
  if (extra) Object.assign(result, extra);
  if (kind === "image" && !result.variants.length) result.notes.push(NOTE.noThumbs);

  if (!isSafeUrl(result.url)) return fail("invalid");
  if (result.embedUrl && !isAllowedEmbed(result.embedUrl)) return fail("invalid");
  return result;
}

/** Turns "IMG_2041-mladenci_crkva.jpg" into "IMG 2041 mladenci crkva". */
export function titleFromFilename(name) {
  const base = String(name || "").replace(/\.[a-z0-9]{2,5}$/i, "").replace(/[_\-.]+/g, " ").replace(/\s+/g, " ").trim();
  if (!base) return "Bez naziva";
  return (base.charAt(0).toUpperCase() + base.slice(1)).slice(0, 140);
}

/** Latin Serbian → URL identifier: "Rođendani i proslave" → "rodjendani-i-proslave". */
export function slugify(text) {
  const map = { č: "c", ć: "c", ž: "z", š: "s", đ: "dj", Č: "c", Ć: "c", Ž: "z", Š: "s", Đ: "dj" };
  return String(text || "")
    .replace(/[čćžšđČĆŽŠĐ]/g, (c) => map[c])
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40)
    .replace(/-+$/g, "");
}
